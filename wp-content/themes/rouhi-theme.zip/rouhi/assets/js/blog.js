(function($) {
    "use strict";


    var blog = {};
    zen.modules.blog = blog;

    blog.zenInitAudioPlayer = zenInitAudioPlayer;

    blog.zenOnDocumentReady = zenOnDocumentReady;
    blog.zenOnWindowLoad = zenOnWindowLoad;
    blog.zenOnWindowResize = zenOnWindowResize;
    blog.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenInitAudioPlayer();
        zenInitBlogSlider();
        zenInitBlogSingleArrows();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {

    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {

    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {

    }



    function zenInitAudioPlayer() {

        var players = $('audio.zen-blog-audio');

        players.mediaelementplayer({
            audioWidth: '100%'
        });
    }


    /**
     * Init Blog Slider shortcode
     */
    function zenInitBlogSlider() {

        var sliderHolders = $('.zen-blog-slider-holder'),
            slider;

        if (sliderHolders.length) {
            sliderHolders.each(function(){
                slider = $(this).children('.zen-blog-slider');

                slider.owlCarousel({
                    autoPlay: 3000,
                    singleItem: true,
                    pagination: false,
                    navigation: true,
                    slideSpeed: 600,
                    mouseDrag: false,
                    transitionStyle: 'backSlide',
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i></span>'
                    ]
                });

            });
        }

    }

    /**
     * Initializes blog navigation arrows
     */
    function zenInitBlogSingleArrows() {
        if($('.zen-blog-single-navigation').length) {

            var button = $('.zen-blog-single-prev a, .zen-blog-single-next a');

            button.addClass('zen-btn-visible');

            button.each(function() {
                var button = $(this);
                var buttonArrowTextWidth = parseInt(button.find('.zen-btn-text').width());
                var buttonArrowIconWidth = parseInt(button.find('.zen-btn-icon-arrow').width());
                var buttonWidth;

                buttonWidth = buttonArrowIconWidth + buttonArrowTextWidth + 15; //15 empty space between arrow and text
                var textPadding = buttonArrowIconWidth;

                button.css('width', buttonWidth + 'px');
                if(button.parent().hasClass('zen-blog-single-next')) {
                    button.find('.zen-btn-text').css({'padding-left': textPadding + 15 + 'px'}); //15 empty space between arrow and text
                } else {
                    button.find('.zen-btn-text').css({'padding-right': textPadding + 15 + 'px'}); //15 empty space between arrow and text
                }

                button.mouseenter(function() {
                    if(button.parent().hasClass('zen-blog-single-next')) {
                        button.find('.zen-btn-text').css({'-webkit-transform': 'translateX(' + buttonArrowTextWidth + 'px)'});
                        button.find('.zen-btn-text').css({'transform': 'translateX(' + buttonArrowTextWidth + 'px)'});
                    } else {
                        button.find('.zen-btn-text').css({'-webkit-transform': 'translateX(' + -buttonArrowTextWidth + 'px)'});
                        button.find('.zen-btn-text').css({'transform': 'translateX(' + -buttonArrowTextWidth + 'px)'});
                    }
                });
                button.mouseleave(function() {
                    button.find('.zen-btn-text').css({'-webkit-transform': 'translateX(0px)'});
                    button.find('.zen-btn-text').css({'transform': 'translateX(0px)'});
                });
            });

        }
    }

})(jQuery);