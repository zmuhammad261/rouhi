(function($) {
    "use strict";

    var header = {};
    zen.modules.header = header;

    header.isStickyVisible = false;
    header.stickyAppearAmount = 0;
    header.behaviour;
    header.zenFullscreenMenu = zenFullscreenMenu;
    header.zenInitMobileNavigation = zenInitMobileNavigation;
    header.zenMobileHeaderBehavior = zenMobileHeaderBehavior;
    header.zenSetMenuWidthForCenteredLogoHeader = zenSetMenuWidthForCenteredLogoHeader;
    header.zenSetDropDownMenuPosition = zenSetDropDownMenuPosition;
    header.zenDropDownMenu = zenDropDownMenu;
    header.zenSearch = zenSearch;

    header.zenOnDocumentReady = zenOnDocumentReady;
    header.zenOnWindowLoad = zenOnWindowLoad;
    header.zenOnWindowResize = zenOnWindowResize;
    header.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenHeaderBehaviour();
        zenFullscreenMenu();
        zenInitMobileNavigation();
        zenMobileHeaderBehavior();
        zenSetDropDownMenuPosition();
        zenDropDownMenu();
        zenSearch();
        zenVerticalMenu().init();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {
        zenSetMenuWidthForCenteredLogoHeader();
        zenSetDropDownMenuPosition();
    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
        zenDropDownMenu();
        zenSetMenuWidthForCenteredLogoHeader();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {
        
    }



    /*
     **	Show/Hide sticky header on window scroll
     */
    function zenHeaderBehaviour() {

        var header = $('.zen-page-header');
        var stickyHeader = $('.zen-sticky-header');

        var stickyAppearAmount;

        switch(true) {
            // sticky header that will be shown when user scrolls up
            case zen.body.hasClass('zen-sticky-header-on-scroll-up'):
                zen.modules.header.behaviour = 'zen-sticky-header-on-scroll-up';
                var docYScroll1 = $(document).scrollTop();
                stickyAppearAmount = zenGlobalVars.vars.zenTopBarHeight + zenGlobalVars.vars.zenLogoAreaHeight + zenGlobalVars.vars.zenMenuAreaHeight + zenGlobalVars.vars.zenStickyHeaderHeight + 400; //400 is designer's whish

                var headerAppear = function(){
                    var docYScroll2 = $(document).scrollTop();

                    if((docYScroll2 > docYScroll1 && docYScroll2 > stickyAppearAmount) || (docYScroll2 < stickyAppearAmount)) {
                        zen.modules.header.isStickyVisible= false;
                        stickyHeader.removeClass('header-appear').find('.zen-main-menu .second').removeClass('zen-drop-down-start');
                    }else {
                        zen.modules.header.isStickyVisible = true;
                        stickyHeader.addClass('header-appear');
                    }

                    docYScroll1 = $(document).scrollTop();
                };
                headerAppear();

                $(window).scroll(function() {
                    headerAppear();
                });

                break;

            // sticky header that will be shown when user scrolls both up and down
            case zen.body.hasClass('zen-sticky-header-on-scroll-down-up'):
                zen.modules.header.behaviour = 'zen-sticky-header-on-scroll-down-up';
                stickyAppearAmount = zenPerPageVars.vars.zenStickyScrollAmount !== 0 ? zenPerPageVars.vars.zenStickyScrollAmount : zenGlobalVars.vars.zenTopBarHeight + zenGlobalVars.vars.zenLogoAreaHeight + zenGlobalVars.vars.zenMenuAreaHeight;
                zen.modules.header.stickyAppearAmount = stickyAppearAmount; //used in anchor logic
                
                var headerAppear = function(){
                    if(zen.scroll < stickyAppearAmount) {
                        zen.modules.header.isStickyVisible = false;
                        stickyHeader.removeClass('header-appear').find('.zen-main-menu .second').removeClass('zen-drop-down-start');
                    }else{
                        zen.modules.header.isStickyVisible = true;
                        stickyHeader.addClass('header-appear');
                    }
                };

                headerAppear();

                $(window).scroll(function() {
                    headerAppear();
                });

                break;

        }
    }

    function zenSetMenuWidthForCenteredLogoHeader(){
        if(zen.body.hasClass('zen-header-centered-logo')){
            //get left side menu width

            var menuAreaLeftSideWidth =  Math.round($('.zen-menu-area').width()/2 - $('.zen-menu-area .zen-position-left .widget').width() - $('.zen-menu-area .zen-logo-wrapper').width()/2);
            $('.zen-menu-area .zen-position-left .zen-main-menu').width(menuAreaLeftSideWidth);

            var stickyHeaderLeftSideWidth =  Math.round($('.zen-sticky-header .zen-vertical-align-containers').width()/2 - $('.zen-sticky-header .zen-position-left .widget').width() - $('.zen-sticky-header .zen-logo-wrapper').width()/2);
            $('.zen-sticky-header .zen-position-left .zen-main-menu').width(stickyHeaderLeftSideWidth);

            //get right side menu width
            var menuAreaRightSideWidth =  Math.round($('.zen-menu-area').width()/2 - $('.zen-menu-area .zen-position-right .widget').width() - $('.zen-menu-area .zen-logo-wrapper').width()/2);
            $('.zen-menu-area .zen-position-right .zen-main-menu').width(menuAreaRightSideWidth);

            var stickyHeaderRightSideWidth =  Math.round($('.zen-sticky-header .zen-vertical-align-containers').width()/2 - $('.zen-sticky-header .zen-position-right .widget').width() - $('.zen-sticky-header .zen-logo-wrapper').width()/2);
            $('.zen-sticky-header .zen-position-right .zen-main-menu').width(stickyHeaderRightSideWidth);

            $('.zen-main-menu').css('opacity',1);

            zenSetDropDownMenuPosition();
        }
    }

    /**
     * Init Fullscreen Menu
     */
    function zenFullscreenMenu() {

        if ($('a.zen-fullscreen-menu-opener').length) {

            var popupMenuOpener = $( 'a.zen-fullscreen-menu-opener'),
                popupMenuHolderOuter = $(".zen-fullscreen-menu-holder-outer"),
                cssClass,
            //Flags for type of animation
                fadeRight = false,
                fadeTop = false,
            //Widgets
                widgetAboveNav = $('.zen-fullscreen-above-menu-widget-holder'),
                widgetBelowNav = $('.zen-fullscreen-below-menu-widget-holder'),
            //Menu
                menuItems = $('.zen-fullscreen-menu-holder-outer nav > ul > li > a'),
                menuItemWithChild =  $('.zen-fullscreen-menu > ul li.has_sub > a'),
                menuItemWithoutChild = $('.zen-fullscreen-menu ul li:not(.has_sub) a');


            //set height of popup holder and initialize nicescroll
            popupMenuHolderOuter.height(zen.windowHeight).niceScroll({
                scrollspeed: 30,
                mousescrollstep: 20,
                cursorwidth: 0,
                cursorborder: 0,
                cursorborderradius: 0,
                cursorcolor: "transparent",
                autohidemode: false,
                horizrailenabled: false
            }); //200 is top and bottom padding of holder

            //set height of popup holder on resize
            $(window).resize(function() {
                popupMenuHolderOuter.height(zen.windowHeight);
            });

            if (zen.body.hasClass('zen-fade-push-text-right')) {
                cssClass = 'zen-push-nav-right';
                fadeRight = true;
            } else if (zen.body.hasClass('zen-fade-push-text-top')) {
                cssClass = 'zen-push-text-top';
                fadeTop = true;
            }

            //Appearing animation
            if (fadeRight || fadeTop) {
                if (widgetAboveNav.length) {
                    widgetAboveNav.children().css({
                        '-webkit-animation-delay' : 0 + 'ms',
                        '-moz-animation-delay' : 0 + 'ms',
                        'animation-delay' : 0 + 'ms'
                    });
                }
                menuItems.each(function(i) {
                    $(this).css({
                        '-webkit-animation-delay': (i+1) * 70 + 'ms',
                        '-moz-animation-delay': (i+1) * 70 + 'ms',
                        'animation-delay': (i+1) * 70 + 'ms'
                    });
                });
                if (widgetBelowNav.length) {
                    widgetBelowNav.children().css({
                        '-webkit-animation-delay' : (menuItems.length + 1)*70 + 'ms',
                        '-moz-animation-delay' : (menuItems.length + 1)*70 + 'ms',
                        'animation-delay' : (menuItems.length + 1)*70 + 'ms'
                    });
                }
            }

            // Open popup menu
            popupMenuOpener.on('click',function(e){
                e.preventDefault();

                if (!popupMenuOpener.hasClass('opened')) {
                    popupMenuOpener.addClass('opened');
                    zen.body.addClass('zen-fullscreen-menu-opened');
                    zen.body.removeClass('zen-fullscreen-fade-out').addClass('zen-fullscreen-fade-in');
                    zen.body.removeClass(cssClass);
                    if(!zen.body.hasClass('page-template-full_screen-php')){
                        zen.modules.common.zenDisableScroll();
                    }
                    $(document).keyup(function(e){
                        if (e.keyCode == 27 ) {
                            popupMenuOpener.removeClass('opened');
                            zen.body.removeClass('zen-fullscreen-menu-opened');
                            zen.body.removeClass('zen-fullscreen-fade-in').addClass('zen-fullscreen-fade-out');
                            zen.body.addClass(cssClass);
                            if(!zen.body.hasClass('page-template-full_screen-php')){
                                zen.modules.common.zenEnableScroll();
                            }
                            $("nav.zen-fullscreen-menu ul.sub_menu").slideUp(200, function(){
                                $('nav.popup_menu').getNiceScroll().resize();
                            });
                        }
                    });
                } else {
                    popupMenuOpener.removeClass('opened');
                    zen.body.removeClass('zen-fullscreen-menu-opened');
                    zen.body.removeClass('zen-fullscreen-fade-in').addClass('zen-fullscreen-fade-out');
                    zen.body.addClass(cssClass);
                    if(!zen.body.hasClass('page-template-full_screen-php')){
                        zen.modules.common.zenEnableScroll();
                    }
                    $("nav.zen-fullscreen-menu ul.sub_menu").slideUp(200, function(){
                        $('nav.popup_menu').getNiceScroll().resize();
                    });
                }
            });

            //logic for open sub menus in popup menu
            menuItemWithChild.on('tap click', function(e) {
                e.preventDefault();

                if ($(this).parent().hasClass('has_sub')) {
                    var submenu = $(this).parent().find('> ul.sub_menu');
                    if (submenu.is(':visible')) {
                        submenu.slideUp(200, function() {
                            popupMenuHolderOuter.getNiceScroll().resize();
                        });
                        $(this).parent().removeClass('open_sub');
                    } else {
                        $(this).parent().addClass('open_sub');
                        submenu.slideDown(200, function() {
                            popupMenuHolderOuter.getNiceScroll().resize();
                        });
                    }
                }
                return false;
            });

            //if link has no submenu and if it's not dead, than open that link
            menuItemWithoutChild.click(function (e) {

                if(($(this).attr('href') !== "http://#") && ($(this).attr('href') !== "#")){

                    if (e.which == 1) {
                        popupMenuOpener.removeClass('opened');
                        zen.body.removeClass('zen-fullscreen-menu-opened');
                        zen.body.removeClass('zen-fullscreen-fade-in').addClass('zen-fullscreen-fade-out');
                        zen.body.addClass(cssClass);
                        $("nav.zen-fullscreen-menu ul.sub_menu").slideUp(200, function(){
                            $('nav.popup_menu').getNiceScroll().resize();
                        });
                        zen.modules.common.zenEnableScroll();
                    }
                }else{
                    return false;
                }

            });

        }



    }

    function zenInitMobileNavigation() {
        var navigationOpener = $('.zen-mobile-header .zen-mobile-menu-opener');
        var navigationHolder = $('.zen-mobile-header .zen-mobile-nav');
        var dropdownOpener = $('.zen-mobile-nav .mobile_arrow, .zen-mobile-nav h4, .zen-mobile-nav a[href*="#"]');
        var animationSpeed = 200;

        //whole mobile menu opening / closing
        if(navigationOpener.length && navigationHolder.length) {
            navigationOpener.on('tap click', function(e) {
                e.stopPropagation();
                e.preventDefault();

                if(navigationHolder.is(':visible')) {
                    navigationOpener.removeClass('opened');
                    navigationHolder.slideUp(animationSpeed);
                } else {
                    navigationOpener.addClass('opened');
                    navigationHolder.slideDown(animationSpeed);
                }
            });
        }

        //dropdown opening / closing
        if(dropdownOpener.length) {
            dropdownOpener.each(function() {
                $(this).on('tap click', function(e) {
                    var dropdownToOpen = $(this).nextAll('ul').first();

                    if(dropdownToOpen.length) {
                        e.preventDefault();
                        e.stopPropagation();

                        var openerParent = $(this).parent('li');
                        if(dropdownToOpen.is(':visible')) {
                            dropdownToOpen.slideUp(animationSpeed);
                            openerParent.removeClass('zen-opened');
                        } else {
                            dropdownToOpen.slideDown(animationSpeed);
                            openerParent.addClass('zen-opened');
                        }
                    }

                });
            });
        }

        $('.zen-mobile-nav a, .zen-mobile-logo-wrapper a').on('click tap', function(e) {
            if($(this).attr('href') !== 'http://#' && $(this).attr('href') !== '#') {
                navigationHolder.slideUp(animationSpeed);
            }
        });
    }

    function zenMobileHeaderBehavior() {
        if(zen.body.hasClass('zen-sticky-up-mobile-header')) {
            var stickyAppearAmount;
            var mobileHeader = $('.zen-mobile-header');
            var adminBar     = $('#wpadminbar');
            var mobileHeaderHeight = mobileHeader.length ? mobileHeader.height() : 0;
            var adminBarHeight = adminBar.length ? adminBar.height() : 0;

            var docYScroll1 = $(document).scrollTop();
            stickyAppearAmount = mobileHeaderHeight + adminBarHeight;

            $(window).scroll(function() {
                var docYScroll2 = $(document).scrollTop();

                if(docYScroll2 > stickyAppearAmount) {
                    mobileHeader.addClass('zen-animate-mobile-header');
                } else {
                    mobileHeader.removeClass('zen-animate-mobile-header');
                }

                if((docYScroll2 > docYScroll1 && docYScroll2 > stickyAppearAmount) || (docYScroll2 < stickyAppearAmount)) {
                    mobileHeader.removeClass('mobile-header-appear');
                    mobileHeader.css('margin-bottom', 0);

                    if(adminBar.length) {
                        mobileHeader.find('.zen-mobile-header-inner').css('top', 0);
                    }
                } else {
                    mobileHeader.addClass('mobile-header-appear');
                    mobileHeader.css('margin-bottom', stickyAppearAmount);

                    //if(adminBar.length) {
                    //    mobileHeader.find('.zen-mobile-header-inner').css('top', adminBarHeight);
                    //}
                }

                docYScroll1 = $(document).scrollTop();
            });
        }

    }


    /**
     * Set dropdown position
     */
    function zenSetDropDownMenuPosition(){

        var menuItems = $(".zen-drop-down > ul > li.narrow");
        menuItems.each( function() {

            var browserWidth = zen.windowWidth;
            var menuItemPosition = $(this).offset().left;
            var dropdownMenuWidth = $(this).find('.second .inner ul').width();

            var menuItemFromLeft = 0;
            if(zen.body.hasClass('boxed')){
                menuItemFromLeft = zen.boxedLayoutWidth  - (menuItemPosition - (browserWidth - zen.boxedLayoutWidth )/2);
            } else {
                menuItemFromLeft = browserWidth - menuItemPosition;
            }

            var dropDownMenuFromLeft; //has to stay undefined beacuse 'dropDownMenuFromLeft < dropdownMenuWidth' condition will be true

            if($(this).find('li.sub').length > 0){
                dropDownMenuFromLeft = menuItemFromLeft - dropdownMenuWidth;
            }

            if(menuItemFromLeft < dropdownMenuWidth || dropDownMenuFromLeft < dropdownMenuWidth){
                $(this).find('.second').addClass('right');
                $(this).find('.second .inner ul').addClass('right');
            }
        });

    }


    function zenDropDownMenu() {

        var menu_items = $('.zen-drop-down > ul > li');

        menu_items.each(function(i) {
            if($(menu_items[i]).find('.second').length > 0) {

                var dropDownSecondDiv = $(menu_items[i]).find('.second');

                if($(menu_items[i]).hasClass('wide')) {

                    var dropdown = $(this).find('.inner > ul');
                    var dropdownPadding = parseInt(dropdown.css('padding-left').slice(0, -2)) + parseInt(dropdown.css('padding-right').slice(0, -2));
                    var dropdownWidth = dropdown.outerWidth();

                    if(!$(this).hasClass('left_position') && !$(this).hasClass('right_position')) {
                        dropDownSecondDiv.css('left', 0);
                    }

                    //set columns to be same height - start
                    var tallest = 0;
                    $(this).find('.second > .inner > ul > li').each(function() {
                        var thisHeight = $(this).height();
                        if(thisHeight > tallest) {
                            tallest = thisHeight;
                        }
                    });
                    $(this).find('.second > .inner > ul > li').css("height", ""); // delete old inline css - via resize
                    $(this).find('.second > .inner > ul > li').height(tallest);
                    //set columns to be same height - end

                    if(!$(this).hasClass('wide_background')) {
                        if(!$(this).hasClass('left_position') && !$(this).hasClass('right_position')) {
                            var left_position = (zen.windowWidth - 2 * (zen.windowWidth - dropdown.offset().left)) / 2 + (dropdownWidth + dropdownPadding) / 2;
                            dropDownSecondDiv.css('left', -left_position);
                        }
                    } else {
                        if(!$(this).hasClass('left_position') && !$(this).hasClass('right_position')) {
                            var left_position = dropdown.offset().left;

                            dropDownSecondDiv.css('left', -left_position);
                            dropDownSecondDiv.css('width', zen.windowWidth);

                        }
                    }
                }

                if(!zen.menuDropdownHeightSet) {
                    $(menu_items[i]).data('original_height', dropDownSecondDiv.height() + 'px');
                    dropDownSecondDiv.height(0);
                }

                if(navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
                    $(menu_items[i]).on("touchstart mouseenter", function() {
                        dropDownSecondDiv.css({
                            'height': $(menu_items[i]).data('original_height'),
                            'overflow': 'visible',
                            'visibility': 'visible',
                            'opacity': '1'
                        });
                    }).on("mouseleave", function() {
                        dropDownSecondDiv.css({
                            'height': '0px',
                            'overflow': 'hidden',
                            'visibility': 'hidden',
                            'opacity': '0'
                        });
                    });

                } else {
                    if(zen.body.hasClass('zen-dropdown-animate-height')) {
                        $(menu_items[i]).mouseenter(function() {
                            dropDownSecondDiv.css({
                                'visibility': 'visible',
                                'height': '0px',
                                'opacity': '0'
                            });
                            dropDownSecondDiv.stop().animate({
                                'height': $(menu_items[i]).data('original_height'),
                                opacity: 1
                            }, 200, function() {
                                dropDownSecondDiv.css('overflow', 'visible');
                            });
                        }).mouseleave(function() {
                            dropDownSecondDiv.stop().animate({
                                'height': '0px'
                            }, 0, function() {
                                dropDownSecondDiv.css({
                                    'overflow': 'hidden',
                                    'visibility': 'hidden'
                                });
                            });
                        });
                    } else {
                        var config = {
                            interval: 0,
                            over: function() {
                                setTimeout(function() {
                                    dropDownSecondDiv.addClass('zen-drop-down-start');
                                    dropDownSecondDiv.stop().css({'height': $(menu_items[i]).data('original_height')});
                                }, 150);
                            },
                            timeout: 150,
                            out: function() {
                                dropDownSecondDiv.stop().css({'height': '0px'});
                                dropDownSecondDiv.removeClass('zen-drop-down-start');
                            }
                        };
                        $(menu_items[i]).hoverIntent(config);
                    }
                }
            }
        });
        $('.zen-drop-down ul li.wide ul li a').on('click', function() {
            var $this = $(this);
            setTimeout(function() {
                $this.mouseleave();
            }, 500);

        });

        //tracker initialization and movement logic
        $('.zen-main-menu .narrow ul').append('<li class="tracker left"></li><li class="tracker right"></li>');

        $('.zen-main-menu .narrow ul li a').hover(function(){
            var linkPos = $(this).parent().position().top + $(this).parent().height()/2 - 6; //
            $(this).parent().siblings('.tracker').stop().animate({top:linkPos+'px',opacity:0.99},150, 'easeOutBack');

        },function(){
            $(this).parent().siblings('.tracker').stop().animate({opacity:0},150);
        });

        zen.menuDropdownHeightSet = true;
    }

    /**
     * Init Search Types
     */
    function zenSearch() {

        var searchOpener = $('a.zen-search-opener'),
            searchClose,
            touch = false;

        if ( $('html').hasClass( 'touch' ) ) {
            touch = true;
        }

        if ( searchOpener.length > 0 ) {
            //Check for type of search

            var fullscreenSearchFade = false,
                fullscreenSearchFromCircle = false;

            searchClose = $( '.zen-fullscreen-search-close' );

            if (zen.body.hasClass('zen-search-fade')) {
                fullscreenSearchFade = true;
            } else if (zen.body.hasClass('zen-search-from-circle')) {
                fullscreenSearchFromCircle = true;
            }
            zenFullscreenSearch( fullscreenSearchFade, fullscreenSearchFromCircle );


            //Check for hover color of search
            if(typeof searchOpener.data('hover-color') !== 'undefined') {
                var changeSearchColor = function(event) {
                    event.data.searchOpener.css('color', event.data.color);
                };

                var originalColor = searchOpener.css('color');
                var hoverColor = searchOpener.data('hover-color');

                searchOpener.on('mouseenter', { searchOpener: searchOpener, color: hoverColor }, changeSearchColor);
                searchOpener.on('mouseleave', { searchOpener: searchOpener, color: originalColor }, changeSearchColor);
            }

        }


        /**
         * Fullscreen search (two types: fade and from circle)
         */
        function zenFullscreenSearch( fade, fromCircle ) {

            var searchHolder = $( '.zen-fullscreen-search-holder'),
                searchOverlay = $( '.zen-fullscreen-search-overlay' ),
                searchField = searchHolder.find('.zen-search-field'),
                searchLine = searchHolder.find('.zen-line');

            searchOpener.click( function(e) {
                e.preventDefault();
                var samePosition = false;
                if ( $(this).data('icon-close-same-position') === 'yes' ) {
                    var closeTop = $(this).offset().top;
                    var closeLeft = $(this).offset().left;
                    samePosition = true;
                }
                //Fullscreen search fade
                if ( fade ) {
                    if ( searchHolder.hasClass( 'zen-animate' ) ) {
                        zen.body.removeClass('zen-fullscreen-search-opened');
                        zen.body.addClass( 'zen-search-fade-out' );
                        zen.body.removeClass( 'zen-search-fade-in' );
                        searchHolder.removeClass( 'zen-animate' );
                        searchField.blur();
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenEnableScroll();
                        }
                    } else {
                        zen.body.addClass('zen-fullscreen-search-opened');
                        zen.body.removeClass('zen-search-fade-out');
                        zen.body.addClass('zen-search-fade-in');
                        searchHolder.addClass('zen-animate');
                        if (samePosition) {
                            searchClose.css({
                                'top' : closeTop - zen.scroll, // Distance from top of viewport ( distance from top of window - scroll distance )
                                'left' : closeLeft
                            });
                        }
						setTimeout(function(){
							searchField.focus();
						},400);
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenDisableScroll();
                        }
                    }
                    searchClose.click( function(e) {
                        e.preventDefault();
                        zen.body.removeClass('zen-fullscreen-search-opened');
                        searchHolder.removeClass('zen-animate');
                        zen.body.removeClass('zen-search-fade-in');
                        zen.body.addClass('zen-search-fade-out');
                        searchHolder.find('input').blur();
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenEnableScroll();
                        }
                    });
                    //Close on escape
                    $(document).keyup(function(e){
                        if (e.keyCode == 27 ) { //KeyCode for ESC button is 27
                            zen.body.removeClass('zen-fullscreen-search-opened');
                            searchHolder.removeClass('zen-animate');
                            zen.body.removeClass('zen-search-fade-in');
                            zen.body.addClass('zen-search-fade-out');
	                        searchField.blur();
                            if(!zen.body.hasClass('page-template-full_screen-php')){
                                zen.modules.common.zenEnableScroll();
                            }
                        }
                    });
                }
                //Fullscreen search from circle
                if ( fromCircle ) {
                    if( searchOverlay.hasClass('zen-animate') ) {
                        searchOverlay.removeClass('zen-animate');
                        searchHolder.css({
                            'opacity': 0,
                            'display':'none'
                        });
                        searchClose.css({
                            'opacity' : 0,
                            'visibility' : 'hidden'
                        });
                        searchOpener.css({
                            'opacity': 1
                        });
                        searchField.blur();
                    } else {
                        searchOverlay.addClass('zen-animate');
                        searchHolder.css({
                            'display':'block'
                        });
                        searchField.focus();
                        setTimeout(function(){
                            searchHolder.css('opacity','1');
                            searchClose.css({
                                'opacity' : 1,
                                'visibility' : 'visible',
                                'top' : closeTop - zen.scroll, // Distance from top of viewport ( distance from top of window - scroll distance )
                                'left' : closeLeft
                            });
                            if (samePosition) {
                                searchClose.css({
                                    'top' : closeTop - zen.scroll, // Distance from top of viewport ( distance from top of window - scroll distance )
                                    'left' : closeLeft
                                });
                            }
                            searchOpener.css({
                                'opacity' : 0
                            });
                        },200);
						setTimeout(function(){
							searchField.focus();
						},400);
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenDisableScroll();
                        }
                    }
                    searchClose.click(function(e) {
                        e.preventDefault();
                        searchOverlay.removeClass('zen-animate');
                        searchHolder.css({
                            'opacity' : 0,
                            'display' : 'none'
                        });
                        searchClose.css({
                            'opacity':0,
                            'visibility' : 'hidden'
                        });
                        searchOpener.css({
                            'opacity' : 1
                        });
                        searchField.blur();
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenEnableScroll();
                        }
                    });
                    //Close on escape
                    $(document).keyup(function(e){
                        if (e.keyCode == 27 ) { //KeyCode for ESC button is 27
                            searchOverlay.removeClass('zen-animate');
                            searchHolder.css({
                                'opacity' : 0,
                                'display' : 'none'
                            });
                            searchClose.css({
                                'opacity':0,
                                'visibility' : 'hidden'
                            });
                            searchOpener.css({
                                'opacity' : 1
                            });
                            if(!zen.body.hasClass('page-template-full_screen-php')){
                                zen.modules.common.zenEnableScroll();
                            }
                        }
                    });
                }
            });

            //Text input focus change
            searchField.focus(function(){
                searchLine.css("width","100%");
            });

            searchField.blur(function(){
                searchLine.css("width","0");
            });

        }

    }

    /**
     * Function object that represents vertical menu area.
     * @returns {{init: Function}}
     */
    var zenVerticalMenu = function() {
        /**
         * Main vertical area object that used through out function
         * @type {jQuery object}
         */
        var verticalMenuObject = $('.zen-vertical-menu-area');

        /**
         * Resizes vertical area. Called whenever height of navigation area changes
         * It first check if vertical area is scrollable, and if it is resizes scrollable area
         */
        //var resizeVerticalArea = function() {
        //    if(verticalAreaScrollable()) {
        //        verticalMenuObject.getNiceScroll().resize();
        //    }
        //};

        /**
         * Checks if vertical area is scrollable (if it has zen-with-scroll class)
         *
         * @returns {bool}
         */
        //var verticalAreaScrollable = function() {
        //    return verticalMenuObject.hasClass('.zen-with-scroll');
        //};

        /**
         * Initialzes navigation functionality. It checks navigation type data attribute and calls proper functions
         */
        var initNavigation = function() {
            var verticalNavObject = verticalMenuObject.find('.zen-vertical-menu');
            var navigationType = typeof verticalNavObject.data('navigation-type') !== 'undefined' ? verticalNavObject.data('navigation-type') : '';

            switch(navigationType) {
                //case 'dropdown-toggle':
                //    dropdownHoverToggle();
                //    break;
                //case 'dropdown-toggle-click':
                //    dropdownClickToggle();
                //    break;
                //case 'float':
                //    dropdownFloat();
                //    break;
                //case 'slide-in':
                //    dropdownSlideIn();
                //    break;
                default:
                    dropdownFloat();
                    break;
            }

            /**
             * Initializes hover toggle navigation type. It has separate functionalities for touch and no-touch devices
             */
            //function dropdownHoverToggle() {
            //    var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
            //
            //    menuItems.each(function() {
            //        var elementToExpand = $(this).find(' > .second, > ul');
            //        var numberOfChildItems = elementToExpand.find(' > .inner > ul > li, > li').length;
            //
            //        var animSpeed = numberOfChildItems * 40;
            //        var animFunc = 'easeInOutSine';
            //        var that = this;
            //
            //        //touch devices functionality
            //        if(Modernizr.touch) {
            //            var dropdownOpener = $(this).find('> a');
            //
            //            dropdownOpener.on('click tap', function(e) {
            //                e.preventDefault();
            //                e.stopPropagation();
            //
            //                if(elementToExpand.is(':visible')) {
            //                    $(that).removeClass('open');
            //                    elementToExpand.slideUp(animSpeed, animFunc, function() {
            //                        resizeVerticalArea();
            //                    });
            //                } else {
            //                    $(that).addClass('open');
            //                    elementToExpand.slideDown(animSpeed, animFunc, function() {
            //                        resizeVerticalArea();
            //                    });
            //                }
            //            });
            //        } else {
            //            $(this).hover(function() {
            //                $(that).addClass('open');
            //                elementToExpand.slideDown(animSpeed, animFunc, function() {
            //                    resizeVerticalArea();
            //                });
            //            }, function() {
            //                setTimeout(function() {
            //                    $(that).removeClass('open');
            //                    elementToExpand.slideUp(animSpeed, animFunc, function() {
            //                        resizeVerticalArea();
            //                    });
            //                }, 1000);
            //            });
            //        }
            //    });
            //}

            /**
             * Initializes click toggle navigation type. Works the same for touch and no-touch devices
             */
            //function dropdownClickToggle() {
            //    var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
            //
            //    menuItems.each(function() {
            //        var elementToExpand = $(this).find(' > .second, > ul');
            //        var menuItem = this;
            //        var dropdownOpener = $(this).find('> a');
            //        var slideUpSpeed = 'fast';
            //        var slideDownSpeed = 'slow';
            //
            //        dropdownOpener.on('click tap', function(e) {
            //            e.preventDefault();
            //            e.stopPropagation();
            //
            //            if(elementToExpand.is(':visible')) {
            //                $(menuItem).removeClass('open');
            //                elementToExpand.slideUp(slideUpSpeed, function() {
            //                    resizeVerticalArea();
            //                });
            //            } else {
            //                if(!$(this).parents('li').hasClass('open')) {
            //                    menuItems.removeClass('open');
            //                    menuItems.find(' > .second, > ul').slideUp(slideUpSpeed);
            //                }
            //
            //                $(menuItem).addClass('open');
            //                elementToExpand.slideDown(slideDownSpeed, function() {
            //                    resizeVerticalArea();
            //                });
            //            }
            //        });
            //    });
            //}

            /**
             * Initializes floating navigation type (it comes from the side as a dropdown)
             */
            function dropdownFloat() {
                var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
                var allDropdowns = menuItems.find(' > .second, > ul');

                menuItems.each(function() {
                    var elementToExpand = $(this).find(' > .second, > ul');
                    var menuItem = this;

                    if(Modernizr.touch) {
                        var dropdownOpener = $(this).find('> a');

                        dropdownOpener.on('click tap', function(e) {
                            e.preventDefault();
                            e.stopPropagation();

                            if(elementToExpand.hasClass('zen-float-open')) {
                                elementToExpand.removeClass('zen-float-open');
                                $(menuItem).removeClass('open');
                            } else {
                                if(!$(this).parents('li').hasClass('open')) {
                                    menuItems.removeClass('open');
                                    allDropdowns.removeClass('zen-float-open');
                                }

                                elementToExpand.addClass('zen-float-open');
                                $(menuItem).addClass('open');
                            }
                        });
                    } else {
                        //must use hoverIntent because basic hover effect doesn't catch dropdown
                        //it doesn't start from menu item's edge
                        $(this).hoverIntent({
                            over: function() {
                                elementToExpand.addClass('zen-float-open');
                                $(menuItem).addClass('open');
                            },
                            out: function() {
                                elementToExpand.removeClass('zen-float-open');
                                $(menuItem).removeClass('open');
                            },
                            timeout: 300
                        });
                    }
                });
            }

            /**
             * Initializes slide in navigation type (dropdowns are coming on top of parent element and cover whole navigation area)
             */
            //function dropdownSlideIn() {
            //    var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
            //    var menuItemsLinks = menuItems.find('> a');
            //
            //    menuItemsLinks.each(function() {
            //        var elementToExpand = $(this).next('.second, ul');
            //        appendToExpandableElement(elementToExpand, this);
            //
            //        if($(this).parent('li').is('.current-menu-ancestor', '.current_page_parent', '.current-menu-parent ')) {
            //            elementToExpand.addClass('zen-vertical-slide-open');
            //        }
            //
            //        $(this).on('click tap', function(e) {
            //            e.preventDefault();
            //            e.stopPropagation();
            //
            //            menuItems.removeClass('open');
            //
            //            $(this).parent('li').addClass('open');
            //            elementToExpand.addClass('zen-vertical-slide-open');
            //        });
            //    });
            //
            //    var previousLevelItems = menuItems.find('li.zen-previous-level > a');
            //
            //    previousLevelItems.on('click tap', function(e) {
            //        e.preventDefault();
            //        e.stopPropagation();
            //
            //        menuItems.removeClass('open');
            //        $(this).parents('.zen-vertical-slide-open').first().removeClass('zen-vertical-slide-open');
            //    });
            //
            //    /**
            //     * Appends 'li' element as first element in dropdown, which will close current dropdown when clicked
            //     * @param {jQuery object} elementToExpand current dropdown to append element to
            //     * @param currentMenuItem
            //     */
            //    function appendToExpandableElement(elementToExpand, currentMenuItem) {
            //        var itemUrl = $(currentMenuItem).attr('href');
            //        var itemText = $(currentMenuItem).text();
            //
            //        var liItem = $('<li />', {class: 'zen-previous-level'});
            //
            //        $('<a />', {
            //            'href': itemUrl,
            //            'html': '<i class="zen-vertical-slide-arrow fa fa-angle-left"></i>' + itemText
            //        }).appendTo(liItem);
            //
            //        if(elementToExpand.hasClass('second')) {
            //            elementToExpand.find('> div > ul').prepend(liItem);
            //        } else {
            //            elementToExpand.prepend(liItem);
            //        }
            //    }
            //}
        };

        /**
         * Initializes scrolling in vertical area. It checks if vertical area is scrollable before doing so
         */
        //var initVerticalAreaScroll = function() {
        //    if(verticalAreaScrollable()) {
        //        verticalMenuObject.niceScroll({
        //            scrollspeed: 60,
        //            mousescrollstep: 40,
        //            cursorwidth: 0,
        //            cursorborder: 0,
        //            cursorborderradius: 0,
        //            cursorcolor: "transparent",
        //            autohidemode: false,
        //            horizrailenabled: false
        //        });
        //    }
        //};

        //var initHiddenVerticalArea = function() {
        //    var verticalLogo = $('.zen-vertical-area-bottom-logo');
        //    var verticalMenuOpener = verticalMenuObject.find('.zen-vertical-menu-hidden-button');
        //    var scrollPosition = 0;
        //
        //    verticalMenuOpener.on('click tap', function() {
        //        if(isVerticalAreaOpen()) {
        //            closeVerticalArea();
        //        } else {
        //            openVerticalArea();
        //        }
        //    });
        //
        //    //take click outside vertical left/right area and close it
        //    $j(verticalMenuObject).outclick({
        //        callback: function() {
        //            closeVerticalArea();
        //        }
        //    });
        //
        //    $(window).scroll(function() {
        //        if(Math.abs($(window).scrollTop() - scrollPosition) > 400){
        //            closeVerticalArea();
        //        }
        //    });
        //
        //    /**
        //     * Closes vertical menu area by removing 'active' class on that element
        //     */
        //    function closeVerticalArea() {
        //        verticalMenuObject.removeClass('active');
        //
        //        if(verticalLogo.length) {
        //            verticalLogo.removeClass('active');
        //        }
        //    }
        //
        //    /**
        //     * Opens vertical menu area by adding 'active' class on that element
        //     */
        //    function openVerticalArea() {
        //        verticalMenuObject.addClass('active');
        //
        //        if(verticalLogo.length) {
        //            verticalLogo.addClass('active');
        //        }
        //
        //        scrollPosition = $(window).scrollTop();
        //    }
        //
        //    function isVerticalAreaOpen() {
        //        return verticalMenuObject.hasClass('active');
        //    }
        //};

        return {
            /**
             * Calls all necessary functionality for vertical menu area if vertical area object is valid
             */
            init: function() {
                if(verticalMenuObject.length) {
                    initNavigation();
                    //initVerticalAreaScroll();
                    //
                    //if(zen.body.hasClass('zen-vertical-header-hidden')) {
                    //    initHiddenVerticalArea();
                    //}
                }
            }
        };
    };

})(jQuery);