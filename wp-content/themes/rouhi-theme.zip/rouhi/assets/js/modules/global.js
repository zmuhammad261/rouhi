(function($) {
    "use strict";

    window.zen = {};
    zen.modules = {};

    zen.scroll = 0;
    zen.window = $(window);
    zen.document = $(document);
    zen.windowWidth = $(window).width();
    zen.windowHeight = $(window).height();
    zen.body = $('body');
    zen.html = $('html, body');
    zen.htmlEl = $('html');
    zen.menuDropdownHeightSet = false;
    zen.defaultHeaderStyle = '';
    zen.minVideoWidth = 1500;
    zen.videoWidthOriginal = 1280;
    zen.videoHeightOriginal = 720;
    zen.videoRatio = 1280/720;

    zen.zenOnDocumentReady = zenOnDocumentReady;
    zen.zenOnWindowLoad = zenOnWindowLoad;
    zen.zenOnWindowResize = zenOnWindowResize;
    zen.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zen.scroll = $(window).scrollTop();

        //set global variable for header style which we will use in various functions
        if(zen.body.hasClass('zen-dark-header')){ zen.defaultHeaderStyle = 'zen-dark-header';}
        if(zen.body.hasClass('zen-light-header')){ zen.defaultHeaderStyle = 'zen-light-header';}
        zenCalcGridWidth();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {

    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
        zen.windowWidth = $(window).width();
        zen.windowHeight = $(window).height();
        zenCalcGridWidth();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {
        zen.scroll = $(window).scrollTop();
    }



    //set boxed layout width variable for various calculations

    switch(true){
        case zen.body.hasClass('zen-grid-1300'):
            zen.boxedLayoutWidth = 1350;
            zen.gridWidth = 1300;
            break;
        case zen.body.hasClass('zen-grid-1200'):
            zen.boxedLayoutWidth = 1250;
            zen.gridWidth = 1200;
            break;
        case zen.body.hasClass('zen-grid-1000'):
            zen.boxedLayoutWidth = 1050;
            zen.gridWidth = 1000;
            break;
        case zen.body.hasClass('zen-grid-800'):
            zen.boxedLayoutWidth = 850;
            zen.gridWidth = 800;
            break;
        default :
            zen.boxedLayoutWidth = 1150;
            zen.gridWidth = 1100;
            break;
    }

	function zenCalcGridWidth(){

		if (zen.windowWidth <= 320){
			zen.boxedLayoutWidth = zen.windowWidth * 0.96;
			zen.gridWidth = zen.windowWidth * 0.95;
		}
		else if (zen.windowWidth <= 480){
			zen.boxedLayoutWidth = 350;
			zen.gridWidth = 300;
		}
		else if (zen.windowWidth <= 600){
			zen.boxedLayoutWidth = 470;
			zen.gridWidth = 420;
		}
		else if (zen.windowWidth <= 768){
			zen.boxedLayoutWidth = 650;
			zen.gridWidth = 600;
		}
		else if (zen.body.hasClass('zen-grid-800')){
			zen.boxedLayoutWidth = 850;
			zen.gridWidth = 800;
		}
		else if (zen.windowWidth <= 1024){
			zen.boxedLayoutWidth = 818;
			zen.gridWidth = 768;
		}
		else if (zen.windowWidth <= 1200){
			zen.boxedLayoutWidth = 1000;
			zen.gridWidth = 950;
		}
		else if (zen.body.hasClass('zen-grid-1000')){
			zen.boxedLayoutWidth = 1050;
			zen.gridWidth = 1000;
		}
		else if (zen.windowWidth <= 1300 && zen.body.hasClass('zen-grid-1200')){
			zen.boxedLayoutWidth = 1150;
			zen.gridWidth = 1100;
		}
		else if (zen.windowWidth <= 1400 && zen.body.hasClass('zen-grid-1300')){
			zen.boxedLayoutWidth = 1150;
			zen.gridWidth = 1100;
		}
	}

})(jQuery);