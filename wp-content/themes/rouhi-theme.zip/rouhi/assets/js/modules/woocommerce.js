(function($) {
    'use strict';

    var woocommerce = {};
    zen.modules.woocommerce = woocommerce;

    woocommerce.zenInitQuantityButtons = zenInitQuantityButtons;
    woocommerce.zenInitSelect2 = zenInitSelect2;
    woocommerce.zenInitSingleProductLightbox = zenInitSingleProductLightbox;

    woocommerce.zenOnDocumentReady = zenOnDocumentReady;
    woocommerce.zenOnWindowLoad = zenOnWindowLoad;
    woocommerce.zenOnWindowResize = zenOnWindowResize;
    woocommerce.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenInitQuantityButtons();
        zenInitSelect2();
        zenInitSingleProductLightbox();
        zenWooSlider();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {

    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
    	zenWooSlider();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {

    }
    

    function zenInitQuantityButtons() {

        $(document).on( 'click', '.zen-quantity-minus, .zen-quantity-plus', function(e) {
            e.stopPropagation();

            var button = $(this),
                inputField = button.siblings('.zen-quantity-input'),
                step = parseFloat(inputField.attr('step')),
                max = parseFloat(inputField.attr('max')),
                minus = false,
                inputValue = parseFloat(inputField.val()),
                newInputValue;

            if (button.hasClass('zen-quantity-minus')) {
                minus = true;
            }

            if (minus) {
                newInputValue = inputValue - step;
                if (newInputValue >= 1) {
                    inputField.val(newInputValue);
                } else {
                    inputField.val(1);
                }
            } else {
                newInputValue = inputValue + step;
                if ( max === undefined ) {
                    inputField.val(newInputValue);
                } else {
                    if ( newInputValue >= max ) {
                        inputField.val(max);
                    } else {
                        inputField.val(newInputValue);
                    }
                }
            }
            inputField.trigger( 'change' );
        });

    }

    function zenInitSelect2() {

        if ($('.woocommerce-ordering .orderby').length ||  $('#calc_shipping_country').length ) {

            $('.woocommerce-ordering .orderby').select2({
                minimumResultsForSearch: Infinity
            });

            $('#calc_shipping_country').select2();

        }

    }

    /**
     * Init Woo Slider
     */
    function zenWooSlider() {

        var carousels = $('.zen-woo-single-slider'),
            carousel,
            imagesHolder,
            imagesHolderOuterWidth;

        if (carousels.length) {
            carousels.each(function(){
                carousel = $(this);
                imagesHolderOuterWidth = parseInt(carousel.parents('.zen-single-product-images').width());
                imagesHolder = carousel.parent();
                imagesHolder.css('width',imagesHolderOuterWidth + 'px');

                carousel.owlCarousel({
                    navigation : true, // Show next and prev buttons
                    slideSpeed : 300,
                    paginationSpeed : 400,
                    singleItem:true,
                    pagination  : false,
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i></span>'
                    ]
                });

            });
        }

    }
    /*
     ** Init Product Single Pretty Photo attributes
     */
    function zenInitSingleProductLightbox() {
        var item = $('.zen-woocommerce-single-page.zen-woo-single-has-pretty-photo .images .woocommerce-product-gallery__image');

        if(item.length) {
            item.children('a').attr('data-rel', 'prettyPhoto[product-gallery]');

            if (typeof zen.modules.common.zenPrettyPhoto === "function") {
                zen.modules.common.zenPrettyPhoto();
            }
        }
    }

})(jQuery);