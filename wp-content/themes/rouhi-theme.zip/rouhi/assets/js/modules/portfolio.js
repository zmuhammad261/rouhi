(function($) {
    'use strict';

    zen.modules.portfolio = {};

    $(window).load(function() {
        zenPortfolioSingleFollow().init();
    });

    var zenPortfolioSingleFollow = function() {

        var info = $('.zen-follow-portfolio-info .small-images.zen-portfolio-single-holder .zen-portfolio-info-holder, ' +
            '.zen-follow-portfolio-info .small-slider.zen-portfolio-single-holder .zen-portfolio-info-holder');

        if (info.length) {
            var infoHolder = info.parent(),
                infoHolderOffset = infoHolder.offset().top,
                infoHolderHeight = infoHolder.height(),
                mediaHolder = $('.zen-portfolio-media'),
                mediaHolderHeight = mediaHolder.height(),
                header = $('.header-appear, .zen-fixed-wrapper'),
                headerHeight = (header.length) ? header.height() : 0;
        }

        var infoHolderPosition = function() {

            if(info.length) {

                if (mediaHolderHeight > infoHolderHeight) {
                    if(zen.scroll > infoHolderOffset) {
                        info.animate({
                            marginTop: (zen.scroll - (infoHolderOffset) + zenGlobalVars.vars.zenAddForAdminBar + headerHeight + 20) //20 px is for styling, spacing between header and info holder
                        });
                    }
                }

            }
        };

        var recalculateInfoHolderPosition = function() {

            if (info.length) {
                if(mediaHolderHeight > infoHolderHeight) {
                    if(zen.scroll > infoHolderOffset) {

                        if(zen.scroll + headerHeight + zenGlobalVars.vars.zenAddForAdminBar + infoHolderHeight + 20 < infoHolderOffset + mediaHolderHeight) {    //20 px is for styling, spacing between header and info holder

                            //Calculate header height if header appears
                            if ($('.header-appear, .zen-fixed-wrapper').length) {
                                headerHeight = $('.header-appear, .zen-fixed-wrapper').height();
                            }
                            info.stop().animate({
                                marginTop: (zen.scroll - (infoHolderOffset) + zenGlobalVars.vars.zenAddForAdminBar + headerHeight + 20) //20 px is for styling, spacing between header and info holder
                            });
                            //Reset header height
                            headerHeight = 0;
                        }
                        else{
                            info.stop().animate({
                                marginTop: mediaHolderHeight - infoHolderHeight
                            });
                        }
                    } else {
                        info.stop().animate({
                            marginTop: 0
                        });
                    }
                }
            }
        };

        return {

            init : function() {

                infoHolderPosition();
                $(window).scroll(function(){
                    recalculateInfoHolderPosition();
                });

            }

        };

    };

})(jQuery);