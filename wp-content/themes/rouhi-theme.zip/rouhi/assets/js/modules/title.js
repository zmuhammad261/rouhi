(function($) {
    "use strict";

    var title = {};
    zen.modules.title = title;

    title.zenParallaxTitle = zenParallaxTitle;

    title.zenOnDocumentReady = zenOnDocumentReady;
    title.zenOnWindowLoad = zenOnWindowLoad;
    title.zenOnWindowResize = zenOnWindowResize;
    title.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenParallaxTitle();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {

    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {

    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {

    }
    

    /*
     **	Title image with parallax effect
     */
    function zenParallaxTitle(){
        if($('.zen-title.zen-has-parallax-background').length > 0 && $('.touch').length === 0){

            var parallaxBackground = $('.zen-title.zen-has-parallax-background');
            var parallaxBackgroundWithZoomOut = $('.zen-title.zen-has-parallax-background.zen-zoom-out');

            var backgroundSizeWidth = parseInt(parallaxBackground.data('background-width').match(/\d+/));
            var titleHolderHeight = parallaxBackground.data('height');
            var titleRate = (titleHolderHeight / 10000) * 7;
            var titleYPos = -(zen.scroll * titleRate);

            //set position of background on doc ready
            parallaxBackground.css({'background-position': 'center '+ (titleYPos+zenGlobalVars.vars.zenAddForAdminBar) +'px' });
            parallaxBackgroundWithZoomOut.css({'background-size': backgroundSizeWidth-zen.scroll + 'px auto'});

            //set position of background on window scroll
            $(window).scroll(function() {
                titleYPos = -(zen.scroll * titleRate);
                parallaxBackground.css({'background-position': 'center ' + (titleYPos+zenGlobalVars.vars.zenAddForAdminBar) + 'px' });
                parallaxBackgroundWithZoomOut.css({'background-size': backgroundSizeWidth-zen.scroll + 'px auto'});
            });

        }
    }

})(jQuery);
