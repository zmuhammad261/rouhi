(function($) {
	"use strict";

    var common = {};
    zen.modules.common = common;

    common.zenIsTouchDevice = zenIsTouchDevice;
    common.zenDisableSmoothScrollForMac = zenDisableSmoothScrollForMac;
    common.zenFluidVideo = zenFluidVideo;
    common.zenPreloadBackgrounds = zenPreloadBackgrounds;
    common.zenPrettyPhoto = zenPrettyPhoto;
    common.zenCheckHeaderStyleOnScroll = zenCheckHeaderStyleOnScroll;
    common.zenInitParallax = zenInitParallax;
    //common.zenSmoothScroll = zenSmoothScroll;
    common.zenEnableScroll = zenEnableScroll;
    common.zenDisableScroll = zenDisableScroll;
    common.zenWheel = zenWheel;
    common.zenKeydown = zenKeydown;
    common.zenPreventDefaultValue = zenPreventDefaultValue;
    common.zenOwlSlider = zenOwlSlider;
    common.zenInitSelfHostedVideoPlayer = zenInitSelfHostedVideoPlayer;
    common.zenSelfHostedVideoSize = zenSelfHostedVideoSize;
    common.zenInitBackToTop = zenInitBackToTop;
    common.zenBackButtonShowHide = zenBackButtonShowHide;
    common.zenSmoothTransition = zenSmoothTransition;

    common.zenOnDocumentReady = zenOnDocumentReady;
    common.zenOnWindowLoad = zenOnWindowLoad;
    common.zenOnWindowResize = zenOnWindowResize;
    common.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenIsTouchDevice();
        zenDisableSmoothScrollForMac();
        zenFluidVideo();
        zenPreloadBackgrounds();
        zenPrettyPhoto();
        zenInitElementsAnimations();
        zenInitAnchor().init();
        zenInitVideoBackground();
        zenInitVideoBackgroundSize();
        zenSetContentBottomMargin();
        //zenSmoothScroll();
        zenOwlSlider();
        zenInitSelfHostedVideoPlayer();
        zenSelfHostedVideoSize();
        zenInitBackToTop();
        zenBackButtonShowHide();
        zenAnimations();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {
        zenCheckHeaderStyleOnScroll(); //called on load since all content needs to be loaded in order to calculate row's position right
        zenSmoothTransition();
    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
        zenInitVideoBackgroundSize();
        zenSelfHostedVideoSize();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {
        
    }

    /*
     ** Disable shortcodes animation on appear for touch devices
     */
    function zenIsTouchDevice() {
        if(Modernizr.touch && !zen.body.hasClass('zen-no-animations-on-touch')) {
            zen.body.addClass('zen-no-animations-on-touch');
        }
    }

    /*
     ** Disable smooth scroll for mac if smooth scroll is enabled
     */
    function zenDisableSmoothScrollForMac() {
        var os = navigator.appVersion.toLowerCase();

        if (os.indexOf('mac') > -1 && zen.body.hasClass('zen-smooth-scroll')) {
            zen.body.removeClass('zen-smooth-scroll');
        }
    }

	function zenFluidVideo() {
        fluidvids.init({
			selector: ['iframe'],
			players: ['www.youtube.com', 'player.vimeo.com']
		});
	}

    /**
     * Init Owl Carousel
     */
    function zenOwlSlider() {

        var sliders = $('.zen-owl-slider');

        if (sliders.length) {
            sliders.each(function(){

                var slider = $(this);
                slider.owlCarousel({
                    singleItem: true,
                    transitionStyle: 'fadeUp',
                    navigation: true,
                    autoHeight: true,
                    pagination: false,
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i><i class="icon-arrows-slim-left zen-icon-hover"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i><i class="icon-arrows-slim-right zen-icon-hover"></i></span>'
                    ]
                });

            });
        }

    }


    /*
     *	Preload background images for elements that have 'zen-preload-background' class
     */
    function zenPreloadBackgrounds(){

        $(".zen-preload-background").each(function() {
            var preloadBackground = $(this);
            if(preloadBackground.css("background-image") !== "" && preloadBackground.css("background-image") != "none") {

                var bgUrl = preloadBackground.attr('style');

                bgUrl = bgUrl.match(/url\(["']?([^'")]+)['"]?\)/);
                bgUrl = bgUrl ? bgUrl[1] : "";

                if (bgUrl) {
                    var backImg = new Image();
                    backImg.src = bgUrl;
                    $(backImg).load(function(){
                        preloadBackground.removeClass('zen-preload-background');
                    });
                }
            }else{
                $(window).load(function(){ preloadBackground.removeClass('zen-preload-background'); }); //make sure that zen-preload-background class is removed from elements with forced background none in css
            }
        });
    }

    function zenPrettyPhoto() {
        /*jshint multistr: true */
        var markupWhole = '<div class="pp_pic_holder"> \
                        <div class="ppt">&nbsp;</div> \
                        <div class="pp_top"> \
                            <div class="pp_left"></div> \
                            <div class="pp_middle"></div> \
                            <div class="pp_right"></div> \
                        </div> \
                        <div class="pp_content_container"> \
                            <div class="pp_left"> \
                            <div class="pp_right"> \
                                <div class="pp_content"> \
                                    <div class="pp_loaderIcon"></div> \
                                    <div class="pp_fade"> \
                                        <a href="#" class="pp_expand" title="Expand the image">Expand</a> \
                                        <div class="pp_hoverContainer"> \
                                            <a class="pp_next" href="#"><span class="icon-arrows-slim-right"></span></a> \
                                            <a class="pp_previous" href="#"><span class="icon-arrows-slim-left"></span></a> \
                                        </div> \
                                        <div id="pp_full_res"></div> \
                                        <div class="pp_details"> \
                                            <div class="pp_nav"> \
                                                <a href="#" class="pp_arrow_previous">Previous</a> \
                                                <p class="currentTextHolder">0/0</p> \
                                                <a href="#" class="pp_arrow_next">Next</a> \
                                            </div> \
                                            <p class="pp_description"></p> \
                                            {pp_social} \
                                            <a class="pp_close" href="#">Close</a> \
                                        </div> \
                                    </div> \
                                </div> \
                            </div> \
                            </div> \
                        </div> \
                        <div class="pp_bottom"> \
                            <div class="pp_left"></div> \
                            <div class="pp_middle"></div> \
                            <div class="pp_right"></div> \
                        </div> \
                    </div> \
                    <div class="pp_overlay"></div>';

        $("a[data-rel^='prettyPhoto']").prettyPhoto({
            hook: 'data-rel',
            animation_speed: 'normal', /* fast/slow/normal */
            slideshow: false, /* false OR interval time in ms */
            autoplay_slideshow: false, /* true/false */
            opacity: 0.80, /* Value between 0 and 1 */
            show_title: true, /* true/false */
            allow_resize: true, /* Resize the photos bigger than viewport. true/false */
            horizontal_padding: 0,
            default_width: 960,
            default_height: 540,
            counter_separator_label: '/', /* The separator for the gallery counter 1 "of" 2 */
            theme: 'pp_default', /* light_rounded / dark_rounded / light_square / dark_square / facebook */
            hideflash: false, /* Hides all the flash object on a page, set to TRUE if flash appears over prettyPhoto */
            wmode: 'opaque', /* Set the flash wmode attribute */
            autoplay: true, /* Automatically start videos: True/False */
            modal: false, /* If set to true, only the close button will close the window */
            overlay_gallery: false, /* If set to true, a gallery will overlay the fullscreen image on mouse over */
            keyboard_shortcuts: true, /* Set to false if you open forms inside prettyPhoto */
            deeplinking: false,
            custom_markup: '',
            social_tools: false,
            markup: markupWhole
        });
    }

    /*
     *	Check header style on scroll, depending on row settings
     */
    function zenCheckHeaderStyleOnScroll(){

        if($('[data-zen_header_style]').length > 0 && zen.body.hasClass('zen-header-style-on-scroll')) {

            var waypointSelectors = $('.zen-full-width-inner > .wpb_row.zen-section, .zen-full-width-inner > .zen-parallax-section-holder, .zen-container-inner > .wpb_row.zen-section, .zen-container-inner > .zen-parallax-section-holder, .zen-portfolio-single > .wpb_row.zen-section');
            var changeStyle = function(element){
                (element.data("zen_header_style") !== undefined) ? zen.body.removeClass('zen-dark-header zen-light-header').addClass(element.data("zen_header_style")) : zen.body.removeClass('zen-dark-header zen-light-header').addClass(''+zen.defaultHeaderStyle);
            };

            waypointSelectors.waypoint( function(direction) {
                if(direction === 'down') { changeStyle($(this.element)); }
            }, { offset: 0});

            waypointSelectors.waypoint( function(direction) {
                if(direction === 'up') { changeStyle($(this.element)); }
            }, { offset: function(){
                return -$(this.element).outerHeight();
            } });
        }
    }

    /*
     *	Start animations on elements
     */
    function zenInitElementsAnimations(){

        var touchClass = $('.zen-no-animations-on-touch'),
            noAnimationsOnTouch = true,
            elements = $('.zen-grow-in, .zen-fade-in-down, .zen-element-from-fade, .zen-element-from-left, .zen-element-from-right, .zen-element-from-top, .zen-element-from-bottom, .zen-flip-in, .zen-x-rotate, .zen-z-rotate, .zen-y-translate, .zen-from-bottom, .zen-fade-in, .zen-fade-in-left-x-rotate'),
            clasess,
            animationClass,
            animationData;

        if (touchClass.length) {
            noAnimationsOnTouch = false;
        }

        if(elements.length > 0 && noAnimationsOnTouch){
            elements.each(function(){
				$(this).appear(function() {
					animationData = $(this).data('animation');
					if(typeof animationData !== 'undefined' && animationData !== '') {
						animationClass = animationData;
						$(this).addClass(animationClass+'-on');
					}
                },{accX: 0, accY: zenGlobalVars.vars.zenElementAppearAmount});
            });
        }

    }


/*
 **	Sections with parallax background image
 */
function zenInitParallax(){

    if($('.zen-parallax-section-holder').length){
        $('.zen-parallax-section-holder').each(function() {

            var parallaxElement = $(this);
            if(parallaxElement.hasClass('zen-full-screen-height-parallax')){
                parallaxElement.height(zen.windowHeight);
                parallaxElement.find('.zen-parallax-content-outer').css('padding',0);
            }
            var speed = parallaxElement.data('zen-parallax-speed')*0.4;
            parallaxElement.parallax("50%", speed);
        });
    }
}

/*
 **	Anchor functionality
 */
var zenInitAnchor = zen.modules.common.zenInitAnchor = function() {

    /**
     * Set active state on clicked anchor
     * @param anchor, clicked anchor
     */
    var setActiveState = function(anchor){

        $('.zen-main-menu .zen-active-item, .zen-mobile-nav .zen-active-item, .zen-vertical-menu .zen-active-item, .zen-fullscreen-menu .zen-active-item').removeClass('zen-active-item');
        anchor.parent().addClass('zen-active-item');

        $('.zen-main-menu a, .zen-mobile-nav a, .zen-vertical-menu a, .zen-fullscreen-menu a').removeClass('current');
        anchor.addClass('current');
    };

    /**
     * Check anchor active state on scroll
     */
    var checkActiveStateOnScroll = function(){

        $('[data-zen-anchor]').waypoint( function(direction) {
            if(direction === 'down') {
                setActiveState($("a[href='"+window.location.href.split('#')[0]+"#"+$(this.element).data("zen-anchor")+"']"));
            }
        }, { offset: '50%' });

        $('[data-zen-anchor]').waypoint( function(direction) {
            if(direction === 'up') {
                setActiveState($("a[href='"+window.location.href.split('#')[0]+"#"+$(this.element).data("zen-anchor")+"']"));
            }
        }, { offset: function(){
            return -($(this.element).outerHeight() - 150);
        } });

    };

    /**
     * Check anchor active state on load
     */
    var checkActiveStateOnLoad = function(){
        var hash = window.location.hash.split('#')[1];

        if(hash !== "" && $('[data-zen-anchor="'+hash+'"]').length > 0){
            //triggers click which is handled in 'anchorClick' function
            $("a[href='"+window.location.href.split('#')[0]+"#"+hash+"'").trigger( "click" );
        }
    };

    /**
     * Calculate header height to be substract from scroll amount
     * @param anchoredElementOffset, anchorded element offest
     */
    var headerHeihtToSubtract = function(anchoredElementOffset){

        if(zen.modules.header.behaviour == 'zen-sticky-header-on-scroll-down-up') {
            (anchoredElementOffset > zen.modules.header.stickyAppearAmount) ? zen.modules.header.isStickyVisible = true : zen.modules.header.isStickyVisible = false;
        }

        if(zen.modules.header.behaviour == 'zen-sticky-header-on-scroll-up') {
            (anchoredElementOffset > zen.scroll) ? zen.modules.header.isStickyVisible = false : '';
        }

        var headerHeight = zen.modules.header.isStickyVisible ? zenGlobalVars.vars.zenStickyHeaderTransparencyHeight : zenPerPageVars.vars.zenHeaderTransparencyHeight;

        return headerHeight;
    };

    /**
     * Handle anchor click
     */
    var anchorClick = function() {
        zen.document.on("click", ".zen-main-menu a, .zen-vertical-menu a, .zen-fullscreen-menu a, .zen-btn, .zen-anchor, .zen-mobile-nav a", function() {
            var scrollAmount;
            var anchor = $(this);
            var hash = anchor.prop("hash").split('#')[1];

            if(hash !== "" && $('[data-zen-anchor="' + hash + '"]').length > 0 /*&& anchor.attr('href').split('#')[0] == window.location.href.split('#')[0]*/) {

                var anchoredElementOffset = $('[data-zen-anchor="' + hash + '"]').offset().top;
                scrollAmount = $('[data-zen-anchor="' + hash + '"]').offset().top - headerHeihtToSubtract(anchoredElementOffset);

                setActiveState(anchor);

                zen.html.stop().animate({
                    scrollTop: Math.round(scrollAmount)
                }, 1000, function() {
                    //change hash tag in url
                    if(history.pushState) { history.pushState(null, null, '#'+hash); }
                });
                return false;
            }
        });
    };

    return {
        init: function() {
            if($('[data-zen-anchor]').length) {
                anchorClick();
                checkActiveStateOnScroll();
                $(window).load(function() { checkActiveStateOnLoad(); });
            }
        }
    };

};

/*
 **	Video background initialization
 */
function zenInitVideoBackground(){

    $('.zen-section .zen-video-wrap .zen-video, .zen-title .zen-video-wrap .zen-video').mediaelementplayer({
        enableKeyboard: false,
        iPadUseNativeControls: false,
        pauseOtherPlayers: false,
        // force iPhone's native controls
        iPhoneUseNativeControls: false,
        // force Android's native controls
        AndroidUseNativeControls: false
    });

    //mobile check
    if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|IEMobile|Opera Mini)/)){
        zenInitVideoBackgroundSize();
        $('.zen-section .zen-mobile-video-image').show();
        $('.zen-section .zen-video-wrap').remove();
    }
}

    /*
     **	Calculate video background size
     */
    function zenInitVideoBackgroundSize(){

        function videoBackgroundSize($element, $closestSelector){
            var sectionWidth = $closestSelector.outerWidth();
            $element.width(sectionWidth);

            var sectionHeight = $closestSelector.outerHeight();
            zen.minVideoWidth = zen.videoRatio * (sectionHeight+20);
            $element.height(sectionHeight);

            var scaleH = sectionWidth / zen.videoWidthOriginal;
            var scaleV = sectionHeight / zen.videoHeightOriginal;
            var scale =  scaleV;
            if (scaleH > scaleV)
                scale =  scaleH;
            if (scale * zen.videoWidthOriginal < zen.minVideoWidth) {scale = zen.minVideoWidth / zen.videoWidthOriginal;}

            $element.find('video, .mejs-overlay, .mejs-poster').width(Math.ceil(scale * zen.videoWidthOriginal +2));
            $element.find('video, .mejs-overlay, .mejs-poster').height(Math.ceil(scale * zen.videoHeightOriginal +2));
            $element.scrollLeft(($element.find('video').width() - sectionWidth) / 2);
            $element.find('.mejs-overlay, .mejs-poster').scrollTop(($element.find('video').height() - (sectionHeight)) / 2);
            $element.scrollTop(($element.find('video').height() - sectionHeight) / 2);
        }

        $('.zen-section .zen-video-wrap').each(function(){
            videoBackgroundSize($(this), $(this).closest('.zen-section'));
        });
        $('.zen-title .zen-video-wrap').each(function(){
            videoBackgroundSize($(this), $(this).closest('.zen-title'));
        });

    }

    /*
     **	Set content bottom margin because of the uncovering footer
     */
    function zenSetContentBottomMargin(){
        var uncoverFooter = $('.zen-footer-uncover');

        if(uncoverFooter.length){
            $('.zen-content').css('margin-bottom', $('.zen-footer-inner').height());
        }
    }

	/*
	** Initiate Smooth Scroll
	*/
	//function zenSmoothScroll(){
    //
	//	if(zen.body.hasClass('zen-smooth-scroll')){
     //
	//		var scrollTime = 0.4;			//Scroll time
	//		var scrollDistance = 300;		//Distance. Use smaller value for shorter scroll and greater value for longer scroll
     //
	//		var mobile_ie = -1 !== navigator.userAgent.indexOf("IEMobile");
     //
	//		var smoothScrollListener = function(event){
	//			event.preventDefault();
     //
	//			var delta = event.wheelDelta / 120 || -event.detail / 3;
	//			var scrollTop = zen.window.scrollTop();
	//			var finalScroll = scrollTop - parseInt(delta * scrollDistance);
     //
	//			TweenLite.to(zen.window, scrollTime, {
	//				scrollTo: {
	//					y: finalScroll, autoKill: !0
	//				},
	//				ease: Power1.easeOut,
	//				autoKill: !0,
	//				overwrite: 5
	//			});
	//		};
     //
	//		if (!$('html').hasClass('touch') && !mobile_ie) {
	//			if (window.addEventListener) {
	//				window.addEventListener('mousewheel', smoothScrollListener, false);
	//				window.addEventListener('DOMMouseScroll', smoothScrollListener, false);
	//			}
	//		}
	//	}
	//}

    function zenDisableScroll() {

        if (window.addEventListener) {
            window.addEventListener('DOMMouseScroll', zenWheel, false);
        }
        window.onmousewheel = document.onmousewheel = zenWheel;
        document.onkeydown = zenKeydown;

        if(zen.body.hasClass('zen-smooth-scroll')){
            window.removeEventListener('mousewheel', smoothScrollListener, false);
            window.removeEventListener('DOMMouseScroll', smoothScrollListener, false);
        }
    }

    function zenEnableScroll() {
        if (window.removeEventListener) {
            window.removeEventListener('DOMMouseScroll', zenWheel, false);
        }
        window.onmousewheel = document.onmousewheel = document.onkeydown = null;

        if(zen.body.hasClass('zen-smooth-scroll')){
            window.addEventListener('mousewheel', smoothScrollListener, false);
            window.addEventListener('DOMMouseScroll', smoothScrollListener, false);
        }
    }

    function zenWheel(e) {
        zenPreventDefaultValue(e);
    }

    function zenKeydown(e) {
        var keys = [37, 38, 39, 40];

        for (var i = keys.length; i--;) {
            if (e.keyCode === keys[i]) {
                zenPreventDefaultValue(e);
                return;
            }
        }
    }

    function zenPreventDefaultValue(e) {
        e = e || window.event;
        if (e.preventDefault) {
            e.preventDefault();
        }
        e.returnValue = false;
    }

    function zenInitSelfHostedVideoPlayer() {

        var players = $('.zen-self-hosted-video');
            players.mediaelementplayer({
                audioWidth: '100%'
            });
    }

	function zenSelfHostedVideoSize(){

		$('.zen-self-hosted-video-holder .zen-video-wrap').each(function(){
			var thisVideo = $(this);

			var videoWidth = thisVideo.closest('.zen-self-hosted-video-holder').outerWidth();
			var videoHeight = videoWidth / zen.videoRatio;

			if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|IEMobile|Opera Mini)/)){
				thisVideo.parent().width(videoWidth);
				thisVideo.parent().height(videoHeight);
			}

			thisVideo.width(videoWidth);
			thisVideo.height(videoHeight);

			thisVideo.find('video, .mejs-overlay, .mejs-poster').width(videoWidth);
			thisVideo.find('video, .mejs-overlay, .mejs-poster').height(videoHeight);
		});
	}

    function zenToTopButton(a) {

        var b = $("#zen-back-to-top");
        b.removeClass('off on');
        if (a === 'on') { b.addClass('on'); } else { b.addClass('off'); }
    }

    function zenBackButtonShowHide(){
        zen.window.scroll(function () {
            var b = $(this).scrollTop();
            var c = $(this).height();
            var d;
            if (b > 0) { d = b + c / 2; } else { d = 1; }
            if (d < 1e3) { zenToTopButton('off'); } else { zenToTopButton('on'); }
        });
    }

    function zenInitBackToTop(){
        var backToTopButton = $('#zen-back-to-top');
        backToTopButton.on('click',function(e){
            e.preventDefault();
            zen.html.animate({scrollTop: 0}, zen.window.scrollTop()/3, 'linear');
        });
    }

    function zenSmoothTransition() {

        if (zen.body.hasClass('zen-smooth-page-transitions')) {
            $(window).bind("pageshow", function(event) {
                if (event.originalEvent.persisted) {
                    $('.zen-wrapper-inner').fadeIn(0);
                }
            });
            $('a').click(function(e) {
                var a = $(this);
                if (
                    e.which == 1 && // check if the left mouse button has been pressed
                    (typeof a.data('rel') === 'undefined') && //Not pretty photo link
                    (typeof a.attr('rel') === 'undefined') && //Not VC pretty photo link
                    !a.hasClass('zen-like') && //Not like link
                    a.attr('href').indexOf(window.location.host) >= 0 && // check if the link is to the same domain
                    (typeof a.attr('target') === 'undefined' || a.attr('target') === '_self') // check if the link opens in the same window
                ) {
                    e.preventDefault();
                    $('.zen-wrapper-inner').fadeOut(1000, function() {
                        window.location = a.attr('href');
                    });
                }
            });
        }
    }

    /*
    *   Do not stop animations on mouse leave
    */
    function zenAnimations() {
        var animatedElements = $('#zen-back-to-top, .zen-process-slider-next-nav, .zen-icon-shortcode.circle.zen-icon-linked');
        if (animatedElements.length) {
            animatedElements.each(function(){
                var animatedElement = $(this);
                animatedElement.mouseenter(function(){
                    $(this).addClass('zen-animating');
                    $(this).one('webkitAnimationEnd oanimationend msAnimationEnd animationend',   
                        function(e) {
                        $(this).removeClass('zen-animating');
                    });
                });
            });
        }
    }

})(jQuery);


