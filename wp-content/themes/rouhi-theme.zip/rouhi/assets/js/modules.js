(function($) {
    "use strict";

    window.zen = {};
    zen.modules = {};

    zen.scroll = 0;
    zen.window = $(window);
    zen.document = $(document);
    zen.windowWidth = $(window).width();
    zen.windowHeight = $(window).height();
    zen.body = $('body');
    zen.html = $('html, body');
    zen.htmlEl = $('html');
    zen.menuDropdownHeightSet = false;
    zen.defaultHeaderStyle = '';
    zen.minVideoWidth = 1500;
    zen.videoWidthOriginal = 1280;
    zen.videoHeightOriginal = 720;
    zen.videoRatio = 1280/720;

    zen.zenOnDocumentReady = zenOnDocumentReady;
    zen.zenOnWindowLoad = zenOnWindowLoad;
    zen.zenOnWindowResize = zenOnWindowResize;
    zen.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zen.scroll = $(window).scrollTop();

        //set global variable for header style which we will use in various functions
        if(zen.body.hasClass('zen-dark-header')){ zen.defaultHeaderStyle = 'zen-dark-header';}
        if(zen.body.hasClass('zen-light-header')){ zen.defaultHeaderStyle = 'zen-light-header';}
        zenCalcGridWidth();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {

    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
        zen.windowWidth = $(window).width();
        zen.windowHeight = $(window).height();
        zenCalcGridWidth();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {
        zen.scroll = $(window).scrollTop();
    }



    //set boxed layout width variable for various calculations

    switch(true){
        case zen.body.hasClass('zen-grid-1300'):
            zen.boxedLayoutWidth = 1350;
            zen.gridWidth = 1300;
            break;
        case zen.body.hasClass('zen-grid-1200'):
            zen.boxedLayoutWidth = 1250;
            zen.gridWidth = 1200;
            break;
        case zen.body.hasClass('zen-grid-1000'):
            zen.boxedLayoutWidth = 1050;
            zen.gridWidth = 1000;
            break;
        case zen.body.hasClass('zen-grid-800'):
            zen.boxedLayoutWidth = 850;
            zen.gridWidth = 800;
            break;
        default :
            zen.boxedLayoutWidth = 1150;
            zen.gridWidth = 1100;
            break;
    }

	function zenCalcGridWidth(){

		if (zen.windowWidth <= 320){
			zen.boxedLayoutWidth = zen.windowWidth * 0.96;
			zen.gridWidth = zen.windowWidth * 0.95;
		}
		else if (zen.windowWidth <= 480){
			zen.boxedLayoutWidth = 350;
			zen.gridWidth = 300;
		}
		else if (zen.windowWidth <= 600){
			zen.boxedLayoutWidth = 470;
			zen.gridWidth = 420;
		}
		else if (zen.windowWidth <= 768){
			zen.boxedLayoutWidth = 650;
			zen.gridWidth = 600;
		}
		else if (zen.body.hasClass('zen-grid-800')){
			zen.boxedLayoutWidth = 850;
			zen.gridWidth = 800;
		}
		else if (zen.windowWidth <= 1024){
			zen.boxedLayoutWidth = 818;
			zen.gridWidth = 768;
		}
		else if (zen.windowWidth <= 1200){
			zen.boxedLayoutWidth = 1000;
			zen.gridWidth = 950;
		}
		else if (zen.body.hasClass('zen-grid-1000')){
			zen.boxedLayoutWidth = 1050;
			zen.gridWidth = 1000;
		}
		else if (zen.windowWidth <= 1300 && zen.body.hasClass('zen-grid-1200')){
			zen.boxedLayoutWidth = 1150;
			zen.gridWidth = 1100;
		}
		else if (zen.windowWidth <= 1400 && zen.body.hasClass('zen-grid-1300')){
			zen.boxedLayoutWidth = 1150;
			zen.gridWidth = 1100;
		}
	}

})(jQuery);
(function($) {
	"use strict";

    var common = {};
    zen.modules.common = common;

    common.zenIsTouchDevice = zenIsTouchDevice;
    common.zenDisableSmoothScrollForMac = zenDisableSmoothScrollForMac;
    common.zenFluidVideo = zenFluidVideo;
    common.zenPreloadBackgrounds = zenPreloadBackgrounds;
    common.zenPrettyPhoto = zenPrettyPhoto;
    common.zenCheckHeaderStyleOnScroll = zenCheckHeaderStyleOnScroll;
    common.zenInitParallax = zenInitParallax;
    //common.zenSmoothScroll = zenSmoothScroll;
    common.zenEnableScroll = zenEnableScroll;
    common.zenDisableScroll = zenDisableScroll;
    common.zenWheel = zenWheel;
    common.zenKeydown = zenKeydown;
    common.zenPreventDefaultValue = zenPreventDefaultValue;
    common.zenOwlSlider = zenOwlSlider;
    common.zenInitSelfHostedVideoPlayer = zenInitSelfHostedVideoPlayer;
    common.zenSelfHostedVideoSize = zenSelfHostedVideoSize;
    common.zenInitBackToTop = zenInitBackToTop;
    common.zenBackButtonShowHide = zenBackButtonShowHide;
    common.zenSmoothTransition = zenSmoothTransition;

    common.zenOnDocumentReady = zenOnDocumentReady;
    common.zenOnWindowLoad = zenOnWindowLoad;
    common.zenOnWindowResize = zenOnWindowResize;
    common.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenIsTouchDevice();
        zenDisableSmoothScrollForMac();
        zenFluidVideo();
        zenPreloadBackgrounds();
        zenPrettyPhoto();
        zenInitElementsAnimations();
        zenInitAnchor().init();
        zenInitVideoBackground();
        zenInitVideoBackgroundSize();
        zenSetContentBottomMargin();
        //zenSmoothScroll();
        zenOwlSlider();
        zenInitSelfHostedVideoPlayer();
        zenSelfHostedVideoSize();
        zenInitBackToTop();
        zenBackButtonShowHide();
        zenAnimations();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {
        zenCheckHeaderStyleOnScroll(); //called on load since all content needs to be loaded in order to calculate row's position right
        zenSmoothTransition();
    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
        zenInitVideoBackgroundSize();
        zenSelfHostedVideoSize();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {
        
    }

    /*
     ** Disable shortcodes animation on appear for touch devices
     */
    function zenIsTouchDevice() {
        if(Modernizr.touch && !zen.body.hasClass('zen-no-animations-on-touch')) {
            zen.body.addClass('zen-no-animations-on-touch');
        }
    }

    /*
     ** Disable smooth scroll for mac if smooth scroll is enabled
     */
    function zenDisableSmoothScrollForMac() {
        var os = navigator.appVersion.toLowerCase();

        if (os.indexOf('mac') > -1 && zen.body.hasClass('zen-smooth-scroll')) {
            zen.body.removeClass('zen-smooth-scroll');
        }
    }

	function zenFluidVideo() {
        fluidvids.init({
			selector: ['iframe'],
			players: ['www.youtube.com', 'player.vimeo.com']
		});
	}

    /**
     * Init Owl Carousel
     */
    function zenOwlSlider() {

        var sliders = $('.zen-owl-slider');

        if (sliders.length) {
            sliders.each(function(){

                var slider = $(this);
                slider.owlCarousel({
                    singleItem: true,
                    transitionStyle: 'fadeUp',
                    navigation: true,
                    autoHeight: true,
                    pagination: false,
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i><i class="icon-arrows-slim-left zen-icon-hover"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i><i class="icon-arrows-slim-right zen-icon-hover"></i></span>'
                    ]
                });

            });
        }

    }


    /*
     *	Preload background images for elements that have 'zen-preload-background' class
     */
    function zenPreloadBackgrounds(){

        $(".zen-preload-background").each(function() {
            var preloadBackground = $(this);
            if(preloadBackground.css("background-image") !== "" && preloadBackground.css("background-image") != "none") {

                var bgUrl = preloadBackground.attr('style');

                bgUrl = bgUrl.match(/url\(["']?([^'")]+)['"]?\)/);
                bgUrl = bgUrl ? bgUrl[1] : "";

                if (bgUrl) {
                    var backImg = new Image();
                    backImg.src = bgUrl;
                    $(backImg).load(function(){
                        preloadBackground.removeClass('zen-preload-background');
                    });
                }
            }else{
                $(window).load(function(){ preloadBackground.removeClass('zen-preload-background'); }); //make sure that zen-preload-background class is removed from elements with forced background none in css
            }
        });
    }

    function zenPrettyPhoto() {
        /*jshint multistr: true */
        var markupWhole = '<div class="pp_pic_holder"> \
                        <div class="ppt">&nbsp;</div> \
                        <div class="pp_top"> \
                            <div class="pp_left"></div> \
                            <div class="pp_middle"></div> \
                            <div class="pp_right"></div> \
                        </div> \
                        <div class="pp_content_container"> \
                            <div class="pp_left"> \
                            <div class="pp_right"> \
                                <div class="pp_content"> \
                                    <div class="pp_loaderIcon"></div> \
                                    <div class="pp_fade"> \
                                        <a href="#" class="pp_expand" title="Expand the image">Expand</a> \
                                        <div class="pp_hoverContainer"> \
                                            <a class="pp_next" href="#"><span class="icon-arrows-slim-right"></span></a> \
                                            <a class="pp_previous" href="#"><span class="icon-arrows-slim-left"></span></a> \
                                        </div> \
                                        <div id="pp_full_res"></div> \
                                        <div class="pp_details"> \
                                            <div class="pp_nav"> \
                                                <a href="#" class="pp_arrow_previous">Previous</a> \
                                                <p class="currentTextHolder">0/0</p> \
                                                <a href="#" class="pp_arrow_next">Next</a> \
                                            </div> \
                                            <p class="pp_description"></p> \
                                            {pp_social} \
                                            <a class="pp_close" href="#">Close</a> \
                                        </div> \
                                    </div> \
                                </div> \
                            </div> \
                            </div> \
                        </div> \
                        <div class="pp_bottom"> \
                            <div class="pp_left"></div> \
                            <div class="pp_middle"></div> \
                            <div class="pp_right"></div> \
                        </div> \
                    </div> \
                    <div class="pp_overlay"></div>';

        $("a[data-rel^='prettyPhoto']").prettyPhoto({
            hook: 'data-rel',
            animation_speed: 'normal', /* fast/slow/normal */
            slideshow: false, /* false OR interval time in ms */
            autoplay_slideshow: false, /* true/false */
            opacity: 0.80, /* Value between 0 and 1 */
            show_title: true, /* true/false */
            allow_resize: true, /* Resize the photos bigger than viewport. true/false */
            horizontal_padding: 0,
            default_width: 960,
            default_height: 540,
            counter_separator_label: '/', /* The separator for the gallery counter 1 "of" 2 */
            theme: 'pp_default', /* light_rounded / dark_rounded / light_square / dark_square / facebook */
            hideflash: false, /* Hides all the flash object on a page, set to TRUE if flash appears over prettyPhoto */
            wmode: 'opaque', /* Set the flash wmode attribute */
            autoplay: true, /* Automatically start videos: True/False */
            modal: false, /* If set to true, only the close button will close the window */
            overlay_gallery: false, /* If set to true, a gallery will overlay the fullscreen image on mouse over */
            keyboard_shortcuts: true, /* Set to false if you open forms inside prettyPhoto */
            deeplinking: false,
            custom_markup: '',
            social_tools: false,
            markup: markupWhole
        });
    }

    /*
     *	Check header style on scroll, depending on row settings
     */
    function zenCheckHeaderStyleOnScroll(){

        if($('[data-zen_header_style]').length > 0 && zen.body.hasClass('zen-header-style-on-scroll')) {

            var waypointSelectors = $('.zen-full-width-inner > .wpb_row.zen-section, .zen-full-width-inner > .zen-parallax-section-holder, .zen-container-inner > .wpb_row.zen-section, .zen-container-inner > .zen-parallax-section-holder, .zen-portfolio-single > .wpb_row.zen-section');
            var changeStyle = function(element){
                (element.data("zen_header_style") !== undefined) ? zen.body.removeClass('zen-dark-header zen-light-header').addClass(element.data("zen_header_style")) : zen.body.removeClass('zen-dark-header zen-light-header').addClass(''+zen.defaultHeaderStyle);
            };

            waypointSelectors.waypoint( function(direction) {
                if(direction === 'down') { changeStyle($(this.element)); }
            }, { offset: 0});

            waypointSelectors.waypoint( function(direction) {
                if(direction === 'up') { changeStyle($(this.element)); }
            }, { offset: function(){
                return -$(this.element).outerHeight();
            } });
        }
    }

    /*
     *	Start animations on elements
     */
    function zenInitElementsAnimations(){

        var touchClass = $('.zen-no-animations-on-touch'),
            noAnimationsOnTouch = true,
            elements = $('.zen-grow-in, .zen-fade-in-down, .zen-element-from-fade, .zen-element-from-left, .zen-element-from-right, .zen-element-from-top, .zen-element-from-bottom, .zen-flip-in, .zen-x-rotate, .zen-z-rotate, .zen-y-translate, .zen-from-bottom, .zen-fade-in, .zen-fade-in-left-x-rotate'),
            clasess,
            animationClass,
            animationData;

        if (touchClass.length) {
            noAnimationsOnTouch = false;
        }

        if(elements.length > 0 && noAnimationsOnTouch){
            elements.each(function(){
				$(this).appear(function() {
					animationData = $(this).data('animation');
					if(typeof animationData !== 'undefined' && animationData !== '') {
						animationClass = animationData;
						$(this).addClass(animationClass+'-on');
					}
                },{accX: 0, accY: zenGlobalVars.vars.zenElementAppearAmount});
            });
        }

    }


/*
 **	Sections with parallax background image
 */
function zenInitParallax(){

    if($('.zen-parallax-section-holder').length){
        $('.zen-parallax-section-holder').each(function() {

            var parallaxElement = $(this);
            if(parallaxElement.hasClass('zen-full-screen-height-parallax')){
                parallaxElement.height(zen.windowHeight);
                parallaxElement.find('.zen-parallax-content-outer').css('padding',0);
            }
            var speed = parallaxElement.data('zen-parallax-speed')*0.4;
            parallaxElement.parallax("50%", speed);
        });
    }
}

/*
 **	Anchor functionality
 */
var zenInitAnchor = zen.modules.common.zenInitAnchor = function() {

    /**
     * Set active state on clicked anchor
     * @param anchor, clicked anchor
     */
    var setActiveState = function(anchor){

        $('.zen-main-menu .zen-active-item, .zen-mobile-nav .zen-active-item, .zen-vertical-menu .zen-active-item, .zen-fullscreen-menu .zen-active-item').removeClass('zen-active-item');
        anchor.parent().addClass('zen-active-item');

        $('.zen-main-menu a, .zen-mobile-nav a, .zen-vertical-menu a, .zen-fullscreen-menu a').removeClass('current');
        anchor.addClass('current');
    };

    /**
     * Check anchor active state on scroll
     */
    var checkActiveStateOnScroll = function(){

        $('[data-zen-anchor]').waypoint( function(direction) {
            if(direction === 'down') {
                setActiveState($("a[href='"+window.location.href.split('#')[0]+"#"+$(this.element).data("zen-anchor")+"']"));
            }
        }, { offset: '50%' });

        $('[data-zen-anchor]').waypoint( function(direction) {
            if(direction === 'up') {
                setActiveState($("a[href='"+window.location.href.split('#')[0]+"#"+$(this.element).data("zen-anchor")+"']"));
            }
        }, { offset: function(){
            return -($(this.element).outerHeight() - 150);
        } });

    };

    /**
     * Check anchor active state on load
     */
    var checkActiveStateOnLoad = function(){
        var hash = window.location.hash.split('#')[1];

        if(hash !== "" && $('[data-zen-anchor="'+hash+'"]').length > 0){
            //triggers click which is handled in 'anchorClick' function
            $("a[href='"+window.location.href.split('#')[0]+"#"+hash+"'").trigger( "click" );
        }
    };

    /**
     * Calculate header height to be substract from scroll amount
     * @param anchoredElementOffset, anchorded element offest
     */
    var headerHeihtToSubtract = function(anchoredElementOffset){

        if(zen.modules.header.behaviour == 'zen-sticky-header-on-scroll-down-up') {
            (anchoredElementOffset > zen.modules.header.stickyAppearAmount) ? zen.modules.header.isStickyVisible = true : zen.modules.header.isStickyVisible = false;
        }

        if(zen.modules.header.behaviour == 'zen-sticky-header-on-scroll-up') {
            (anchoredElementOffset > zen.scroll) ? zen.modules.header.isStickyVisible = false : '';
        }

        var headerHeight = zen.modules.header.isStickyVisible ? zenGlobalVars.vars.zenStickyHeaderTransparencyHeight : zenPerPageVars.vars.zenHeaderTransparencyHeight;

        return headerHeight;
    };

    /**
     * Handle anchor click
     */
    var anchorClick = function() {
        zen.document.on("click", ".zen-main-menu a, .zen-vertical-menu a, .zen-fullscreen-menu a, .zen-btn, .zen-anchor, .zen-mobile-nav a", function() {
            var scrollAmount;
            var anchor = $(this);
            var hash = anchor.prop("hash").split('#')[1];

            if(hash !== "" && $('[data-zen-anchor="' + hash + '"]').length > 0 /*&& anchor.attr('href').split('#')[0] == window.location.href.split('#')[0]*/) {

                var anchoredElementOffset = $('[data-zen-anchor="' + hash + '"]').offset().top;
                scrollAmount = $('[data-zen-anchor="' + hash + '"]').offset().top - headerHeihtToSubtract(anchoredElementOffset);

                setActiveState(anchor);

                zen.html.stop().animate({
                    scrollTop: Math.round(scrollAmount)
                }, 1000, function() {
                    //change hash tag in url
                    if(history.pushState) { history.pushState(null, null, '#'+hash); }
                });
                return false;
            }
        });
    };

    return {
        init: function() {
            if($('[data-zen-anchor]').length) {
                anchorClick();
                checkActiveStateOnScroll();
                $(window).load(function() { checkActiveStateOnLoad(); });
            }
        }
    };

};

/*
 **	Video background initialization
 */
function zenInitVideoBackground(){

    $('.zen-section .zen-video-wrap .zen-video, .zen-title .zen-video-wrap .zen-video').mediaelementplayer({
        enableKeyboard: false,
        iPadUseNativeControls: false,
        pauseOtherPlayers: false,
        // force iPhone's native controls
        iPhoneUseNativeControls: false,
        // force Android's native controls
        AndroidUseNativeControls: false
    });

    //mobile check
    if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|IEMobile|Opera Mini)/)){
        zenInitVideoBackgroundSize();
        $('.zen-section .zen-mobile-video-image').show();
        $('.zen-section .zen-video-wrap').remove();
    }
}

    /*
     **	Calculate video background size
     */
    function zenInitVideoBackgroundSize(){

        function videoBackgroundSize($element, $closestSelector){
            var sectionWidth = $closestSelector.outerWidth();
            $element.width(sectionWidth);

            var sectionHeight = $closestSelector.outerHeight();
            zen.minVideoWidth = zen.videoRatio * (sectionHeight+20);
            $element.height(sectionHeight);

            var scaleH = sectionWidth / zen.videoWidthOriginal;
            var scaleV = sectionHeight / zen.videoHeightOriginal;
            var scale =  scaleV;
            if (scaleH > scaleV)
                scale =  scaleH;
            if (scale * zen.videoWidthOriginal < zen.minVideoWidth) {scale = zen.minVideoWidth / zen.videoWidthOriginal;}

            $element.find('video, .mejs-overlay, .mejs-poster').width(Math.ceil(scale * zen.videoWidthOriginal +2));
            $element.find('video, .mejs-overlay, .mejs-poster').height(Math.ceil(scale * zen.videoHeightOriginal +2));
            $element.scrollLeft(($element.find('video').width() - sectionWidth) / 2);
            $element.find('.mejs-overlay, .mejs-poster').scrollTop(($element.find('video').height() - (sectionHeight)) / 2);
            $element.scrollTop(($element.find('video').height() - sectionHeight) / 2);
        }

        $('.zen-section .zen-video-wrap').each(function(){
            videoBackgroundSize($(this), $(this).closest('.zen-section'));
        });
        $('.zen-title .zen-video-wrap').each(function(){
            videoBackgroundSize($(this), $(this).closest('.zen-title'));
        });

    }

    /*
     **	Set content bottom margin because of the uncovering footer
     */
    function zenSetContentBottomMargin(){
        var uncoverFooter = $('.zen-footer-uncover');

        if(uncoverFooter.length){
            $('.zen-content').css('margin-bottom', $('.zen-footer-inner').height());
        }
    }

	/*
	** Initiate Smooth Scroll
	*/
	//function zenSmoothScroll(){
    //
	//	if(zen.body.hasClass('zen-smooth-scroll')){
     //
	//		var scrollTime = 0.4;			//Scroll time
	//		var scrollDistance = 300;		//Distance. Use smaller value for shorter scroll and greater value for longer scroll
     //
	//		var mobile_ie = -1 !== navigator.userAgent.indexOf("IEMobile");
     //
	//		var smoothScrollListener = function(event){
	//			event.preventDefault();
     //
	//			var delta = event.wheelDelta / 120 || -event.detail / 3;
	//			var scrollTop = zen.window.scrollTop();
	//			var finalScroll = scrollTop - parseInt(delta * scrollDistance);
     //
	//			TweenLite.to(zen.window, scrollTime, {
	//				scrollTo: {
	//					y: finalScroll, autoKill: !0
	//				},
	//				ease: Power1.easeOut,
	//				autoKill: !0,
	//				overwrite: 5
	//			});
	//		};
     //
	//		if (!$('html').hasClass('touch') && !mobile_ie) {
	//			if (window.addEventListener) {
	//				window.addEventListener('mousewheel', smoothScrollListener, false);
	//				window.addEventListener('DOMMouseScroll', smoothScrollListener, false);
	//			}
	//		}
	//	}
	//}

    function zenDisableScroll() {

        if (window.addEventListener) {
            window.addEventListener('DOMMouseScroll', zenWheel, false);
        }
        window.onmousewheel = document.onmousewheel = zenWheel;
        document.onkeydown = zenKeydown;

        if(zen.body.hasClass('zen-smooth-scroll')){
            window.removeEventListener('mousewheel', smoothScrollListener, false);
            window.removeEventListener('DOMMouseScroll', smoothScrollListener, false);
        }
    }

    function zenEnableScroll() {
        if (window.removeEventListener) {
            window.removeEventListener('DOMMouseScroll', zenWheel, false);
        }
        window.onmousewheel = document.onmousewheel = document.onkeydown = null;

        if(zen.body.hasClass('zen-smooth-scroll')){
            window.addEventListener('mousewheel', smoothScrollListener, false);
            window.addEventListener('DOMMouseScroll', smoothScrollListener, false);
        }
    }

    function zenWheel(e) {
        zenPreventDefaultValue(e);
    }

    function zenKeydown(e) {
        var keys = [37, 38, 39, 40];

        for (var i = keys.length; i--;) {
            if (e.keyCode === keys[i]) {
                zenPreventDefaultValue(e);
                return;
            }
        }
    }

    function zenPreventDefaultValue(e) {
        e = e || window.event;
        if (e.preventDefault) {
            e.preventDefault();
        }
        e.returnValue = false;
    }

    function zenInitSelfHostedVideoPlayer() {

        var players = $('.zen-self-hosted-video');
            players.mediaelementplayer({
                audioWidth: '100%'
            });
    }

	function zenSelfHostedVideoSize(){

		$('.zen-self-hosted-video-holder .zen-video-wrap').each(function(){
			var thisVideo = $(this);

			var videoWidth = thisVideo.closest('.zen-self-hosted-video-holder').outerWidth();
			var videoHeight = videoWidth / zen.videoRatio;

			if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|IEMobile|Opera Mini)/)){
				thisVideo.parent().width(videoWidth);
				thisVideo.parent().height(videoHeight);
			}

			thisVideo.width(videoWidth);
			thisVideo.height(videoHeight);

			thisVideo.find('video, .mejs-overlay, .mejs-poster').width(videoWidth);
			thisVideo.find('video, .mejs-overlay, .mejs-poster').height(videoHeight);
		});
	}

    function zenToTopButton(a) {

        var b = $("#zen-back-to-top");
        b.removeClass('off on');
        if (a === 'on') { b.addClass('on'); } else { b.addClass('off'); }
    }

    function zenBackButtonShowHide(){
        zen.window.scroll(function () {
            var b = $(this).scrollTop();
            var c = $(this).height();
            var d;
            if (b > 0) { d = b + c / 2; } else { d = 1; }
            if (d < 1e3) { zenToTopButton('off'); } else { zenToTopButton('on'); }
        });
    }

    function zenInitBackToTop(){
        var backToTopButton = $('#zen-back-to-top');
        backToTopButton.on('click',function(e){
            e.preventDefault();
            zen.html.animate({scrollTop: 0}, zen.window.scrollTop()/3, 'linear');
        });
    }

    function zenSmoothTransition() {

        if (zen.body.hasClass('zen-smooth-page-transitions')) {
            $(window).bind("pageshow", function(event) {
                if (event.originalEvent.persisted) {
                    $('.zen-wrapper-inner').fadeIn(0);
                }
            });
            $('a').click(function(e) {
                var a = $(this);
                if (
                    e.which == 1 && // check if the left mouse button has been pressed
                    (typeof a.data('rel') === 'undefined') && //Not pretty photo link
                    (typeof a.attr('rel') === 'undefined') && //Not VC pretty photo link
                    !a.hasClass('zen-like') && //Not like link
                    a.attr('href').indexOf(window.location.host) >= 0 && // check if the link is to the same domain
                    (typeof a.attr('target') === 'undefined' || a.attr('target') === '_self') // check if the link opens in the same window
                ) {
                    e.preventDefault();
                    $('.zen-wrapper-inner').fadeOut(1000, function() {
                        window.location = a.attr('href');
                    });
                }
            });
        }
    }

    /*
    *   Do not stop animations on mouse leave
    */
    function zenAnimations() {
        var animatedElements = $('#zen-back-to-top, .zen-process-slider-next-nav, .zen-icon-shortcode.circle.zen-icon-linked');
        if (animatedElements.length) {
            animatedElements.each(function(){
                var animatedElement = $(this);
                animatedElement.mouseenter(function(){
                    $(this).addClass('zen-animating');
                    $(this).one('webkitAnimationEnd oanimationend msAnimationEnd animationend',   
                        function(e) {
                        $(this).removeClass('zen-animating');
                    });
                });
            });
        }
    }

})(jQuery);



(function($) {
    "use strict";

    var header = {};
    zen.modules.header = header;

    header.isStickyVisible = false;
    header.stickyAppearAmount = 0;
    header.behaviour;
    header.zenFullscreenMenu = zenFullscreenMenu;
    header.zenInitMobileNavigation = zenInitMobileNavigation;
    header.zenMobileHeaderBehavior = zenMobileHeaderBehavior;
    header.zenSetMenuWidthForCenteredLogoHeader = zenSetMenuWidthForCenteredLogoHeader;
    header.zenSetDropDownMenuPosition = zenSetDropDownMenuPosition;
    header.zenDropDownMenu = zenDropDownMenu;
    header.zenSearch = zenSearch;

    header.zenOnDocumentReady = zenOnDocumentReady;
    header.zenOnWindowLoad = zenOnWindowLoad;
    header.zenOnWindowResize = zenOnWindowResize;
    header.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenHeaderBehaviour();
        zenFullscreenMenu();
        zenInitMobileNavigation();
        zenMobileHeaderBehavior();
        zenSetDropDownMenuPosition();
        zenDropDownMenu();
        zenSearch();
        zenVerticalMenu().init();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {
        zenSetMenuWidthForCenteredLogoHeader();
        zenSetDropDownMenuPosition();
    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
        zenDropDownMenu();
        zenSetMenuWidthForCenteredLogoHeader();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {
        
    }



    /*
     **	Show/Hide sticky header on window scroll
     */
    function zenHeaderBehaviour() {

        var header = $('.zen-page-header');
        var stickyHeader = $('.zen-sticky-header');

        var stickyAppearAmount;

        switch(true) {
            // sticky header that will be shown when user scrolls up
            case zen.body.hasClass('zen-sticky-header-on-scroll-up'):
                zen.modules.header.behaviour = 'zen-sticky-header-on-scroll-up';
                var docYScroll1 = $(document).scrollTop();
                stickyAppearAmount = zenGlobalVars.vars.zenTopBarHeight + zenGlobalVars.vars.zenLogoAreaHeight + zenGlobalVars.vars.zenMenuAreaHeight + zenGlobalVars.vars.zenStickyHeaderHeight + 400; //400 is designer's whish

                var headerAppear = function(){
                    var docYScroll2 = $(document).scrollTop();

                    if((docYScroll2 > docYScroll1 && docYScroll2 > stickyAppearAmount) || (docYScroll2 < stickyAppearAmount)) {
                        zen.modules.header.isStickyVisible= false;
                        stickyHeader.removeClass('header-appear').find('.zen-main-menu .second').removeClass('zen-drop-down-start');
                    }else {
                        zen.modules.header.isStickyVisible = true;
                        stickyHeader.addClass('header-appear');
                    }

                    docYScroll1 = $(document).scrollTop();
                };
                headerAppear();

                $(window).scroll(function() {
                    headerAppear();
                });

                break;

            // sticky header that will be shown when user scrolls both up and down
            case zen.body.hasClass('zen-sticky-header-on-scroll-down-up'):
                zen.modules.header.behaviour = 'zen-sticky-header-on-scroll-down-up';
                stickyAppearAmount = zenPerPageVars.vars.zenStickyScrollAmount !== 0 ? zenPerPageVars.vars.zenStickyScrollAmount : zenGlobalVars.vars.zenTopBarHeight + zenGlobalVars.vars.zenLogoAreaHeight + zenGlobalVars.vars.zenMenuAreaHeight;
                zen.modules.header.stickyAppearAmount = stickyAppearAmount; //used in anchor logic
                
                var headerAppear = function(){
                    if(zen.scroll < stickyAppearAmount) {
                        zen.modules.header.isStickyVisible = false;
                        stickyHeader.removeClass('header-appear').find('.zen-main-menu .second').removeClass('zen-drop-down-start');
                    }else{
                        zen.modules.header.isStickyVisible = true;
                        stickyHeader.addClass('header-appear');
                    }
                };

                headerAppear();

                $(window).scroll(function() {
                    headerAppear();
                });

                break;

        }
    }

    function zenSetMenuWidthForCenteredLogoHeader(){
        if(zen.body.hasClass('zen-header-centered-logo')){
            //get left side menu width

            var menuAreaLeftSideWidth =  Math.round($('.zen-menu-area').width()/2 - $('.zen-menu-area .zen-position-left .widget').width() - $('.zen-menu-area .zen-logo-wrapper').width()/2);
            $('.zen-menu-area .zen-position-left .zen-main-menu').width(menuAreaLeftSideWidth);

            var stickyHeaderLeftSideWidth =  Math.round($('.zen-sticky-header .zen-vertical-align-containers').width()/2 - $('.zen-sticky-header .zen-position-left .widget').width() - $('.zen-sticky-header .zen-logo-wrapper').width()/2);
            $('.zen-sticky-header .zen-position-left .zen-main-menu').width(stickyHeaderLeftSideWidth);

            //get right side menu width
            var menuAreaRightSideWidth =  Math.round($('.zen-menu-area').width()/2 - $('.zen-menu-area .zen-position-right .widget').width() - $('.zen-menu-area .zen-logo-wrapper').width()/2);
            $('.zen-menu-area .zen-position-right .zen-main-menu').width(menuAreaRightSideWidth);

            var stickyHeaderRightSideWidth =  Math.round($('.zen-sticky-header .zen-vertical-align-containers').width()/2 - $('.zen-sticky-header .zen-position-right .widget').width() - $('.zen-sticky-header .zen-logo-wrapper').width()/2);
            $('.zen-sticky-header .zen-position-right .zen-main-menu').width(stickyHeaderRightSideWidth);

            $('.zen-main-menu').css('opacity',1);

            zenSetDropDownMenuPosition();
        }
    }

    /**
     * Init Fullscreen Menu
     */
    function zenFullscreenMenu() {

        if ($('a.zen-fullscreen-menu-opener').length) {

            var popupMenuOpener = $( 'a.zen-fullscreen-menu-opener'),
                popupMenuHolderOuter = $(".zen-fullscreen-menu-holder-outer"),
                cssClass,
            //Flags for type of animation
                fadeRight = false,
                fadeTop = false,
            //Widgets
                widgetAboveNav = $('.zen-fullscreen-above-menu-widget-holder'),
                widgetBelowNav = $('.zen-fullscreen-below-menu-widget-holder'),
            //Menu
                menuItems = $('.zen-fullscreen-menu-holder-outer nav > ul > li > a'),
                menuItemWithChild =  $('.zen-fullscreen-menu > ul li.has_sub > a'),
                menuItemWithoutChild = $('.zen-fullscreen-menu ul li:not(.has_sub) a');


            //set height of popup holder and initialize nicescroll
            popupMenuHolderOuter.height(zen.windowHeight).niceScroll({
                scrollspeed: 30,
                mousescrollstep: 20,
                cursorwidth: 0,
                cursorborder: 0,
                cursorborderradius: 0,
                cursorcolor: "transparent",
                autohidemode: false,
                horizrailenabled: false
            }); //200 is top and bottom padding of holder

            //set height of popup holder on resize
            $(window).resize(function() {
                popupMenuHolderOuter.height(zen.windowHeight);
            });

            if (zen.body.hasClass('zen-fade-push-text-right')) {
                cssClass = 'zen-push-nav-right';
                fadeRight = true;
            } else if (zen.body.hasClass('zen-fade-push-text-top')) {
                cssClass = 'zen-push-text-top';
                fadeTop = true;
            }

            //Appearing animation
            if (fadeRight || fadeTop) {
                if (widgetAboveNav.length) {
                    widgetAboveNav.children().css({
                        '-webkit-animation-delay' : 0 + 'ms',
                        '-moz-animation-delay' : 0 + 'ms',
                        'animation-delay' : 0 + 'ms'
                    });
                }
                menuItems.each(function(i) {
                    $(this).css({
                        '-webkit-animation-delay': (i+1) * 70 + 'ms',
                        '-moz-animation-delay': (i+1) * 70 + 'ms',
                        'animation-delay': (i+1) * 70 + 'ms'
                    });
                });
                if (widgetBelowNav.length) {
                    widgetBelowNav.children().css({
                        '-webkit-animation-delay' : (menuItems.length + 1)*70 + 'ms',
                        '-moz-animation-delay' : (menuItems.length + 1)*70 + 'ms',
                        'animation-delay' : (menuItems.length + 1)*70 + 'ms'
                    });
                }
            }

            // Open popup menu
            popupMenuOpener.on('click',function(e){
                e.preventDefault();

                if (!popupMenuOpener.hasClass('opened')) {
                    popupMenuOpener.addClass('opened');
                    zen.body.addClass('zen-fullscreen-menu-opened');
                    zen.body.removeClass('zen-fullscreen-fade-out').addClass('zen-fullscreen-fade-in');
                    zen.body.removeClass(cssClass);
                    if(!zen.body.hasClass('page-template-full_screen-php')){
                        zen.modules.common.zenDisableScroll();
                    }
                    $(document).keyup(function(e){
                        if (e.keyCode == 27 ) {
                            popupMenuOpener.removeClass('opened');
                            zen.body.removeClass('zen-fullscreen-menu-opened');
                            zen.body.removeClass('zen-fullscreen-fade-in').addClass('zen-fullscreen-fade-out');
                            zen.body.addClass(cssClass);
                            if(!zen.body.hasClass('page-template-full_screen-php')){
                                zen.modules.common.zenEnableScroll();
                            }
                            $("nav.zen-fullscreen-menu ul.sub_menu").slideUp(200, function(){
                                $('nav.popup_menu').getNiceScroll().resize();
                            });
                        }
                    });
                } else {
                    popupMenuOpener.removeClass('opened');
                    zen.body.removeClass('zen-fullscreen-menu-opened');
                    zen.body.removeClass('zen-fullscreen-fade-in').addClass('zen-fullscreen-fade-out');
                    zen.body.addClass(cssClass);
                    if(!zen.body.hasClass('page-template-full_screen-php')){
                        zen.modules.common.zenEnableScroll();
                    }
                    $("nav.zen-fullscreen-menu ul.sub_menu").slideUp(200, function(){
                        $('nav.popup_menu').getNiceScroll().resize();
                    });
                }
            });

            //logic for open sub menus in popup menu
            menuItemWithChild.on('tap click', function(e) {
                e.preventDefault();

                if ($(this).parent().hasClass('has_sub')) {
                    var submenu = $(this).parent().find('> ul.sub_menu');
                    if (submenu.is(':visible')) {
                        submenu.slideUp(200, function() {
                            popupMenuHolderOuter.getNiceScroll().resize();
                        });
                        $(this).parent().removeClass('open_sub');
                    } else {
                        $(this).parent().addClass('open_sub');
                        submenu.slideDown(200, function() {
                            popupMenuHolderOuter.getNiceScroll().resize();
                        });
                    }
                }
                return false;
            });

            //if link has no submenu and if it's not dead, than open that link
            menuItemWithoutChild.click(function (e) {

                if(($(this).attr('href') !== "http://#") && ($(this).attr('href') !== "#")){

                    if (e.which == 1) {
                        popupMenuOpener.removeClass('opened');
                        zen.body.removeClass('zen-fullscreen-menu-opened');
                        zen.body.removeClass('zen-fullscreen-fade-in').addClass('zen-fullscreen-fade-out');
                        zen.body.addClass(cssClass);
                        $("nav.zen-fullscreen-menu ul.sub_menu").slideUp(200, function(){
                            $('nav.popup_menu').getNiceScroll().resize();
                        });
                        zen.modules.common.zenEnableScroll();
                    }
                }else{
                    return false;
                }

            });

        }



    }

    function zenInitMobileNavigation() {
        var navigationOpener = $('.zen-mobile-header .zen-mobile-menu-opener');
        var navigationHolder = $('.zen-mobile-header .zen-mobile-nav');
        var dropdownOpener = $('.zen-mobile-nav .mobile_arrow, .zen-mobile-nav h4, .zen-mobile-nav a[href*="#"]');
        var animationSpeed = 200;

        //whole mobile menu opening / closing
        if(navigationOpener.length && navigationHolder.length) {
            navigationOpener.on('tap click', function(e) {
                e.stopPropagation();
                e.preventDefault();

                if(navigationHolder.is(':visible')) {
                    navigationOpener.removeClass('opened');
                    navigationHolder.slideUp(animationSpeed);
                } else {
                    navigationOpener.addClass('opened');
                    navigationHolder.slideDown(animationSpeed);
                }
            });
        }

        //dropdown opening / closing
        if(dropdownOpener.length) {
            dropdownOpener.each(function() {
                $(this).on('tap click', function(e) {
                    var dropdownToOpen = $(this).nextAll('ul').first();

                    if(dropdownToOpen.length) {
                        e.preventDefault();
                        e.stopPropagation();

                        var openerParent = $(this).parent('li');
                        if(dropdownToOpen.is(':visible')) {
                            dropdownToOpen.slideUp(animationSpeed);
                            openerParent.removeClass('zen-opened');
                        } else {
                            dropdownToOpen.slideDown(animationSpeed);
                            openerParent.addClass('zen-opened');
                        }
                    }

                });
            });
        }

        $('.zen-mobile-nav a, .zen-mobile-logo-wrapper a').on('click tap', function(e) {
            if($(this).attr('href') !== 'http://#' && $(this).attr('href') !== '#') {
                navigationHolder.slideUp(animationSpeed);
            }
        });
    }

    function zenMobileHeaderBehavior() {
        if(zen.body.hasClass('zen-sticky-up-mobile-header')) {
            var stickyAppearAmount;
            var mobileHeader = $('.zen-mobile-header');
            var adminBar     = $('#wpadminbar');
            var mobileHeaderHeight = mobileHeader.length ? mobileHeader.height() : 0;
            var adminBarHeight = adminBar.length ? adminBar.height() : 0;

            var docYScroll1 = $(document).scrollTop();
            stickyAppearAmount = mobileHeaderHeight + adminBarHeight;

            $(window).scroll(function() {
                var docYScroll2 = $(document).scrollTop();

                if(docYScroll2 > stickyAppearAmount) {
                    mobileHeader.addClass('zen-animate-mobile-header');
                } else {
                    mobileHeader.removeClass('zen-animate-mobile-header');
                }

                if((docYScroll2 > docYScroll1 && docYScroll2 > stickyAppearAmount) || (docYScroll2 < stickyAppearAmount)) {
                    mobileHeader.removeClass('mobile-header-appear');
                    mobileHeader.css('margin-bottom', 0);

                    if(adminBar.length) {
                        mobileHeader.find('.zen-mobile-header-inner').css('top', 0);
                    }
                } else {
                    mobileHeader.addClass('mobile-header-appear');
                    mobileHeader.css('margin-bottom', stickyAppearAmount);

                    //if(adminBar.length) {
                    //    mobileHeader.find('.zen-mobile-header-inner').css('top', adminBarHeight);
                    //}
                }

                docYScroll1 = $(document).scrollTop();
            });
        }

    }


    /**
     * Set dropdown position
     */
    function zenSetDropDownMenuPosition(){

        var menuItems = $(".zen-drop-down > ul > li.narrow");
        menuItems.each( function() {

            var browserWidth = zen.windowWidth;
            var menuItemPosition = $(this).offset().left;
            var dropdownMenuWidth = $(this).find('.second .inner ul').width();

            var menuItemFromLeft = 0;
            if(zen.body.hasClass('boxed')){
                menuItemFromLeft = zen.boxedLayoutWidth  - (menuItemPosition - (browserWidth - zen.boxedLayoutWidth )/2);
            } else {
                menuItemFromLeft = browserWidth - menuItemPosition;
            }

            var dropDownMenuFromLeft; //has to stay undefined beacuse 'dropDownMenuFromLeft < dropdownMenuWidth' condition will be true

            if($(this).find('li.sub').length > 0){
                dropDownMenuFromLeft = menuItemFromLeft - dropdownMenuWidth;
            }

            if(menuItemFromLeft < dropdownMenuWidth || dropDownMenuFromLeft < dropdownMenuWidth){
                $(this).find('.second').addClass('right');
                $(this).find('.second .inner ul').addClass('right');
            }
        });

    }


    function zenDropDownMenu() {

        var menu_items = $('.zen-drop-down > ul > li');

        menu_items.each(function(i) {
            if($(menu_items[i]).find('.second').length > 0) {

                var dropDownSecondDiv = $(menu_items[i]).find('.second');

                if($(menu_items[i]).hasClass('wide')) {

                    var dropdown = $(this).find('.inner > ul');
                    var dropdownPadding = parseInt(dropdown.css('padding-left').slice(0, -2)) + parseInt(dropdown.css('padding-right').slice(0, -2));
                    var dropdownWidth = dropdown.outerWidth();

                    if(!$(this).hasClass('left_position') && !$(this).hasClass('right_position')) {
                        dropDownSecondDiv.css('left', 0);
                    }

                    //set columns to be same height - start
                    var tallest = 0;
                    $(this).find('.second > .inner > ul > li').each(function() {
                        var thisHeight = $(this).height();
                        if(thisHeight > tallest) {
                            tallest = thisHeight;
                        }
                    });
                    $(this).find('.second > .inner > ul > li').css("height", ""); // delete old inline css - via resize
                    $(this).find('.second > .inner > ul > li').height(tallest);
                    //set columns to be same height - end

                    if(!$(this).hasClass('wide_background')) {
                        if(!$(this).hasClass('left_position') && !$(this).hasClass('right_position')) {
                            var left_position = (zen.windowWidth - 2 * (zen.windowWidth - dropdown.offset().left)) / 2 + (dropdownWidth + dropdownPadding) / 2;
                            dropDownSecondDiv.css('left', -left_position);
                        }
                    } else {
                        if(!$(this).hasClass('left_position') && !$(this).hasClass('right_position')) {
                            var left_position = dropdown.offset().left;

                            dropDownSecondDiv.css('left', -left_position);
                            dropDownSecondDiv.css('width', zen.windowWidth);

                        }
                    }
                }

                if(!zen.menuDropdownHeightSet) {
                    $(menu_items[i]).data('original_height', dropDownSecondDiv.height() + 'px');
                    dropDownSecondDiv.height(0);
                }

                if(navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
                    $(menu_items[i]).on("touchstart mouseenter", function() {
                        dropDownSecondDiv.css({
                            'height': $(menu_items[i]).data('original_height'),
                            'overflow': 'visible',
                            'visibility': 'visible',
                            'opacity': '1'
                        });
                    }).on("mouseleave", function() {
                        dropDownSecondDiv.css({
                            'height': '0px',
                            'overflow': 'hidden',
                            'visibility': 'hidden',
                            'opacity': '0'
                        });
                    });

                } else {
                    if(zen.body.hasClass('zen-dropdown-animate-height')) {
                        $(menu_items[i]).mouseenter(function() {
                            dropDownSecondDiv.css({
                                'visibility': 'visible',
                                'height': '0px',
                                'opacity': '0'
                            });
                            dropDownSecondDiv.stop().animate({
                                'height': $(menu_items[i]).data('original_height'),
                                opacity: 1
                            }, 200, function() {
                                dropDownSecondDiv.css('overflow', 'visible');
                            });
                        }).mouseleave(function() {
                            dropDownSecondDiv.stop().animate({
                                'height': '0px'
                            }, 0, function() {
                                dropDownSecondDiv.css({
                                    'overflow': 'hidden',
                                    'visibility': 'hidden'
                                });
                            });
                        });
                    } else {
                        var config = {
                            interval: 0,
                            over: function() {
                                setTimeout(function() {
                                    dropDownSecondDiv.addClass('zen-drop-down-start');
                                    dropDownSecondDiv.stop().css({'height': $(menu_items[i]).data('original_height')});
                                }, 150);
                            },
                            timeout: 150,
                            out: function() {
                                dropDownSecondDiv.stop().css({'height': '0px'});
                                dropDownSecondDiv.removeClass('zen-drop-down-start');
                            }
                        };
                        $(menu_items[i]).hoverIntent(config);
                    }
                }
            }
        });
        $('.zen-drop-down ul li.wide ul li a').on('click', function() {
            var $this = $(this);
            setTimeout(function() {
                $this.mouseleave();
            }, 500);

        });

        //tracker initialization and movement logic
        $('.zen-main-menu .narrow ul').append('<li class="tracker left"></li><li class="tracker right"></li>');

        $('.zen-main-menu .narrow ul li a').hover(function(){
            var linkPos = $(this).parent().position().top + $(this).parent().height()/2 - 6; //
            $(this).parent().siblings('.tracker').stop().animate({top:linkPos+'px',opacity:0.99},150, 'easeOutBack');

        },function(){
            $(this).parent().siblings('.tracker').stop().animate({opacity:0},150);
        });

        zen.menuDropdownHeightSet = true;
    }

    /**
     * Init Search Types
     */
    function zenSearch() {

        var searchOpener = $('a.zen-search-opener'),
            searchClose,
            touch = false;

        if ( $('html').hasClass( 'touch' ) ) {
            touch = true;
        }

        if ( searchOpener.length > 0 ) {
            //Check for type of search

            var fullscreenSearchFade = false,
                fullscreenSearchFromCircle = false;

            searchClose = $( '.zen-fullscreen-search-close' );

            if (zen.body.hasClass('zen-search-fade')) {
                fullscreenSearchFade = true;
            } else if (zen.body.hasClass('zen-search-from-circle')) {
                fullscreenSearchFromCircle = true;
            }
            zenFullscreenSearch( fullscreenSearchFade, fullscreenSearchFromCircle );


            //Check for hover color of search
            if(typeof searchOpener.data('hover-color') !== 'undefined') {
                var changeSearchColor = function(event) {
                    event.data.searchOpener.css('color', event.data.color);
                };

                var originalColor = searchOpener.css('color');
                var hoverColor = searchOpener.data('hover-color');

                searchOpener.on('mouseenter', { searchOpener: searchOpener, color: hoverColor }, changeSearchColor);
                searchOpener.on('mouseleave', { searchOpener: searchOpener, color: originalColor }, changeSearchColor);
            }

        }


        /**
         * Fullscreen search (two types: fade and from circle)
         */
        function zenFullscreenSearch( fade, fromCircle ) {

            var searchHolder = $( '.zen-fullscreen-search-holder'),
                searchOverlay = $( '.zen-fullscreen-search-overlay' ),
                searchField = searchHolder.find('.zen-search-field'),
                searchLine = searchHolder.find('.zen-line');

            searchOpener.click( function(e) {
                e.preventDefault();
                var samePosition = false;
                if ( $(this).data('icon-close-same-position') === 'yes' ) {
                    var closeTop = $(this).offset().top;
                    var closeLeft = $(this).offset().left;
                    samePosition = true;
                }
                //Fullscreen search fade
                if ( fade ) {
                    if ( searchHolder.hasClass( 'zen-animate' ) ) {
                        zen.body.removeClass('zen-fullscreen-search-opened');
                        zen.body.addClass( 'zen-search-fade-out' );
                        zen.body.removeClass( 'zen-search-fade-in' );
                        searchHolder.removeClass( 'zen-animate' );
                        searchField.blur();
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenEnableScroll();
                        }
                    } else {
                        zen.body.addClass('zen-fullscreen-search-opened');
                        zen.body.removeClass('zen-search-fade-out');
                        zen.body.addClass('zen-search-fade-in');
                        searchHolder.addClass('zen-animate');
                        if (samePosition) {
                            searchClose.css({
                                'top' : closeTop - zen.scroll, // Distance from top of viewport ( distance from top of window - scroll distance )
                                'left' : closeLeft
                            });
                        }
						setTimeout(function(){
							searchField.focus();
						},400);
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenDisableScroll();
                        }
                    }
                    searchClose.click( function(e) {
                        e.preventDefault();
                        zen.body.removeClass('zen-fullscreen-search-opened');
                        searchHolder.removeClass('zen-animate');
                        zen.body.removeClass('zen-search-fade-in');
                        zen.body.addClass('zen-search-fade-out');
                        searchHolder.find('input').blur();
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenEnableScroll();
                        }
                    });
                    //Close on escape
                    $(document).keyup(function(e){
                        if (e.keyCode == 27 ) { //KeyCode for ESC button is 27
                            zen.body.removeClass('zen-fullscreen-search-opened');
                            searchHolder.removeClass('zen-animate');
                            zen.body.removeClass('zen-search-fade-in');
                            zen.body.addClass('zen-search-fade-out');
	                        searchField.blur();
                            if(!zen.body.hasClass('page-template-full_screen-php')){
                                zen.modules.common.zenEnableScroll();
                            }
                        }
                    });
                }
                //Fullscreen search from circle
                if ( fromCircle ) {
                    if( searchOverlay.hasClass('zen-animate') ) {
                        searchOverlay.removeClass('zen-animate');
                        searchHolder.css({
                            'opacity': 0,
                            'display':'none'
                        });
                        searchClose.css({
                            'opacity' : 0,
                            'visibility' : 'hidden'
                        });
                        searchOpener.css({
                            'opacity': 1
                        });
                        searchField.blur();
                    } else {
                        searchOverlay.addClass('zen-animate');
                        searchHolder.css({
                            'display':'block'
                        });
                        searchField.focus();
                        setTimeout(function(){
                            searchHolder.css('opacity','1');
                            searchClose.css({
                                'opacity' : 1,
                                'visibility' : 'visible',
                                'top' : closeTop - zen.scroll, // Distance from top of viewport ( distance from top of window - scroll distance )
                                'left' : closeLeft
                            });
                            if (samePosition) {
                                searchClose.css({
                                    'top' : closeTop - zen.scroll, // Distance from top of viewport ( distance from top of window - scroll distance )
                                    'left' : closeLeft
                                });
                            }
                            searchOpener.css({
                                'opacity' : 0
                            });
                        },200);
						setTimeout(function(){
							searchField.focus();
						},400);
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenDisableScroll();
                        }
                    }
                    searchClose.click(function(e) {
                        e.preventDefault();
                        searchOverlay.removeClass('zen-animate');
                        searchHolder.css({
                            'opacity' : 0,
                            'display' : 'none'
                        });
                        searchClose.css({
                            'opacity':0,
                            'visibility' : 'hidden'
                        });
                        searchOpener.css({
                            'opacity' : 1
                        });
                        searchField.blur();
                        if(!zen.body.hasClass('page-template-full_screen-php')){
                            zen.modules.common.zenEnableScroll();
                        }
                    });
                    //Close on escape
                    $(document).keyup(function(e){
                        if (e.keyCode == 27 ) { //KeyCode for ESC button is 27
                            searchOverlay.removeClass('zen-animate');
                            searchHolder.css({
                                'opacity' : 0,
                                'display' : 'none'
                            });
                            searchClose.css({
                                'opacity':0,
                                'visibility' : 'hidden'
                            });
                            searchOpener.css({
                                'opacity' : 1
                            });
                            if(!zen.body.hasClass('page-template-full_screen-php')){
                                zen.modules.common.zenEnableScroll();
                            }
                        }
                    });
                }
            });

            //Text input focus change
            searchField.focus(function(){
                searchLine.css("width","100%");
            });

            searchField.blur(function(){
                searchLine.css("width","0");
            });

        }

    }

    /**
     * Function object that represents vertical menu area.
     * @returns {{init: Function}}
     */
    var zenVerticalMenu = function() {
        /**
         * Main vertical area object that used through out function
         * @type {jQuery object}
         */
        var verticalMenuObject = $('.zen-vertical-menu-area');

        /**
         * Resizes vertical area. Called whenever height of navigation area changes
         * It first check if vertical area is scrollable, and if it is resizes scrollable area
         */
        //var resizeVerticalArea = function() {
        //    if(verticalAreaScrollable()) {
        //        verticalMenuObject.getNiceScroll().resize();
        //    }
        //};

        /**
         * Checks if vertical area is scrollable (if it has zen-with-scroll class)
         *
         * @returns {bool}
         */
        //var verticalAreaScrollable = function() {
        //    return verticalMenuObject.hasClass('.zen-with-scroll');
        //};

        /**
         * Initialzes navigation functionality. It checks navigation type data attribute and calls proper functions
         */
        var initNavigation = function() {
            var verticalNavObject = verticalMenuObject.find('.zen-vertical-menu');
            var navigationType = typeof verticalNavObject.data('navigation-type') !== 'undefined' ? verticalNavObject.data('navigation-type') : '';

            switch(navigationType) {
                //case 'dropdown-toggle':
                //    dropdownHoverToggle();
                //    break;
                //case 'dropdown-toggle-click':
                //    dropdownClickToggle();
                //    break;
                //case 'float':
                //    dropdownFloat();
                //    break;
                //case 'slide-in':
                //    dropdownSlideIn();
                //    break;
                default:
                    dropdownFloat();
                    break;
            }

            /**
             * Initializes hover toggle navigation type. It has separate functionalities for touch and no-touch devices
             */
            //function dropdownHoverToggle() {
            //    var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
            //
            //    menuItems.each(function() {
            //        var elementToExpand = $(this).find(' > .second, > ul');
            //        var numberOfChildItems = elementToExpand.find(' > .inner > ul > li, > li').length;
            //
            //        var animSpeed = numberOfChildItems * 40;
            //        var animFunc = 'easeInOutSine';
            //        var that = this;
            //
            //        //touch devices functionality
            //        if(Modernizr.touch) {
            //            var dropdownOpener = $(this).find('> a');
            //
            //            dropdownOpener.on('click tap', function(e) {
            //                e.preventDefault();
            //                e.stopPropagation();
            //
            //                if(elementToExpand.is(':visible')) {
            //                    $(that).removeClass('open');
            //                    elementToExpand.slideUp(animSpeed, animFunc, function() {
            //                        resizeVerticalArea();
            //                    });
            //                } else {
            //                    $(that).addClass('open');
            //                    elementToExpand.slideDown(animSpeed, animFunc, function() {
            //                        resizeVerticalArea();
            //                    });
            //                }
            //            });
            //        } else {
            //            $(this).hover(function() {
            //                $(that).addClass('open');
            //                elementToExpand.slideDown(animSpeed, animFunc, function() {
            //                    resizeVerticalArea();
            //                });
            //            }, function() {
            //                setTimeout(function() {
            //                    $(that).removeClass('open');
            //                    elementToExpand.slideUp(animSpeed, animFunc, function() {
            //                        resizeVerticalArea();
            //                    });
            //                }, 1000);
            //            });
            //        }
            //    });
            //}

            /**
             * Initializes click toggle navigation type. Works the same for touch and no-touch devices
             */
            //function dropdownClickToggle() {
            //    var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
            //
            //    menuItems.each(function() {
            //        var elementToExpand = $(this).find(' > .second, > ul');
            //        var menuItem = this;
            //        var dropdownOpener = $(this).find('> a');
            //        var slideUpSpeed = 'fast';
            //        var slideDownSpeed = 'slow';
            //
            //        dropdownOpener.on('click tap', function(e) {
            //            e.preventDefault();
            //            e.stopPropagation();
            //
            //            if(elementToExpand.is(':visible')) {
            //                $(menuItem).removeClass('open');
            //                elementToExpand.slideUp(slideUpSpeed, function() {
            //                    resizeVerticalArea();
            //                });
            //            } else {
            //                if(!$(this).parents('li').hasClass('open')) {
            //                    menuItems.removeClass('open');
            //                    menuItems.find(' > .second, > ul').slideUp(slideUpSpeed);
            //                }
            //
            //                $(menuItem).addClass('open');
            //                elementToExpand.slideDown(slideDownSpeed, function() {
            //                    resizeVerticalArea();
            //                });
            //            }
            //        });
            //    });
            //}

            /**
             * Initializes floating navigation type (it comes from the side as a dropdown)
             */
            function dropdownFloat() {
                var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
                var allDropdowns = menuItems.find(' > .second, > ul');

                menuItems.each(function() {
                    var elementToExpand = $(this).find(' > .second, > ul');
                    var menuItem = this;

                    if(Modernizr.touch) {
                        var dropdownOpener = $(this).find('> a');

                        dropdownOpener.on('click tap', function(e) {
                            e.preventDefault();
                            e.stopPropagation();

                            if(elementToExpand.hasClass('zen-float-open')) {
                                elementToExpand.removeClass('zen-float-open');
                                $(menuItem).removeClass('open');
                            } else {
                                if(!$(this).parents('li').hasClass('open')) {
                                    menuItems.removeClass('open');
                                    allDropdowns.removeClass('zen-float-open');
                                }

                                elementToExpand.addClass('zen-float-open');
                                $(menuItem).addClass('open');
                            }
                        });
                    } else {
                        //must use hoverIntent because basic hover effect doesn't catch dropdown
                        //it doesn't start from menu item's edge
                        $(this).hoverIntent({
                            over: function() {
                                elementToExpand.addClass('zen-float-open');
                                $(menuItem).addClass('open');
                            },
                            out: function() {
                                elementToExpand.removeClass('zen-float-open');
                                $(menuItem).removeClass('open');
                            },
                            timeout: 300
                        });
                    }
                });
            }

            /**
             * Initializes slide in navigation type (dropdowns are coming on top of parent element and cover whole navigation area)
             */
            //function dropdownSlideIn() {
            //    var menuItems = verticalNavObject.find('ul li.menu-item-has-children');
            //    var menuItemsLinks = menuItems.find('> a');
            //
            //    menuItemsLinks.each(function() {
            //        var elementToExpand = $(this).next('.second, ul');
            //        appendToExpandableElement(elementToExpand, this);
            //
            //        if($(this).parent('li').is('.current-menu-ancestor', '.current_page_parent', '.current-menu-parent ')) {
            //            elementToExpand.addClass('zen-vertical-slide-open');
            //        }
            //
            //        $(this).on('click tap', function(e) {
            //            e.preventDefault();
            //            e.stopPropagation();
            //
            //            menuItems.removeClass('open');
            //
            //            $(this).parent('li').addClass('open');
            //            elementToExpand.addClass('zen-vertical-slide-open');
            //        });
            //    });
            //
            //    var previousLevelItems = menuItems.find('li.zen-previous-level > a');
            //
            //    previousLevelItems.on('click tap', function(e) {
            //        e.preventDefault();
            //        e.stopPropagation();
            //
            //        menuItems.removeClass('open');
            //        $(this).parents('.zen-vertical-slide-open').first().removeClass('zen-vertical-slide-open');
            //    });
            //
            //    /**
            //     * Appends 'li' element as first element in dropdown, which will close current dropdown when clicked
            //     * @param {jQuery object} elementToExpand current dropdown to append element to
            //     * @param currentMenuItem
            //     */
            //    function appendToExpandableElement(elementToExpand, currentMenuItem) {
            //        var itemUrl = $(currentMenuItem).attr('href');
            //        var itemText = $(currentMenuItem).text();
            //
            //        var liItem = $('<li />', {class: 'zen-previous-level'});
            //
            //        $('<a />', {
            //            'href': itemUrl,
            //            'html': '<i class="zen-vertical-slide-arrow fa fa-angle-left"></i>' + itemText
            //        }).appendTo(liItem);
            //
            //        if(elementToExpand.hasClass('second')) {
            //            elementToExpand.find('> div > ul').prepend(liItem);
            //        } else {
            //            elementToExpand.prepend(liItem);
            //        }
            //    }
            //}
        };

        /**
         * Initializes scrolling in vertical area. It checks if vertical area is scrollable before doing so
         */
        //var initVerticalAreaScroll = function() {
        //    if(verticalAreaScrollable()) {
        //        verticalMenuObject.niceScroll({
        //            scrollspeed: 60,
        //            mousescrollstep: 40,
        //            cursorwidth: 0,
        //            cursorborder: 0,
        //            cursorborderradius: 0,
        //            cursorcolor: "transparent",
        //            autohidemode: false,
        //            horizrailenabled: false
        //        });
        //    }
        //};

        //var initHiddenVerticalArea = function() {
        //    var verticalLogo = $('.zen-vertical-area-bottom-logo');
        //    var verticalMenuOpener = verticalMenuObject.find('.zen-vertical-menu-hidden-button');
        //    var scrollPosition = 0;
        //
        //    verticalMenuOpener.on('click tap', function() {
        //        if(isVerticalAreaOpen()) {
        //            closeVerticalArea();
        //        } else {
        //            openVerticalArea();
        //        }
        //    });
        //
        //    //take click outside vertical left/right area and close it
        //    $j(verticalMenuObject).outclick({
        //        callback: function() {
        //            closeVerticalArea();
        //        }
        //    });
        //
        //    $(window).scroll(function() {
        //        if(Math.abs($(window).scrollTop() - scrollPosition) > 400){
        //            closeVerticalArea();
        //        }
        //    });
        //
        //    /**
        //     * Closes vertical menu area by removing 'active' class on that element
        //     */
        //    function closeVerticalArea() {
        //        verticalMenuObject.removeClass('active');
        //
        //        if(verticalLogo.length) {
        //            verticalLogo.removeClass('active');
        //        }
        //    }
        //
        //    /**
        //     * Opens vertical menu area by adding 'active' class on that element
        //     */
        //    function openVerticalArea() {
        //        verticalMenuObject.addClass('active');
        //
        //        if(verticalLogo.length) {
        //            verticalLogo.addClass('active');
        //        }
        //
        //        scrollPosition = $(window).scrollTop();
        //    }
        //
        //    function isVerticalAreaOpen() {
        //        return verticalMenuObject.hasClass('active');
        //    }
        //};

        return {
            /**
             * Calls all necessary functionality for vertical menu area if vertical area object is valid
             */
            init: function() {
                if(verticalMenuObject.length) {
                    initNavigation();
                    //initVerticalAreaScroll();
                    //
                    //if(zen.body.hasClass('zen-vertical-header-hidden')) {
                    //    initHiddenVerticalArea();
                    //}
                }
            }
        };
    };

})(jQuery);
(function($) {
    "use strict";

    var title = {};
    zen.modules.title = title;

    title.zenParallaxTitle = zenParallaxTitle;

    title.zenOnDocumentReady = zenOnDocumentReady;
    title.zenOnWindowLoad = zenOnWindowLoad;
    title.zenOnWindowResize = zenOnWindowResize;
    title.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenParallaxTitle();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {

    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {

    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {

    }
    

    /*
     **	Title image with parallax effect
     */
    function zenParallaxTitle(){
        if($('.zen-title.zen-has-parallax-background').length > 0 && $('.touch').length === 0){

            var parallaxBackground = $('.zen-title.zen-has-parallax-background');
            var parallaxBackgroundWithZoomOut = $('.zen-title.zen-has-parallax-background.zen-zoom-out');

            var backgroundSizeWidth = parseInt(parallaxBackground.data('background-width').match(/\d+/));
            var titleHolderHeight = parallaxBackground.data('height');
            var titleRate = (titleHolderHeight / 10000) * 7;
            var titleYPos = -(zen.scroll * titleRate);

            //set position of background on doc ready
            parallaxBackground.css({'background-position': 'center '+ (titleYPos+zenGlobalVars.vars.zenAddForAdminBar) +'px' });
            parallaxBackgroundWithZoomOut.css({'background-size': backgroundSizeWidth-zen.scroll + 'px auto'});

            //set position of background on window scroll
            $(window).scroll(function() {
                titleYPos = -(zen.scroll * titleRate);
                parallaxBackground.css({'background-position': 'center ' + (titleYPos+zenGlobalVars.vars.zenAddForAdminBar) + 'px' });
                parallaxBackgroundWithZoomOut.css({'background-size': backgroundSizeWidth-zen.scroll + 'px auto'});
            });

        }
    }

})(jQuery);

(function($) {
    'use strict';

    var shortcodes = {};

    zen.modules.shortcodes = shortcodes;

    shortcodes.zenInitCounter = zenInitCounter;
    shortcodes.zenInitProgressBars = zenInitProgressBars;
    shortcodes.zenInitCountdown = zenInitCountdown;
    shortcodes.zenInitTestimonials = zenInitTestimonials;
    shortcodes.zenInitCarousels = zenInitCarousels;
    shortcodes.zenInitPieChart = zenInitPieChart;
    shortcodes.zenInitTabs = zenInitTabs;
    shortcodes.zenInitTabIcons = zenInitTabIcons;
    shortcodes.zenCustomFontResize = zenCustomFontResize;
    shortcodes.zenInitImageGallery = zenInitImageGallery;
    shortcodes.zenInitAccordions = zenInitAccordions;
    shortcodes.zenShowGoogleMap = zenShowGoogleMap;
    shortcodes.zenInitPortfolioListMasonry = zenInitPortfolioListMasonry;
    shortcodes.zenInitPortfolioListPinterest = zenInitPortfolioListPinterest;
    shortcodes.zenInitPortfolio = zenInitPortfolio;
    shortcodes.zenInitPortfolioMasonryFilter = zenInitPortfolioMasonryFilter;
    shortcodes.zenInitPortfolioLoadMore = zenInitPortfolioLoadMore;
    shortcodes.zenProcessSlider = zenProcessSlider;

    shortcodes.zenOnDocumentReady = zenOnDocumentReady;
    shortcodes.zenOnWindowLoad = zenOnWindowLoad;
    shortcodes.zenOnWindowResize = zenOnWindowResize;
    shortcodes.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);

    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenInitCounter();
        zenInitProgressBars();
        zenInitCountdown();
        zenIcon().init();
        zenInitTestimonials();
        zenInitCarousels();
        zenInitPieChart();
        zenInitTabs();
        zenInitTabIcons();
        zenButton().init();
        zenCustomFontResize();
        zenInitImageGallery();
        zenInitAccordions();
        zenShowGoogleMap();
        zenInitPortfolioListMasonry();
        zenInitPortfolioListPinterest();
        zenInitPortfolio();
        zenInitPortfolioMasonryFilter();
        zenInitPortfolioLoadMore();
        zenInitPortfolioSingleArrows();
        zenSocialIconWidget().init();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {
        zenButton().initArrowType();
        zenProcessSlider();
        setTimeout(function(){
            zenProcessScroll();
        },1000); //beacuse of the safari mac and width calcs problems

        zen.modules.common.zenInitParallax();
    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
        zenCustomFontResize();
        zenInitPortfolioListMasonry();
        zenInitPortfolioListPinterest();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {
        
    }

    /**
     * Counter Shortcode
     */
    function zenInitCounter() {

        var counters = $('.zen-counter');


        if (counters.length) {
            counters.each(function() {
                var counter = $(this);
                counter.appear(function() {
                    counter.parent().addClass('zen-counter-holder-show');

                    //Counter zero type
                    if (counter.hasClass('zero')) {
                        var max = parseFloat(counter.text());
                        counter.countTo({
                            from: 0,
                            to: max,
                            speed: 1500,
                            refreshInterval: 100
                        });
                    } else {
                        counter.absoluteCounter({
                            speed: 2000,
                            fadeInDelay: 1000
                        });
                    }

                },{accX: 0, accY: zenGlobalVars.vars.zenElementAppearAmount});
            });
        }

    }
    
    /*
    **	Horizontal progress bars shortcode
    */
    function zenInitProgressBars(){
        
        var progressBar = $('.zen-progress-bar');
        
        if(progressBar.length){
            
            progressBar.each(function() {
                
                var thisBar = $(this);
                
                thisBar.appear(function() {
                    zenInitToCounterProgressBar(thisBar);
                    if(thisBar.find('.zen-floating.zen-floating-inside') !== 0){
                        var floatingInsideMargin = thisBar.find('.zen-progress-content').height();
                        floatingInsideMargin += parseFloat(thisBar.find('.zen-progress-title-holder').css('padding-bottom'));
                        floatingInsideMargin += parseFloat(thisBar.find('.zen-progress-title-holder').css('margin-bottom'));
                        thisBar.find('.zen-floating-inside').css('margin-bottom',-(floatingInsideMargin)+'px');
                    }
                    var percentage = thisBar.find('.zen-progress-content').data('percentage'),
                        progressContent = thisBar.find('.zen-progress-content'),
                        progressNumber = thisBar.find('.zen-progress-number');

                    progressContent.css('width', '0%');
                    progressContent.animate({'width': percentage+'%'}, 1500);
                    progressNumber.css('left', '0%');
                    if (!thisBar.hasClass('zen-progress-on-side')){
                        progressNumber.animate({'left': percentage+'%'}, 1500);
                    }

                });
            });
        }
    }

    /*
    **	Counter for horizontal progress bars percent from zero to defined percent
    */
    function zenInitToCounterProgressBar(progressBar){
        var percentage = parseFloat(progressBar.find('.zen-progress-content').data('percentage'));
        var percent = progressBar.find('.zen-progress-number .zen-percent');
        if(percent.length) {
            percent.each(function() {
                var thisPercent = $(this);
                thisPercent.parents('.zen-progress-number-wrapper').css('opacity', '1');
                thisPercent.countTo({
                    from: 0,
                    to: percentage,
                    speed: 1500,
                    refreshInterval: 50
                });
            });
        }
    }

    /**
     * Countdown Shortcode
     */
    function zenInitCountdown() {

        var countdowns = $('.zen-countdown'),
            year,
            month,
            day,
            hour,
            minute,
            timezone,
            monthLabel,
            dayLabel,
            hourLabel,
            minuteLabel,
            secondLabel;

        if (countdowns.length) {

            countdowns.each(function(){

                //Find countdown elements by id-s
                var countdownId = $(this).attr('id'),
                    countdown = $('#'+countdownId),
                    digitFontSize,
                    labelFontSize;

                //Get data for countdown
                year = countdown.data('year');
                month = countdown.data('month');
                day = countdown.data('day');
                hour = countdown.data('hour');
                minute = countdown.data('minute');
                timezone = countdown.data('timezone');
                monthLabel = countdown.data('month-label');
                dayLabel = countdown.data('day-label');
                hourLabel = countdown.data('hour-label');
                minuteLabel = countdown.data('minute-label');
                secondLabel = countdown.data('second-label');
                digitFontSize = countdown.data('digit-size');
                labelFontSize = countdown.data('label-size');


                //Initialize countdown
                countdown.countdown({
                    until: new Date(year, month - 1, day, hour, minute, 44),
                    labels: ['Years', monthLabel, 'Weeks', dayLabel, hourLabel, minuteLabel, secondLabel],
                    format: 'ODHMS',
                    timezone: timezone,
                    padZeroes: true,
                    onTick: setCountdownStyle
                });

                function setCountdownStyle() {
                    countdown.find('.countdown-amount').css({
                        'font-size' : digitFontSize+'px',
                        'line-height' : digitFontSize+'px'
                    });
                    countdown.find('.countdown-period').css({
                        'font-size' : labelFontSize+'px'
                    });
                }

            });

        }

    }

    /**
     * Object that represents icon shortcode
     * @returns {{init: Function}} function that initializes icon's functionality
     */
    var zenIcon = zen.modules.shortcodes.zenIcon = function() {
        //get all icons on page
        var icons = $('.zen-icon-shortcode');

        /**
         * Function that triggers icon animation and icon animation delay
         */
        var iconAnimation = function(icon) {
            if(icon.hasClass('zen-icon-animation')) {
                icon.appear(function() {
                    icon.parent('.zen-icon-animation-holder').addClass('zen-icon-animation-show');
                }, {accX: 0, accY: zenGlobalVars.vars.zenElementAppearAmount});
            }
        };

        /**
         * Function that triggers icon hover color functionality
         */
        var iconHoverColor = function(icon) {
            if(typeof icon.data('hover-color') !== 'undefined') {
                var changeIconColor = function(event) {
                    event.data.icon.css('color', event.data.color);
                };

                var iconElement = icon.find('.zen-icon-element');
                var hoverColor = icon.data('hover-color');
                var originalColor = iconElement.css('color');

                if(hoverColor !== '') {
                    icon.on('mouseenter', {icon: iconElement, color: hoverColor}, changeIconColor);
                    icon.on('mouseleave', {icon: iconElement, color: originalColor}, changeIconColor);
                }
            }
        };

        /**
         * Function that triggers icon holder background color hover functionality
         */
        var iconHolderBackgroundHover = function(icon) {
            if(typeof icon.data('hover-background-color') !== 'undefined') {
                var changeIconBgColor = function(event) {
                    event.data.icon.css('background-color', event.data.color);
                };

                var hoverBackgroundColor = icon.data('hover-background-color');
                var originalBackgroundColor = icon.css('background-color');

                if(hoverBackgroundColor !== '') {
                    icon.on('mouseenter', {icon: icon, color: hoverBackgroundColor}, changeIconBgColor);
                    icon.on('mouseleave', {icon: icon, color: originalBackgroundColor}, changeIconBgColor);
                }
            }
        };

        /**
         * Function that initializes icon holder border hover functionality
         */
        var iconHolderBorderHover = function(icon) {
            if(typeof icon.data('hover-border-color') !== 'undefined') {
                var changeIconBorder = function(event) {
                    event.data.icon.css('border-color', event.data.color);
                };

                var hoverBorderColor = icon.data('hover-border-color');
                var originalBorderColor = icon.css('border-color');

                if(hoverBorderColor !== '') {
                    icon.on('mouseenter', {icon: icon, color: hoverBorderColor}, changeIconBorder);
                    icon.on('mouseleave', {icon: icon, color: originalBorderColor}, changeIconBorder);
                }
            }
        };

        return {
            init: function() {
                if(icons.length) {
                    icons.each(function() {
                        iconAnimation($(this));
                        iconHoverColor($(this));
                        iconHolderBackgroundHover($(this));
                        iconHolderBorderHover($(this));
                    });

                }
            }
        };
    };

    /**
     * Object that represents social icon widget
     * @returns {{init: Function}} function that initializes icon's functionality
     */
    var zenSocialIconWidget = zen.modules.shortcodes.zenSocialIconWidget = function() {
        //get all social icons on page
        var icons = $('.zen-social-icon-widget-holder');

        /**
         * Function that triggers icon hover color functionality
         */
        var socialIconHoverColor = function(icon) {
            if(typeof icon.data('hover-color') !== 'undefined') {
                var changeIconColor = function(event) {
                    event.data.icon.css('color', event.data.color);
                };

                var iconElement = icon;
                var hoverColor = icon.data('hover-color');
                var originalColor = iconElement.css('color');

                if(hoverColor !== '') {
                    icon.on('mouseenter', {icon: iconElement, color: hoverColor}, changeIconColor);
                    icon.on('mouseleave', {icon: iconElement, color: originalColor}, changeIconColor);
                }
            }
        };

        return {
            init: function() {
                if(icons.length) {
                    icons.each(function() {
                        socialIconHoverColor($(this));
                    });

                }
            }
        };
    };

    /**
     * Init testimonials shortcode
     */
    function zenInitTestimonials(){

        var testimonial = $('.zen-testimonials');
        if(testimonial.length){
            testimonial.each(function(){

                var thisTestimonial = $(this);

                thisTestimonial.appear(function() {
                    thisTestimonial.css('visibility','visible');
                },{accX: 0, accY: zenGlobalVars.vars.zenElementAppearAmount});

                var interval = 400;
                var controlNav = false;
                var directionNav = true;
                var animationSpeed = 5000;
                if(typeof thisTestimonial.data('animation-speed') !== 'undefined' && thisTestimonial.data('animation-speed') !== false) {
                    animationSpeed = thisTestimonial.data('animation-speed');
                }

                //var iconClasses = getIconClassesForNavigation(directionNavArrowsTestimonials); TODO

                thisTestimonial.owlCarousel({
                    singleItem: true,
                    autoPlay: animationSpeed,
                    navigation: directionNav,
                    transitionStyle : 'goDown', //fade, fadeUp, backSlide, goDown
                    autoHeight: true,
                    pagination: controlNav,
                    slideSpeed: interval,
                    addClassActive: true,
                    mouseDrag: false,
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i></span>'
                    ],
                    afterMove: afterMove
                });

            	var navPrev = thisTestimonial.find('.owl-prev');

            	navPrev.after('<span class="zen-nav-line"></span><span class="zen-nav-line zen-line-second"></span>');

				function afterMove(){
					var testimonialItem = thisTestimonial.find('.owl-item.active');
					var testimonialItemImageHeight = parseInt(testimonialItem.find('.zen-testimonial-image-holder').height());
					var testimonialItemImageWidth = parseInt(testimonialItem.find('.zen-testimonial-image-holder img').width());
					var testimonialItemTextHeight = parseInt(testimonialItem.find('.zen-testimonial-text').outerHeight(true));
					var navHolder = thisTestimonial.find('.owl-buttons');
					var navHolderLine = navHolder.find('.zen-nav-line');
					var navHolderLineSecond = navHolder.find('.zen-nav-line.zen-line-second');
					var navNext = navHolder.find('.owl-next');

					if (isNaN(testimonialItemImageHeight)){
						testimonialItemImageHeight = 96; //if image height is NaN set it to height of prev/next navigation + margin in order to separate it from text
					}
					if (isNaN(testimonialItemImageWidth)){
						testimonialItemImageWidth = 0;
					}

					var testimonialNavTop = testimonialItemTextHeight+testimonialItemImageHeight/2; //calculate navigation top position

					navHolder.animate({top: testimonialNavTop});
					navHolderLine.css('width',255); //add width to lines
					navHolderLineSecond.css('left',testimonialItemImageWidth); //move second line for image width
					navNext.css('left',testimonialItemImageWidth); //move next nav for image width
					navHolder.css('width',testimonialItemImageWidth + 610); //set navigation holder width as image width + 2 line widths + prev and next width (all in all 310)

                }

                afterMove();

            });

        }

    }

    /**
     * Init Carousel shortcode
     */
    function zenInitCarousels() {

        var carouselHolders = $('.zen-carousel-holder'),
            carousel,
            numberOfItems,
            navigation;

        if (carouselHolders.length) {
            carouselHolders.each(function(){
                carousel = $(this).children('.zen-carousel');
                numberOfItems = carousel.data('items');
                navigation = (carousel.data('navigation') == 'yes') ? true : false;

                //Responsive breakpoints
                var items = [
                    [0,1],
                    [480,2],
                    [768,3],
                    [1024,numberOfItems]
                ];

                carousel.owlCarousel({
                    autoPlay: 3000,
                    items: numberOfItems,
                    itemsCustom: items,
                    pagination: false,
                    navigation: navigation,
                    slideSpeed: 600,
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i></span>'
                    ]
                });

                //appear
                carouselHolders.css('visibility','visible');
                carouselHolders.animate({opacity:1},300);

                var singleCarouselItem = carousel.find('.zen-carousel-item-holder');

                carouselHolders.appear(function(){
                    setTimeout(function(){
                        singleCarouselItem.each(function(i){
                            var thisItem = $(this);
                            thisItem.delay(i*120).animate({opacity:1,left:0},200,'easeOutSine');
                        });
                    },50);
                },{accX: 0, accY: zenGlobalVars.vars.zenElementAppearAmount});

            });
        }

    }

    /**
     * Init Pie Chart and Pie Chart With Icon shortcode
     */
    function zenInitPieChart() {

        var pieCharts = $('.zen-pie-chart-holder, .zen-pie-chart-with-icon-holder');

        if (pieCharts.length) {

            pieCharts.each(function () {

                var pieChart = $(this),
                    percentageHolder = pieChart.children('.zen-percentage, .zen-percentage-with-icon'),
                    barColor = zenGlobalVars.vars.zenFirstColor,
                    trackColor = '#dedede',
                    lineWidth,
                    size = 190;

                percentageHolder.appear(function() {
                    initToCounterPieChart(pieChart);
                    percentageHolder.css('opacity', '1');

                    percentageHolder.easyPieChart({
                        barColor: barColor,
                        trackColor: trackColor,
                        scaleColor: false,
                        lineCap: 'butt',
                        lineWidth: lineWidth,
                        animate: 1500,
                        size: size
                    });
                },{accX: 0, accY: zenGlobalVars.vars.zenElementAppearAmount});

            });

        }

    }

    /*
     **	Counter for pie chart number from zero to defined number
     */
    function initToCounterPieChart( pieChart ){

        pieChart.css('opacity', '1');
        var counter = pieChart.find('.zen-to-counter'),
            max = parseFloat(counter.text());
        counter.countTo({
            from: 0,
            to: max,
            speed: 1500,
            refreshInterval: 50
        });

    }

    /*
    **	Init tabs shortcode
    */
    function zenInitTabs(){

       var tabs = $('.zen-tabs');
        if(tabs.length){
            tabs.each(function(){
                var thisTabs = $(this),
                	backgroundHolderBckg = '';

                thisTabs.children('.zen-tab-container').each(function(index){
                    index = index + 1;
                    var that = $(this),
                        link = that.attr('id'),
                        navItem = that.parent().find('.zen-tabs-nav li:nth-child('+index+') a'),
                        navLink = navItem.attr('href');

                    link = '#'+link;

                    if(link.indexOf(navLink) > -1) {
                        navItem.attr('href',link);
                    }
                });

                var columnHolderBckg = thisTabs.closest('.wpb_column').css('background-color');
                var rowHolderBckg = thisTabs.closest('.vc_row').css('background-color');
                if(columnHolderBckg !== 'rgba(0, 0, 0, 0)' && columnHolderBckg !== 'transparent'){
                	backgroundHolderBckg = columnHolderBckg;
                }
                else if(rowHolderBckg !== 'rgba(0, 0, 0, 0)' && rowHolderBckg !== 'transparent'){
                	backgroundHolderBckg = rowHolderBckg;
                }

                if(thisTabs.hasClass('zen-horizontal')){
                    thisTabs.tabs();
                }
                else if(thisTabs.hasClass('zen-vertical')){
                    thisTabs.tabs({
						activate: function(){
							if (backgroundHolderBckg !== ''){
								thisTabs.find('li.ui-state-active a').css('background-color',backgroundHolderBckg);
							}
							zenButton().initArrowType();
						},
						beforeActivate: function(){
							if (backgroundHolderBckg !== ''){
								thisTabs.find('li.ui-state-active a').css('background-color','transparent');
							}
						}
                    }).addClass( 'ui-tabs-vertical ui-helper-clearfix' );
                    thisTabs.find('.zen-tabs-nav > ul >li').removeClass( 'ui-corner-top' ).addClass( 'ui-corner-left' );
					if (backgroundHolderBckg !== ''){
						thisTabs.find('li.ui-state-active a').css('background-color',backgroundHolderBckg);
					}
                }
            });
        }
    }

    /*
    **	Generate icons in tabs navigation
    */
    function zenInitTabIcons(){

        var tabContent = $('.zen-tab-container');
        if(tabContent.length){

            tabContent.each(function(){
                var thisTabContent = $(this);

                var id = thisTabContent.attr('id');
                var icon = '';
                if(typeof thisTabContent.data('icon-html') !== 'undefined' || thisTabContent.data('icon-html') !== 'false') {
                    icon = thisTabContent.data('icon-html');
                }

                var tabNav = thisTabContent.parents('.zen-tabs').find('.zen-tabs-nav > li > a[href="#'+id+'"]');

                if(typeof(tabNav) !== 'undefined') {
                    tabNav.children('.zen-icon-frame').append(icon);
                }
            });
        }
    }

    /**
     * Button object that initializes whole button functionality
     * @type {Function}
     */
    var zenButton = zen.modules.shortcodes.zenButton = function() {
        //all buttons on the page
        var buttons = $('.zen-btn');
        var buttonsArrowType = $('.zen-btn.zen-btn-arrow');

        /**
         * Initializes button hover color
         * @param button current button
         */
        var buttonHoverColor = function(button) {
            if(typeof button.data('hover-color') !== 'undefined') {
                var changeButtonColor = function(event) {
                    event.data.button.css('color', event.data.color);
                };

                var originalColor = button.css('color');
                var hoverColor = button.data('hover-color');

                button.on('mouseenter', { button: button, color: hoverColor }, changeButtonColor);
                button.on('mouseleave', { button: button, color: originalColor }, changeButtonColor);
            }
        };



        /**
         * Initializes button hover background color
         * @param button current button
         */
        var buttonHoverBgColor = function(button) {
            if(typeof button.data('hover-bg-color') !== 'undefined') {
                var changeButtonBg = function(event) {
                    event.data.button.css('background-color', event.data.color);
                };

                var originalBgColor = button.css('background-color');
                var hoverBgColor = button.data('hover-bg-color');

                button.on('mouseenter', { button: button, color: hoverBgColor }, changeButtonBg);
                button.on('mouseleave', { button: button, color: originalBgColor }, changeButtonBg);
            }
        };

        /**
         * Initializes button border color
         * @param button
         */
        var buttonHoverBorderColor = function(button) {
            if(typeof button.data('hover-border-color') !== 'undefined') {
                var changeBorderColor = function(event) {
                    event.data.button.css('border-color', event.data.color);
                };

                var originalBorderColor = button.css('borderTopColor'); //take one of the four sides
                var hoverBorderColor = button.data('hover-border-color');

                button.on('mouseenter', { button: button, color: hoverBorderColor }, changeBorderColor);
                button.on('mouseleave', { button: button, color: originalBorderColor }, changeBorderColor);
            }
        };

        /*
        * Button type arrow width
        * @param button
        */
        var buttonArrowWidth = function(button) {
        	button.addClass('zen-btn-visible');

        	var buttonArrowTextWidth = parseInt(button.find('.zen-btn-text').width());
        	var buttonArrowIconWidth = parseInt(button.find('.zen-btn-icon-arrow').width());
        	var buttonWidth;

            if (button.hasClass('zen-btn-rotate')) {
            	if (buttonArrowIconWidth > buttonArrowTextWidth){
            		buttonWidth = buttonArrowIconWidth;
            	}
            	else{
            		buttonWidth = buttonArrowTextWidth;
            	}

                button.animate({width: buttonWidth + 20 + 'px'});  //20 to ensure text visibility during the animation

            } else if (button.hasClass('zen-btn-hide-text')) {

                buttonWidth = buttonArrowIconWidth + buttonArrowTextWidth + 15; //15 empty space between arrow and text
                var textPadding = buttonArrowIconWidth;

                button.animate({width: buttonWidth + 'px'});
            	var buttonText = button.find('.zen-btn-text');
            	var buttonArrow = button.find('.zen-btn-icon-arrow');
                buttonText.css({'padding-left':textPadding + 15 +'px'}); //15 empty space between arrow and text

                button.on('mouseenter touch',function(){
					buttonArrow.css('width','85%');
                    buttonText.css({'-webkit-transform':'translateX('+(buttonArrowTextWidth+3)+'px)'}); //3 for hiding text fully when translating
                    buttonText.css({'transform':'translateX('+(buttonArrowTextWidth+3)+'px)'}); //3 for hiding text fully when translating
                });
                button.on('mouseleave',function(){
                	buttonArrow.css('width',buttonArrowIconWidth);
                    buttonText.css({'-webkit-transform':'translateX(0px)'});
                    buttonText.css({'transform':'translateX(0px)'});
                });
            }

            
        };

        return {
            init: function() {
                if(buttons.length) {
                    buttons.each(function() {
                        buttonHoverColor($(this));
                        buttonHoverBgColor($(this));
                        buttonHoverBorderColor($(this));
                    });
                }
            },
            initArrowType: function() {
                if(buttonsArrowType.length) {
                    buttonsArrowType.each(function() {
                        buttonArrowWidth($(this));
                    });
                }
            }
        };
    };
    

	/*
	**	Custom Font resizing
	*/
	function zenCustomFontResize(){
		var customFont = $('.zen-custom-font-holder');
		if (customFont.length){
			customFont.each(function(){
				var thisCustomFont = $(this);
				var fontSize;
				var lineHeight;
				var coef1 = 1;
				var coef2 = 1;

				if (zen.windowWidth < 1200){
					coef1 = 0.8;
				}

				if (zen.windowWidth < 1000){
					coef1 = 0.7;
				}

				if (zen.windowWidth < 768){
					coef1 = 0.6;
					coef2 = 0.7;
				}

				if (zen.windowWidth < 600){
					coef1 = 0.4;
					coef2 = 0.6;
				}

				if (zen.windowWidth < 480){
					coef1 = 0.3;
					coef2 = 0.5;
				}

				if (typeof thisCustomFont.data('font-size') !== 'undefined' && thisCustomFont.data('font-size') !== false) {
					fontSize = parseInt(thisCustomFont.data('font-size'));

					if (fontSize > 70) {
						fontSize = Math.round(fontSize*coef1);
					}
					else if (fontSize > 35) {
						fontSize = Math.round(fontSize*coef2);
					}

					thisCustomFont.css('font-size',fontSize + 'px');
				}

				if (typeof thisCustomFont.data('line-height') !== 'undefined' && thisCustomFont.data('line-height') !== false) {
					lineHeight = parseInt(thisCustomFont.data('line-height'));

					if (lineHeight > 70 && zen.windowWidth < 1200) {
						lineHeight = '1.2em';
					}
					else if (lineHeight > 35 && zen.windowWidth < 768) {
						lineHeight = '1.2em';
					}
					else{
						lineHeight += 'px';
					}

					thisCustomFont.css('line-height', lineHeight);
				}
			});
		}
	}

    /*
     **	Show Google Map
     */
    function zenShowGoogleMap(){

        if($('.zen-google-map').length){
            $('.zen-google-map').each(function(){

                var element = $(this);

                var customMapStyle;
                if(typeof element.data('custom-map-style') !== 'undefined') {
                    customMapStyle = element.data('custom-map-style');
                }

                var colorOverlay;
                if(typeof element.data('color-overlay') !== 'undefined' && element.data('color-overlay') !== false) {
                    colorOverlay = element.data('color-overlay');
                }

                var saturation;
                if(typeof element.data('saturation') !== 'undefined' && element.data('saturation') !== false) {
                    saturation = element.data('saturation');
                }

                var lightness;
                if(typeof element.data('lightness') !== 'undefined' && element.data('lightness') !== false) {
                    lightness = element.data('lightness');
                }

                var zoom;
                if(typeof element.data('zoom') !== 'undefined' && element.data('zoom') !== false) {
                    zoom = element.data('zoom');
                }

                var pin;
                if(typeof element.data('pin') !== 'undefined' && element.data('pin') !== false) {
                    pin = element.data('pin');
                }

                var mapHeight;
                if(typeof element.data('height') !== 'undefined' && element.data('height') !== false) {
                    mapHeight = element.data('height');
                }

                var uniqueId;
                if(typeof element.data('unique-id') !== 'undefined' && element.data('unique-id') !== false) {
                    uniqueId = element.data('unique-id');
                }

                var scrollWheel;
                if(typeof element.data('scroll-wheel') !== 'undefined') {
                    scrollWheel = element.data('scroll-wheel');
                }
                var addresses;
                if(typeof element.data('addresses') !== 'undefined' && element.data('addresses') !== false) {
                    addresses = element.data('addresses');
                }

                var map = "map_"+ uniqueId;
                var geocoder = "geocoder_"+ uniqueId;
                var holderId = "zen-map-"+ uniqueId;

                zenInitializeGoogleMap(customMapStyle, colorOverlay, saturation, lightness, scrollWheel, zoom, holderId, mapHeight, pin,  map, geocoder, addresses);
            });
        }

    }
    /*
     **	Init Google Map
     */
    function zenInitializeGoogleMap(customMapStyle, color, saturation, lightness, wheel, zoom, holderId, height, pin,  map, geocoder, data){

        var mapStyles = [
            {
                stylers: [
                    {hue: color },
                    {saturation: saturation},
                    {lightness: lightness},
                    {gamma: 1}
                ]
            }
        ];

        var googleMapStyleId;

        if(customMapStyle){
            googleMapStyleId = 'zen-style';
        } else {
            googleMapStyleId = google.maps.MapTypeId.ROADMAP;
        }

        var qoogleMapType = new google.maps.StyledMapType(mapStyles,
            {name: "Zenith Google Map"});

        geocoder = new google.maps.Geocoder();
        var latlng = new google.maps.LatLng(-34.397, 150.644);

        if (!isNaN(height)){
            height = height + 'px';
        }

        var myOptions = {

            zoom: zoom,
            scrollwheel: wheel,
            center: latlng,
            zoomControl: true,
            zoomControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL,
                position: google.maps.ControlPosition.RIGHT_CENTER
            },
            scaleControl: false,
            scaleControlOptions: {
                position: google.maps.ControlPosition.LEFT_CENTER
            },
            streetViewControl: false,
            streetViewControlOptions: {
                position: google.maps.ControlPosition.LEFT_CENTER
            },
            panControl: false,
            panControlOptions: {
                position: google.maps.ControlPosition.LEFT_CENTER
            },
            mapTypeControl: false,
            mapTypeControlOptions: {
                mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'zen-style'],
                style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
                position: google.maps.ControlPosition.LEFT_CENTER
            },
            mapTypeId: googleMapStyleId
        };

        map = new google.maps.Map(document.getElementById(holderId), myOptions);
        map.mapTypes.set('zen-style', qoogleMapType);

        var index;

        for (index = 0; index < data.length; ++index) {
            zenInitializeGoogleAddress(data[index], pin, map, geocoder);
        }

        var holderElement = document.getElementById(holderId);
        holderElement.style.height = height;
    }
    /*
     **	Init Google Map Addresses
     */
    function zenInitializeGoogleAddress(data, pin,  map, geocoder){
        if (data === '')
            return;
        var contentString = '<div id="content">'+
            '<div id="siteNotice">'+
            '</div>'+
            '<div id="bodyContent">'+
            '<p>'+data+'</p>'+
            '</div>'+
            '</div>';
        var infowindow = new google.maps.InfoWindow({
            content: contentString
        });
        geocoder.geocode( { 'address': data}, function(results, status) {
            if (status === google.maps.GeocoderStatus.OK) {
                map.setCenter(results[0].geometry.location);
                var marker = new google.maps.Marker({
                    map: map,
                    position: results[0].geometry.location,
                    icon:  pin,
                    title: data['store_title']
                });
                google.maps.event.addListener(marker, 'click', function() {
                    infowindow.open(map,marker);
                });

                google.maps.event.addDomListener(window, 'resize', function() {
                    map.setCenter(results[0].geometry.location);
                });

            }
        });
    }

    function zenInitAccordions(){
        var accordion = $('.zen-accordion-holder');
        if(accordion.length){
            accordion.each(function(){

               var thisAccordion = $(this);

				if(thisAccordion.hasClass('zen-accordion')){

					thisAccordion.accordion({
						animate: "swing",
						collapsible: true,
						active: 0,
						icons: "",
						heightStyle: "content",
						activate: function () {
							zenButton().initArrowType();
						}
					});
				}

				if(thisAccordion.hasClass('zen-toggle')){

					var toggleAccordion = $(this);
					var toggleAccordionTitle = toggleAccordion.find('.zen-title-holder');
					var toggleAccordionContent = toggleAccordionTitle.next();

					toggleAccordion.addClass("accordion ui-accordion ui-accordion-icons ui-widget ui-helper-reset");
					toggleAccordionTitle.addClass("ui-accordion-header ui-helper-reset ui-state-default ui-corner-top ui-corner-bottom");
					toggleAccordionContent.addClass("ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom").hide();

					toggleAccordionTitle.each(function(){
						var thisTitle = $(this);
						thisTitle.hover(function(){
							thisTitle.toggleClass("ui-state-hover");
						});

						thisTitle.on('click',function(){
							thisTitle.toggleClass('ui-accordion-header-active ui-state-active ui-state-default ui-corner-bottom');
							thisTitle.next().toggleClass('ui-accordion-content-active').slideToggle(400);
                            zenButton().initArrowType();
						});
					});
				}
            });
        }
    }

    function zenInitImageGallery() {

        var galleries = $('.zen-image-gallery');

        if (galleries.length) {
            galleries.each(function () {
                var gallery = $(this).children('.zen-image-gallery-slider'),
                    autoplay = gallery.data('autoplay'),
                    animation = (gallery.data('animation') == 'slide') ? false : gallery.data('animation'),
                    navigation = (gallery.data('navigation') == 'yes'),
                    pagination = (gallery.data('pagination') == 'yes');

                gallery.owlCarousel({
                    singleItem: true,
                    autoPlay: autoplay * 1000,
                    navigation: navigation,
                    transitionStyle : animation, //fade, fadeUp, backSlide, goDown
                    autoHeight: true,
                    pagination: pagination,
                    slideSpeed: 600,
                    mouseDrag: false,
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i></span>'
                    ]
                });
            });
        }

    }
    /**
     * Initializes portfolio list
     */
    function zenInitPortfolio(){
        var portList = $('.zen-portfolio-list-holder-outer.zen-ptf-standard, .zen-portfolio-list-holder-outer.zen-ptf-gallery');
        if(portList.length){            
            portList.each(function(){
                var thisPortList = $(this);
                thisPortList.appear(function(){
                    zenInitPortMixItUp(thisPortList);
                });
            });
        }
    }

    /**
     * Initializes portfolio list
     */
    function zenInitPortfolioSingleArrows() {
        if($('.zen-portfolio-single-nav').length) {

            var button = $('.zen-portfolio-prev a, .zen-portfolio-next a');

            button.addClass('zen-btn-visible');

            button.each(function() {
                var button = $(this);
                var buttonArrowTextWidth = parseInt(button.find('.zen-btn-text').width());
                var buttonArrowIconWidth = parseInt(button.find('.zen-btn-icon-arrow').width());
                var buttonWidth;

                buttonWidth = buttonArrowIconWidth + buttonArrowTextWidth + 15; //15 empty space between arrow and text
                var textPadding = buttonArrowIconWidth;

                button.css('width', buttonWidth + 'px');
                if(button.parent().hasClass('zen-portfolio-next')) {
                    button.find('.zen-btn-text').css({'padding-left': textPadding + 15 + 'px'}); //15 empty space between arrow and text
                } else {
                    button.find('.zen-btn-text').css({'padding-right': textPadding + 15 + 'px'}); //15 empty space between arrow and text
                }

                button.mouseenter(function() {
                    if(button.parent().hasClass('zen-portfolio-next')) {
                        button.find('.zen-btn-text').css({'-webkit-transform': 'translateX(' + buttonArrowTextWidth + 'px)'});
                        button.find('.zen-btn-text').css({'transform': 'translateX(' + buttonArrowTextWidth + 'px)'});
                    } else {
                        button.find('.zen-btn-text').css({'-webkit-transform': 'translateX(' + -buttonArrowTextWidth + 'px)'});
                        button.find('.zen-btn-text').css({'transform': 'translateX(' + -buttonArrowTextWidth + 'px)'});
                    }
                });
                button.mouseleave(function() {
                    button.find('.zen-btn-text').css({'-webkit-transform': 'translateX(0px)'});
                    button.find('.zen-btn-text').css({'transform': 'translateX(0px)'});
                });
            });

        }
    }
    /**
     * Initializes mixItUp function for specific container
     */
    function zenInitPortMixItUp(container){
        var filterClass = '',
            loadMore = container.find('.zen-ptf-list-paging');

        if(container.hasClass('zen-ptf-has-filter')){
            filterClass = container.find('.zen-portfolio-filter-holder-inner ul li').data('class');
            filterClass = '.'+filterClass;
        }
        
        var holderInner = container.find('.zen-portfolio-list-holder');
        holderInner.mixItUp({
            callbacks: {
                onMixLoad: function(){
                    holderInner.find('article').css('visibility','visible');
                    zenButton().initArrowType(); //because of the button that can be loaded on portfolio list
                    loadMore.animate({opacity:1},300); //add opacity to load more button
                    zen.modules.common.zenInitParallax();
                },
                onMixStart: function(){
                    holderInner.find('article').css('visibility','visible');

                },
                onMixBusy: function(){
                    holderInner.find('article').css('visibility','visible');
                } 
            },           
            selectors: {
                filter: filterClass
            },
            animation: {
                effects: 'fade translateY(80px) stagger(150ms)',
                duration: 300,
                easing: 'ease-in-out',
            }
            
        });
        
    }
     /*
    **	Init portfolio list masonry type
    */
    function zenInitPortfolioListMasonry(){
        var portList = $('.zen-portfolio-list-holder-outer.zen-ptf-masonry');
        if(portList.length) {
            portList.each(function() {
                var thisPortList = $(this).children('.zen-portfolio-list-holder');
                var size = thisPortList.find('.zen-portfolio-list-masonry-grid-sizer').width();
                zenResizeMasonry(size,thisPortList);
                
                zenInitMasonry(thisPortList);
                $(window).resize(function(){
                    zenResizeMasonry(size,thisPortList);
                    zenInitMasonry(thisPortList);
                });
            });
        }
    }
    
    function zenInitMasonry(container){
        container.animate({opacity: 1});
        container.isotope({
            itemSelector: '.zen-portfolio-item',
            masonry: {
                columnWidth: '.zen-portfolio-list-masonry-grid-sizer'
            }
        });
    }
    
    function zenResizeMasonry(size,container){
        
        var defaultMasonryItem = container.find('.zen-default-masonry-item');
        var largeWidthMasonryItem = container.find('.zen-large-width-masonry-item');
        var largeHeightMasonryItem = container.find('.zen-large-height-masonry-item');
        var largeWidthHeightMasonryItem = container.find('.zen-large-width-height-masonry-item');

        defaultMasonryItem.css('height', size);
        largeHeightMasonryItem.css('height', Math.round(2*size));

        if(zen.windowWidth > 600){
            largeWidthHeightMasonryItem.css('height', Math.round(2*size));
            largeWidthMasonryItem.css('height', size);
        }else{
            largeWidthHeightMasonryItem.css('height', size);
            largeWidthMasonryItem.css('height', Math.round(size/2));

        }
    }
    /**
     * Initializes portfolio pinterest 
     */
    function zenInitPortfolioListPinterest(){
        
        var portList = $('.zen-portfolio-list-holder-outer.zen-ptf-pinterest');
        if(portList.length) {
            portList.each(function() {
                var thisPortList = $(this).children('.zen-portfolio-list-holder');
                zenInitPinterest(thisPortList);
                $(window).resize(function(){
                     zenInitPinterest(thisPortList);
                });
            });
            
        }
    }
    
    function zenInitPinterest(container){
        container.animate({opacity: 1});
        container.isotope({
            itemSelector: '.zen-portfolio-item',
            masonry: {
                columnWidth: '.zen-portfolio-list-masonry-grid-sizer'
            }
        });
        
    }
    /**
     * Initializes portfolio masonry filter
     */
    function zenInitPortfolioMasonryFilter(){
        
        var filterHolder = $('.zen-portfolio-filter-holder.zen-masonry-filter');
        
        if(filterHolder.length){
            filterHolder.each(function(){
               
                var thisFilterHolder = $(this);
                
                var portfolioIsotopeAnimation = null;
                
                var filter = thisFilterHolder.find('ul li').data('class');
                
                thisFilterHolder.find('.filter:first').addClass('current');
                
                thisFilterHolder.find('.filter').click(function(){

                    var currentFilter = $(this);
                    clearTimeout(portfolioIsotopeAnimation);

                    $('.isotope, .isotope .isotope-item').css('transition-duration','0.8s');

                    portfolioIsotopeAnimation = setTimeout(function(){
                        $('.isotope, .isotope .isotope-item').css('transition-duration','0s'); 
                    },700);

                    var selector = $(this).attr('data-filter');
                    thisFilterHolder.siblings('.zen-portfolio-list-holder-outer').find('.zen-portfolio-list-holder').isotope({ filter: selector });

                    thisFilterHolder.find('.filter').removeClass('current');
                    currentFilter.addClass('current');

                    return false;

                });
                
            });
        }
    }
    /**
     * Initializes portfolio load more function
     */
    function zenInitPortfolioLoadMore(){
        var portList = $('.zen-portfolio-list-holder-outer.zen-ptf-load-more');
        if(portList.length){
            portList.each(function(){
                
                var thisPortList = $(this);
                var thisPortListInner = thisPortList.find('.zen-portfolio-list-holder');
                var nextPage; 
                var maxNumPages;
                var loadMoreButton = thisPortList.find('.zen-ptf-list-load-more a');
                
                if (typeof thisPortList.data('max-num-pages') !== 'undefined' && thisPortList.data('max-num-pages') !== false) {  
                    maxNumPages = thisPortList.data('max-num-pages');
                }
                
                loadMoreButton.on('click', function (e) {  
                    var loadMoreDatta = zenGetPortfolioAjaxData(thisPortList);
                    nextPage = loadMoreDatta.nextPage;
                    e.preventDefault();
                    e.stopPropagation(); 
                    if(nextPage <= maxNumPages){
                        var ajaxData = zenSetPortfolioAjaxData(loadMoreDatta);
                        $.ajax({
                            type: 'POST',
                            data: ajaxData,
                            url: zenCoreAjaxUrl,
                            success: function (data) {
                                nextPage++;
                                thisPortList.data('next-page', nextPage);
                                var response = $.parseJSON(data);
                                var responseHtml = zenConvertHTML(response.html); //convert response html into jQuery collection that Mixitup can work with
                                thisPortList.waitForImages(function(){    
                                    setTimeout(function() {
                                        if(thisPortList.hasClass('zen-ptf-masonry') || thisPortList.hasClass('zen-ptf-pinterest') ){
                                            thisPortListInner.isotope().append( responseHtml ).isotope( 'appended', responseHtml ).isotope('reloadItems');
                                            zenButton().initArrowType(); //because of the button that can be loaded on portfolio list
                                        } else {
                                            thisPortListInner.mixItUp('append',responseHtml, function() {
                                                zenButton().initArrowType(); //because of the button that can be loaded on portfolio list
                                                }
                                            );
                                        }
                                        zenButton().initArrowType();
                                    },400);                                    
                                });                           
                            }
                        });
                    }
                    if(nextPage === maxNumPages){
                        loadMoreButton.closest('.zen-ptf-list-load-more').fadeOut();
                    }
                });
                
            });
        }
    }
    
    function zenConvertHTML ( html ) {
        var newHtml = $.trim( html ),
                $html = $(newHtml ),
                $empty = $();

        $html.each(function ( index, value ) {
            if ( value.nodeType === 1) {
                $empty = $empty.add ( this );
            }
        });

        return $empty;
    }

    /**
     * Initializes portfolio load more data params
     * @param portfolio list container with defined data params
     * return array
     */
    function zenGetPortfolioAjaxData(container){
        var returnValue = {};
        
        returnValue.type = '';
        returnValue.columns = '';
        returnValue.gridSize = '';
        returnValue.orderBy = '';
        returnValue.order = '';
        returnValue.number = '';
        returnValue.imageSize = '';
        returnValue.filter = '';
        returnValue.filterOrderBy = '';
        returnValue.category = '';
        returnValue.selectedProjectes = '';
        returnValue.showLoadMore = '';
        returnValue.titleTag = '';
        returnValue.nextPage = '';
        returnValue.maxNumPages = '';
        
        if (typeof container.data('type') !== 'undefined' && container.data('type') !== false) {
            returnValue.type = container.data('type');
        }
        if (typeof container.data('grid-size') !== 'undefined' && container.data('grid-size') !== false) {                    
            returnValue.gridSize = container.data('grid-size');
        }
        if (typeof container.data('columns') !== 'undefined' && container.data('columns') !== false) {                    
            returnValue.columns = container.data('columns');
        }
        if (typeof container.data('order-by') !== 'undefined' && container.data('order-by') !== false) {                    
            returnValue.orderBy = container.data('order-by');
        }
        if (typeof container.data('order') !== 'undefined' && container.data('order') !== false) {                    
            returnValue.order = container.data('order');
        }
        if (typeof container.data('number') !== 'undefined' && container.data('number') !== false) {                    
            returnValue.number = container.data('number');
        }
        if (typeof container.data('image-size') !== 'undefined' && container.data('image-size') !== false) {                    
            returnValue.imageSize = container.data('image-size');
        }
        if (typeof container.data('filter') !== 'undefined' && container.data('filter') !== false) {                    
            returnValue.filter = container.data('filter');
        }
        if (typeof container.data('filter-order-by') !== 'undefined' && container.data('filter-order-by') !== false) {                    
            returnValue.filterOrderBy = container.data('filter-order-by');
        }
        if (typeof container.data('category') !== 'undefined' && container.data('category') !== false) {                    
            returnValue.category = container.data('category');
        }
        if (typeof container.data('selected-projects') !== 'undefined' && container.data('selected-projects') !== false) {                    
            returnValue.selectedProjectes = container.data('selected-projects');
        }
        if (typeof container.data('show-load-more') !== 'undefined' && container.data('show-load-more') !== false) {                    
            returnValue.showLoadMore = container.data('show-load-more');
        }
        if (typeof container.data('title-tag') !== 'undefined' && container.data('title-tag') !== false) {                    
            returnValue.titleTag = container.data('title-tag');
        }
        if (typeof container.data('next-page') !== 'undefined' && container.data('next-page') !== false) {                    
            returnValue.nextPage = container.data('next-page');
        }
        if (typeof container.data('max-num-pages') !== 'undefined' && container.data('max-num-pages') !== false) {                    
            returnValue.maxNumPages = container.data('max-num-pages');
        }
        return returnValue;
    }
     /**
     * Sets portfolio load more data params for ajax function
     * @param portfolio list container with defined data params
     * return array
     */
    function zenSetPortfolioAjaxData(container){
        var returnValue = {
            action: 'zen_core_portfolio_ajax_load_more',
            type: container.type,
            columns: container.columns,
            gridSize: container.gridSize,
            orderBy: container.orderBy,
            order: container.order,
            number: container.number,
            imageSize: container.imageSize,
            filter: container.filter,
            filterOrderBy: container.filterOrderBy,
            category: container.category,
            selectedProjectes: container.selectedProjectes,
            showLoadMore: container.showLoadMore,
            titleTag: container.titleTag,
            nextPage: container.nextPage
        };
        return returnValue;
    }

    /*
    * Process Slider init
    */

    function zenProcessSlider() {
        var processSlider = $('.zen-process-slider');

        if (processSlider.length) {
            processSlider.each(function(){
                //vars
                var thisProcessSlider = $(this),
                    processSliderTitleArea = $(this).find('.zen-process-slider-title-area'),
                    processSliderItems = $(this).find('.zen-process-slider-content-area'),
                    processSliderItem = processSliderItems.find('.zen-process-slider-item'),
                    processSliderNext = processSliderTitleArea.find('.zen-process-slider-next-nav'),
                    processSliderHandler = thisProcessSlider.parent().parent().find('.zen-process-handle'),
                    cycleTimeout= null,
                    processSliderContentWidth = processSliderItem.length*processSliderItem.outerWidth(),
                    processSliderContentHeight = processSliderItem.outerHeight(),
                    processSliderWidth = processSliderContentWidth + processSliderTitleArea.outerWidth(),
                    leftOffset = (Math.max(zen.windowWidth - zen.gridWidth , 0) / 2);

                    //appears
                    setTimeout(function(){
                        processSliderItem.each(function(i){
                            $(this).animate({opacity:1},400, 'easeOutSine');
                            processSliderHandler.parent().animate({opacity:1},400, 'easeOutSine');
                            $(this).find('.zen-process-slide-item-number').append(i+1);
                        });
                    },200);

                        //calcs
                        thisProcessSlider.css({width:processSliderContentWidth+processSliderTitleArea.outerWidth()+'px'});
                        thisProcessSlider.css({height:processSliderContentHeight+'px'});
                        thisProcessSlider.css({'-webkit-transform':'translateX('+leftOffset+'px)'});
                        thisProcessSlider.css({'transform':'translateX('+leftOffset+'px)'});
                        thisProcessSlider.delay(200).animate({opacity:1},200);

                        //recalcs
                        $(window).resize(function(){
                            leftOffset = (Math.max($(window).width() - zen.gridWidth , 0) / 2);
                            processSliderContentWidth = processSliderItem.length*processSliderItem.outerWidth();
                            processSliderContentHeight = processSliderItem.outerHeight();
                            processSliderWidth = processSliderContentWidth + processSliderTitleArea.outerWidth();
                            thisProcessSlider.css({width:processSliderContentWidth+processSliderTitleArea.outerWidth()+'px'});
                            thisProcessSlider.css({height:processSliderContentHeight+'px'});
                            thisProcessSlider.css({'-webkit-transform':'translateX('+leftOffset+'px)'});
                            thisProcessSlider.css({'transform':'translateX('+leftOffset+'px)'});
                            processSliderItem.each(function(i){
                                $(this).delay(200*i).animate({opacity:1},400, 'easeOutSine');
                                processSliderHandler.parent().animate({opacity:1},400, 'easeOutSine');
                            });
                        });

                        // clicks
                        processSliderNext.click(function(event){
                            event.preventDefault();
                            clearTimeout(cycleTimeout);
                            cycleTimeout = setTimeout(function(){
                                if(processSliderItems.hasClass('zen-moved')) {
                                    setTimeout(function(){
                                        thisProcessSlider.css({'-webkit-transform':'translateX('+leftOffset+'px)'});
                                        thisProcessSlider.css({'transform':'translateX('+leftOffset+'px)'});
                                        processSliderHandler.css({marginLeft:0});
                                        processSliderItems.removeClass('zen-moved');
                                    },500);
                                } else {
                                    setTimeout(function(){
                                        if (zen.gridWidth < $(window).width()) {
                                            thisProcessSlider.css({'-webkit-transform':'translateX(0)'});
                                            thisProcessSlider.css({'transform':'translateX(0)'});
                                        } else {
                                            thisProcessSlider.css({'-webkit-transform':'translateX(-'+processSliderTitleArea.outerWidth()+'px)'});
                                            thisProcessSlider.css({'transform':'translateX(-'+processSliderTitleArea.outerWidth()+'px)'});
                                        }
                                        processSliderHandler.css({marginLeft:111}); //match the dragged margin offset
                                        processSliderItems.addClass('zen-moved');
                                    },500);
                                }
                            }, 50);
                        });
            });
        }
    }

    /*
    * Scroll logic for process Slider
    */
    function zenProcessScroll() {

            var scroller;
            var gridCalcs;

            function calculategridCalcs () {
                gridCalcs = (Math.max($('.zen-process-slider').width() - zen.gridWidth, 0) / 2);
                return gridCalcs;
            }

            function Scroller (opts) {
                var handle = opts.handle;
                var track = opts.track;
                var scroller = opts.scroller;
                var content = opts.content;
                var dragEndedCallback = opts.dragEndedCallback || function () {};
                var dragStartedCallback = opts.dragStartedCallback || function () {};   

                var contentMaxScroll = (content.width() + gridCalcs*0.3) - scroller.width(); //0.3 - coeff that results in the appropriate scroll amount
                var maxTravel = track.width() - handle.width();
                var window_mouseMove = null;
                var dragInProgress = false;


                handle.click(function (e) {e.preventDefault(); e.stopPropagation();});

                function mouseFollower (cb) {
                    return function (e) {
                        cb(e.clientX || e.originalEvent.targetTouches[0].clientX || 0,
                             e.clientY || e.originalEvent.targetTouches[0].clientY || 0);
                    };
                }

                function scrollContentToRatio (ratio, animated, callback) {
                    var newScroll = ratio * contentMaxScroll;
                    if (!animated) {
                        scroller.scrollLeft(newScroll);
                        return;
                    } else {
                        scroller.animate({scrollLeft: newScroll}, 400, 'swing', callback);
                    }
                }

                function moveHandleToRatio (ratio, animated, callback) {
                    var props = {marginLeft: ratio * maxTravel};
                    if (!animated) {
                        handle.css(props);
                        return;
                    } else {
                        handle.animate(props, 400, 'swing', callback);
                    }
                }

                function scrollToRatio (ratio, opts) {
                    opts = $.extend({
                        animate: false,
                        scrollbarCallback: function () {},
                        contentCallback: function () {}
                        }, opts);
                    ratio = Math.max(Math.min(ratio, 1.0), 0.0);
                    moveHandleToRatio(ratio, opts.animate, opts.scrollbarCallback);
                    scrollContentToRatio(ratio, opts.animate, opts.contentCallback);
                }

                function scrollByDelta (delta, opts) {
                    return scrollToRatio((scroller.scrollLeft() - delta) / contentMaxScroll, opts);
                }

                function getScrollbarRatio () {
                    return handle.offset().left / maxTravel;
                }

                function getContentRatio () {
                    return scroller.scrollLeft() / contentMaxScroll;
                }

                var endDrag;
                function beginDrag (e) {
                    endDrag();
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    e.stopPropagation();
                    dragInProgress = true;

                    var pageX = e.pageX || e.originalEvent.targetTouches[0].clientX;

                    var xOnHandle = pageX - handle.offset().left + track.offset().left;
                    function scrollHandleCallback (x, y) {
                        var position = x - xOnHandle;

                        if (position < 0) {
                            position = 0;
                        } else if (position > maxTravel) {
                            position = maxTravel;
                        }

                        var scrollRatio = position / maxTravel;
                        scrollToRatio(scrollRatio);
                    }
                    window_mouseMove = mouseFollower(scrollHandleCallback);
                    $('body').bind('mousemove', window_mouseMove);
                    dragStartedCallback();
                    handle.addClass('start');
                    return false;
                }
                
                endDrag = function (e) {
                    dragInProgress = false;
                    $('body').unbind('mousemove', window_mouseMove);
                    dragEndedCallback();
                    handle.removeClass('start');
                    return false;
                };

                handle.get(0).onselectstart = function () {return false;};
                // handle.mousedown(beginDrag);
                handle.bind('mousedown', beginDrag);
                $('html,body').bind('mouseup', endDrag);

                //$(window).bind('mouseleave', endDrag);

                return {
                    scrollToRatio: scrollToRatio,
                    scrollByDelta: scrollByDelta,
                    getContentRatio: getContentRatio,
                    getScrollbarRatio: getScrollbarRatio,
                    moveToSelector: function (selector, opts) {
                        if (!selector) return false;
                        var dest = $(selector, content);
                        var destOffset = (dest.offset().left + scroller.scrollLeft()) - (gridCalcs + 10);
                        var destRatio =  destOffset / contentMaxScroll;
                        scrollToRatio(destRatio, opts);
                    },
                    swipeToSide: function (amount, opts) {
                        var position = parseInt(handle.css('marginLeft')) + amount;

                        if (position < 0) {
                            position = 0;
                        } else if (position > maxTravel) {
                            position = maxTravel;
                        }

                        var scrollRatio = position / maxTravel;
                        scrollToRatio(scrollRatio, opts);
                    },
                    dragInProgress: function () {
                        return dragInProgress;
                    },
                    destroy: function () {
                        handle.unbind('mousedown', beginDrag);
                        $(window).unbind('mouseup', endDrag).unbind('mousemove', window_mouseMove);
                    }
                };
            }

            /*
            * Process Slider Scroll init
            */
            function processSliderScroll () {
                if ($(window).width() >= 768) { 
                    $('.zen-process-slider').each(function (idx, el) {
                        calculategridCalcs();
                        $('.zen-process-track').css({width:(Math.min($(window).width(), zen.gridWidth))});
                        //recalcs
                        $(window).resize(function(){
                            $('.zen-process-track').css({width:(Math.min($(window).width(), zen.gridWidth))});
                        });
                        scroller = Scroller({
                            track: $('.zen-process-track'),
                            handle: $('.zen-process-handle'),
                            scroller: $('.zen-process-outer'),
                            content: $('.zen-process-slider')
                        });


                        $('.zen-process-slider').swipe( {
                            swipeLeft: function(){
                                scroller.swipeToSide(300, {animate: true});
                            },
                            swipeRight: function(){
                                scroller.swipeToSide(-300, {animate: true});
                            },
                            threshold:20
                        });
                    });
                }

            }

            processSliderScroll();

    }
})(jQuery);
(function($) {
    'use strict';

    var woocommerce = {};
    zen.modules.woocommerce = woocommerce;

    woocommerce.zenInitQuantityButtons = zenInitQuantityButtons;
    woocommerce.zenInitSelect2 = zenInitSelect2;
    woocommerce.zenInitSingleProductLightbox = zenInitSingleProductLightbox;

    woocommerce.zenOnDocumentReady = zenOnDocumentReady;
    woocommerce.zenOnWindowLoad = zenOnWindowLoad;
    woocommerce.zenOnWindowResize = zenOnWindowResize;
    woocommerce.zenOnWindowScroll = zenOnWindowScroll;

    $(document).ready(zenOnDocumentReady);
    $(window).load(zenOnWindowLoad);
    $(window).resize(zenOnWindowResize);
    $(window).scroll(zenOnWindowScroll);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function zenOnDocumentReady() {
        zenInitQuantityButtons();
        zenInitSelect2();
        zenInitSingleProductLightbox();
        zenWooSlider();
    }

    /* 
        All functions to be called on $(window).load() should be in this function
    */
    function zenOnWindowLoad() {

    }

    /* 
        All functions to be called on $(window).resize() should be in this function
    */
    function zenOnWindowResize() {
    	zenWooSlider();
    }

    /* 
        All functions to be called on $(window).scroll() should be in this function
    */
    function zenOnWindowScroll() {

    }
    

    function zenInitQuantityButtons() {

        $(document).on( 'click', '.zen-quantity-minus, .zen-quantity-plus', function(e) {
            e.stopPropagation();

            var button = $(this),
                inputField = button.siblings('.zen-quantity-input'),
                step = parseFloat(inputField.attr('step')),
                max = parseFloat(inputField.attr('max')),
                minus = false,
                inputValue = parseFloat(inputField.val()),
                newInputValue;

            if (button.hasClass('zen-quantity-minus')) {
                minus = true;
            }

            if (minus) {
                newInputValue = inputValue - step;
                if (newInputValue >= 1) {
                    inputField.val(newInputValue);
                } else {
                    inputField.val(1);
                }
            } else {
                newInputValue = inputValue + step;
                if ( max === undefined ) {
                    inputField.val(newInputValue);
                } else {
                    if ( newInputValue >= max ) {
                        inputField.val(max);
                    } else {
                        inputField.val(newInputValue);
                    }
                }
            }
            inputField.trigger( 'change' );
        });

    }

    function zenInitSelect2() {

        if ($('.woocommerce-ordering .orderby').length ||  $('#calc_shipping_country').length ) {

            $('.woocommerce-ordering .orderby').select2({
                minimumResultsForSearch: Infinity
            });

            $('#calc_shipping_country').select2();

        }

    }

    /**
     * Init Woo Slider
     */
    function zenWooSlider() {

        var carousels = $('.zen-woo-single-slider'),
            carousel,
            imagesHolder,
            imagesHolderOuterWidth;

        if (carousels.length) {
            carousels.each(function(){
                carousel = $(this);
                imagesHolderOuterWidth = parseInt(carousel.parents('.zen-single-product-images').width());
                imagesHolder = carousel.parent();
                imagesHolder.css('width',imagesHolderOuterWidth + 'px');

                carousel.owlCarousel({
                    navigation : true, // Show next and prev buttons
                    slideSpeed : 300,
                    paginationSpeed : 400,
                    singleItem:true,
                    pagination  : false,
                    navigationText: [
                        '<span class="zen-prev-icon"><i class="icon-arrows-slim-left"></i></span>',
                        '<span class="zen-next-icon"><i class="icon-arrows-slim-right"></i></span>'
                    ]
                });

            });
        }

    }
    /*
     ** Init Product Single Pretty Photo attributes
     */
    function zenInitSingleProductLightbox() {
        var item = $('.zen-woocommerce-single-page.zen-woo-single-has-pretty-photo .images .woocommerce-product-gallery__image');

        if(item.length) {
            item.children('a').attr('data-rel', 'prettyPhoto[product-gallery]');

            if (typeof zen.modules.common.zenPrettyPhoto === "function") {
                zen.modules.common.zenPrettyPhoto();
            }
        }
    }

})(jQuery);
(function($) {
    'use strict';

    zen.modules.portfolio = {};

    $(window).load(function() {
        zenPortfolioSingleFollow().init();
    });

    var zenPortfolioSingleFollow = function() {

        var info = $('.zen-follow-portfolio-info .small-images.zen-portfolio-single-holder .zen-portfolio-info-holder, ' +
            '.zen-follow-portfolio-info .small-slider.zen-portfolio-single-holder .zen-portfolio-info-holder');

        if (info.length) {
            var infoHolder = info.parent(),
                infoHolderOffset = infoHolder.offset().top,
                infoHolderHeight = infoHolder.height(),
                mediaHolder = $('.zen-portfolio-media'),
                mediaHolderHeight = mediaHolder.height(),
                header = $('.header-appear, .zen-fixed-wrapper'),
                headerHeight = (header.length) ? header.height() : 0;
        }

        var infoHolderPosition = function() {

            if(info.length) {

                if (mediaHolderHeight > infoHolderHeight) {
                    if(zen.scroll > infoHolderOffset) {
                        info.animate({
                            marginTop: (zen.scroll - (infoHolderOffset) + zenGlobalVars.vars.zenAddForAdminBar + headerHeight + 20) //20 px is for styling, spacing between header and info holder
                        });
                    }
                }

            }
        };

        var recalculateInfoHolderPosition = function() {

            if (info.length) {
                if(mediaHolderHeight > infoHolderHeight) {
                    if(zen.scroll > infoHolderOffset) {

                        if(zen.scroll + headerHeight + zenGlobalVars.vars.zenAddForAdminBar + infoHolderHeight + 20 < infoHolderOffset + mediaHolderHeight) {    //20 px is for styling, spacing between header and info holder

                            //Calculate header height if header appears
                            if ($('.header-appear, .zen-fixed-wrapper').length) {
                                headerHeight = $('.header-appear, .zen-fixed-wrapper').height();
                            }
                            info.stop().animate({
                                marginTop: (zen.scroll - (infoHolderOffset) + zenGlobalVars.vars.zenAddForAdminBar + headerHeight + 20) //20 px is for styling, spacing between header and info holder
                            });
                            //Reset header height
                            headerHeight = 0;
                        }
                        else{
                            info.stop().animate({
                                marginTop: mediaHolderHeight - infoHolderHeight
                            });
                        }
                    } else {
                        info.stop().animate({
                            marginTop: 0
                        });
                    }
                }
            }
        };

        return {

            init : function() {

                infoHolderPosition();
                $(window).scroll(function(){
                    recalculateInfoHolderPosition();
                });

            }

        };

    };

})(jQuery);