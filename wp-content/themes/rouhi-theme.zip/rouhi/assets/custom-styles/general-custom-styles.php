<?php
if(!function_exists('rouhi_zenith_design_styles')) {
    /**
     * Generates general custom styles
     */
    function rouhi_zenith_design_styles() {

        $preload_background_styles = array();

        if(rouhi_zenith_options()->getOptionValue('preload_pattern_image') !== ""){
            $preload_background_styles['background-image'] = 'url('.rouhi_zenith_options()->getOptionValue('preload_pattern_image').') !important';
        }else{
            $preload_background_styles['background-image'] = 'url('.esc_url(zenith_assets_root."/img/preload_pattern.png").') !important';
        }

        echo rouhi_zenith_dynamic_css('.zen-preload-background', $preload_background_styles);

		if (rouhi_zenith_options()->getOptionValue('google_fonts')){
			$font_family = rouhi_zenith_options()->getOptionValue('google_fonts');
			if(rouhi_zenith_is_font_option_valid($font_family)) {
				echo rouhi_zenith_dynamic_css('body', array('font-family' => rouhi_zenith_get_font_option_val($font_family)));
			}
		}

        if(rouhi_zenith_options()->getOptionValue('first_color') !== "") {
            $color_selector = array(
                'h1 a:hover',
                'h2 a:hover',
                'h3 a:hover',
                'h4 a:hover',
                'h5 a:hover',
                'h6 a:hover',
                'h5',
                'a',
                'p a',
                '.zen-author-description .zen-author',
                '.zen-single-tags-holder .zen-tags a:hover',
                '.zen-single-links-pages .zen-single-links-pages-inner > a:hover',
                '.zen-single-links-pages .zen-single-links-pages-inner > span',
                '.zen-comment-holder .zen-comment-text .replay:hover',
                '.zen-comment-holder .zen-comment-text .comment-reply-link:hover',
                '.zen-comment-holder .zen-comment-text .comment-edit-link:hover',
                '.zen-comment-holder .zen-comment-text .zen-comment-arrow:hover',
                '#submit_comment:hover',
                '.post-password-form input[type="submit"]:hover',
                'input.wpcf7-form-control.wpcf7-submit:hover',
                '.zen-pagination li a:hover',
                '.zen-pagination li.active span',
                '.zen-print-page:hover',
                '.zen-drop-down .wide .second .inner > ul > li > a:hover',
                '.zen-drop-down .wide .second .inner ul li.sub .flexslider ul li a:hover',
                '.zen-drop-down .wide .second ul li .flexslider ul li a:hover',
                '.zen-drop-down .wide .second .inner ul li.sub .flexslider.widget_flexslider .menu_recent_post_text a:hover',
                '.zen-mobile-header .zen-mobile-nav a:hover, .zen-mobile-header .zen-mobile-nav h4:hover',
                'footer .zen-footer-bottom-holder .widget.widget_nav_menu li a:hover',
                '.zen-title .zen-title-holder .zen-breadcrumbs span.zen-current',
                '.zen-portfolio-single-holder .zen-toolbar-holder .zen-like:not(.liked):hover',
                '.zen-portfolio-single-holder .zen-portfolio-info-holder .zen-portfolio-info-item.zen-portfolio-categories p',
                '.zen-portfolio-single-holder .zen-portfolio-single-nav .zen-portfolio-back-btn:hover span',
                '.zen-counter-holder .zen-counter',
                '.zen-ordered-list ol > li:before',
                '.zen-icon-list-item .zen-icon-list-icon-holder-inner i',
                '.zen-icon-list-item .zen-icon-list-icon-holder-inner .font_elegant',
                '.zen-price-table .zen-table-btm .zen-table-icon',
                '.zen-price-table .zen-price-table-inner .zen-table-prices .zen-value',
                '.zen-tabs .zen-tabs-nav li.ui-state-active a',
                '.zen-tabs .zen-tabs-nav li.ui-state-hover a',
                '.zen-accordion-holder .zen-title-holder.ui-state-active',
                '.zen-accordion-holder .zen-title-holder.ui-state-hover',
                '.zen-blog-list-holder .zen-item-info-section',
                '.zen-blog-list-holder .zen-item-info-section > div a',
                '.zen-blog-list-holder .zen-item-info-section > div:before',
                '.zen-blog-list-holder .zen-item-info-section span',
                '.zen-blog-slider-item .zen-item-info-section',
                '.zen-blog-slider-item .zen-item-info-section > div a',
                '.zen-blog-slider-item .zen-item-info-section > div:before',
                '.zen-blog-slider-item .zen-item-info-section span',
                '.zen-btn.zen-btn-outline',
                '.zen-dropcaps',
                '.zen-portfolio-filter-holder .zen-portfolio-filter-holder-inner ul li.active span',
                '.zen-portfolio-filter-holder .zen-portfolio-filter-holder-inner ul li.current span',
                '.zen-portfolio-list-holder article .zen-item-icons-holder a',
                '.zen-portfolio-list-holder-outer.zen-ptf-standard article .zen-item-icons-holder a:hover',
                '.zen-portfolio-list-holder-outer.zen-ptf-standard article .zen-item-text-holder .zen-ptf-category-holder span',
                '.zen-portfolio-list-holder-outer.zen-ptf-gallery article .zen-item-text-holder .zen-item-title > a',
                '.zen-portfolio-list-holder-outer.zen-ptf-gallery article .zen-item-text-holder .zen-ptf-category-holder span',
                '.zen-portfolio-list-holder-outer.zen-ptf-pinterest article .zen-item-text-holder .zen-item-title > a',
                '.zen-portfolio-list-holder-outer.zen-ptf-pinterest article .zen-item-text-holder .zen-ptf-category-holder span',
                '.zen-portfolio-list-holder-outer.zen-ptf-masonry article .zen-item-text-holder .zen-item-title > a',
                '.zen-portfolio-list-holder-outer.zen-ptf-masonry article .zen-item-text-holder .zen-ptf-category-holder span',
                '.zen-social-share-holder.zen-dropdown .zen-social-share-dropdown-opener:hover',
                '.zen-process-outer .zen-process-slider .zen-process-slider-content-area .zen-process-slider-item .zen-process-slide-item-title-holder .zen-process-subtitle',
                '.widget.widget_rss ul li:hover > a',
                '.widget.widget_rss ul li:hover:before',
                '.widget.widget_text ul li:hover > a',
                '.widget.widget_text ul li:hover:before',
                '.widget.widget_pages ul li:hover > a',
                '.widget.widget_pages ul li:hover:before',
                '.widget.widget_meta ul li:hover > a',
                '.widget.widget_meta ul li:hover:before',
                '.widget.widget_archive ul li:hover > a',
                '.widget.widget_archive ul li:hover:before',
                '.widget.widget_nav_menu ul li:hover > a',
                '.widget.widget_nav_menu ul li:hover:before',
                '.widget.widget_recent_entries ul li:hover > a',
                '.widget.widget_recent_entries ul li:hover:before',
                '.widget.widget_recent_comments ul li:hover > a',
                '.widget.widget_recent_comments ul li:hover:before',
                '.widget.widget_product_categories ul li:hover > a',
                '.widget.widget_product_categories ul li:hover:before',
                '.widget.widget_categories ul li:hover > a',
                '.widget.widget_categories ul li:hover:before',
                '.widget.widget_tag_cloud a:hover',
                '.widget #lang_sel *:hover > a',
                '.widget #lang_sel_list *:hover > a',
                '.widget #lang_sel ul ul *:hover > a',
                '.widget #lang_sel_list ul ul *:hover > a',
                '.widget #lang_sel a:hover',
                '.widget #lang_sel_list a:hover',
                '.woocommerce-account .woocommerce-MyAccount-navigation ul li.is-active a',
                '.woocommerce-account .woocommerce-MyAccount-navigation ul li a:hover'
            );

            $color_important_selector = array(
            	'.zen-btn.zen-btn-solid:not(.zen-btn-custom-hover-color):hover'
            );

            $background_color_selector = array(
            	'.zen-blog-holder article .zen-post-mark',
            	'.zen-st-loader .pulse',
            	'.zen-st-loader .double_pulse .double-bounce1',
            	'.zen-st-loader .double_pulse .double-bounce2',
            	'.zen-st-loader .cube',
            	'.zen-st-loader .rotating_cubes .cube1',
            	'.zen-st-loader .rotating_cubes .cube2',
            	'.zen-st-loader .stripes > div',
            	'.zen-st-loader .wave > div',
            	'.zen-st-loader .two_rotating_circles .dot1',
            	'.zen-st-loader .two_rotating_circles .dot2',
            	'.zen-st-loader .five_rotating_circles .container1 > div',
            	'.zen-st-loader .five_rotating_circles .container2 > div',
            	'.zen-st-loader .five_rotating_circles .container3 > div',
            	'.zen-st-loader .atom .ball-1:before',
            	'.zen-st-loader .atom .ball-2:before',
            	'.zen-st-loader .atom .ball-3:before',
            	'.zen-st-loader .atom .ball-4:before',
            	'.zen-st-loader .clock .ball:before',
            	'.zen-st-loader .mitosis .ball',
            	'.zen-st-loader .lines .line1',
            	'.zen-st-loader .lines .line2',
            	'.zen-st-loader .lines .line3',
            	'.zen-st-loader .lines .line4',
            	'.zen-st-loader .fussion .ball',
            	'.zen-st-loader .fussion .ball-1',
            	'.zen-st-loader .fussion .ball-2',
            	'.zen-st-loader .fussion .ball-3',
            	'.zen-st-loader .fussion .ball-4',
            	'.zen-st-loader .wave_circles .ball',
            	'.zen-st-loader .pulse_circles .ball',
            	'.zen-main-menu > ul > li > a:hover span.bottom_line',
            	'.zen-drop-down .narrow .second .inner ul li.tracker',
                'nav.zen-fullscreen-menu ul li a:hover span.bottom_line',
                '.zen-icon-shortcode.circle',
                '.zen-icon-shortcode.square',
                '.zen-progress-bar .zen-progress-content-outer .zen-progress-content',
                '.zen-blog-list-holder.zen-boxes .zen-post-mark',
                '.zen-btn.zen-btn-solid',
                '.zen-dropcaps.zen-square',
                '.zen-dropcaps.zen-circle',
                '.zen-portfolio-list-holder-outer.zen-ptf-standard article .zen-item-icons-holder',
                '.zen-process-outer .zen-process-slider .zen-process-slider-title-area .zen-process-slider-next-nav span'
            );

            $background_color_important_selector = array(
            	'.zen-btn.zen-btn-outline:not(.zen-btn-custom-hover-bg):hover'
            );

            $border_color_selector = array(
            	'.zen-st-loader .pulse_circles .ball',
            	'.wpcf7-form-control.wpcf7-text:focus',
            	'.wpcf7-form-control.wpcf7-number:focus',
            	'.wpcf7-form-control.wpcf7-date:focus',
            	'.wpcf7-form-control.wpcf7-textarea:focus',
            	'.wpcf7-form-control.wpcf7-select:focus',
            	'.wpcf7-form-control.wpcf7-quiz:focus',
            	'#respond textarea:focus',
            	'#respond input[type="text"]:focus',
            	'.post-password-form input[type="password"]:focus',
            	'.zen-drop-down .second',
            	'.widget_search input[type="text"]:focus',
            	'.zen-btn.zen-btn-solid',
            	'.zen-btn.zen-btn-outline',
            	'.zen-portfolio-list-holder article .zen-item-icons-holder a',
            	'.widget.widget_rss select:focus',
            	'.widget.widget_rss select option:focus',
            	'.widget.widget_text select:focus',
            	'.widget.widget_text select option:focus',
            	'.widget.widget_pages select:focus',
            	'.widget.widget_pages select option:focus',
            	'.widget.widget_meta select:focus',
            	'.widget.widget_meta select option:focus',
            	'.widget.widget_archive select:focus',
            	'.widget.widget_archive select option:focus',
            	'.widget.widget_nav_menu select:focus',
            	'.widget.widget_nav_menu select option:focus',
            	'.widget.widget_recent_entries select:focus',
            	'.widget.widget_recent_entries select option:focus',
            	'.widget.widget_recent_comments select:focus',
            	'.widget.widget_recent_comments select option:focus',
            	'.widget.widget_product_categories select:focus',
            	'.widget.widget_product_categories select option:focus',
            	'.widget.widget_categories select:focus',
            	'.widget.widget_categories select option:focus',
            	'.widget #lang_sel ul ul'
            );

            $border_color_important_selector = array(
            	'.zen-btn.zen-btn-solid:not(.zen-btn-custom-border-hover):hover',
            	'.zen-btn.zen-btn-outline:not(.zen-btn-custom-border-hover):hover'
        	);
			if(rouhi_zenith_is_woocommerce_installed()){
				$color_selector = array_merge($color_selector,array(
					'.woocommerce-pagination .page-numbers li span.current',
					'.woocommerce-pagination .page-numbers li a:hover',
					'.woocommerce-pagination .page-numbers li span:hover',
					'.woocommerce-pagination .page-numbers li span.current:hover',
					'.zen-single-product-summary input[type="submit"]:hover',
					'.zen-woocommerce-page .woocommerce-product-rating .woocommerce-review-link:hover',
					'.zen-woocommerce-page .star-rating',
					'.zen-woocommerce-page input[type="submit"].button',
					'.zen-shopping-cart-dropdown ul li a:hover',
					'.zen-shopping-cart-dropdown .zen-item-info-holder .zen-item-left:hover',
					'.zen-shopping-cart-dropdown span.zen-total span',
					'.zen-shopping-cart-dropdown .zen-empty-cart .zen-cart-icon-empty',
					'.zen-shopping-cart-dropdown span.zen-quantity',
					'.woocommerce.widget_price_filter .price_slider_amount button:hover',
					'.zen-woocommerce-page .select2-container .select2-choice .select2-arrow b:after',
					'.woocommerce-pagination .page-numbers li span.current',
					'.woocommerce-pagination .page-numbers li a:hover',
					'.woocommerce-pagination .page-numbers li span:hover',
					'.woocommerce-pagination .page-numbers li span.current:hover',
					'.zen-single-product-summary input[type="submit"]:hover',
					'.zen-woocommerce-page .woocommerce-product-rating .woocommerce-review-link:hover',
					'.zen-woocommerce-page .star-rating',
					'.zen-woocommerce-page input[type="submit"].button',
					'.zen-shopping-cart-dropdown ul li a:hover',
					'.zen-shopping-cart-dropdown .zen-item-info-holder .zen-item-left:hover',
					'.zen-shopping-cart-dropdown span.zen-total span',
					'.zen-shopping-cart-dropdown .zen-empty-cart .zen-cart-icon-empty',
					'.zen-shopping-cart-dropdown span.zen-quantity',
					'.woocommerce.widget_price_filter .price_slider_amount button:hover',
					'.zen-woocommerce-page .select2-container .select2-choice .select2-arrow b:after'
				));

				$color_important_selector = array_merge($color_important_selector,array(
					'.zen-woocommerce-page .single_add_to_cart_button.zen-btn:hover',
					'.zen-woocommerce-page .single_add_to_cart_button.zen-btn:hover'
				));

				$background_color_selector = array_merge($background_color_selector,array(
					'.woocommerce .product .zen-onsale',
					'.woocommerce .product .zen-out-of-stock',
					'.zen-woocommerce-page .product .zen-onsale',
					'.zen-woocommerce-page .product .zen-out-of-stock',
					'.zen-woocommerce-page input[type="submit"].button:hover',
					'.woocommerce .product .zen-onsale',
					'.woocommerce .product .zen-out-of-stock',
					'.zen-woocommerce-page .product .zen-onsale',
					'.zen-woocommerce-page .product .zen-out-of-stock',
					'.zen-woocommerce-page input[type="submit"].button:hover'
				));

				$border_color_selector = array_merge($border_color_selector,array(
					'.zen-woocommerce-page .coupon input[type="text"]:focus',
					'.zen-woocommerce-page input[type="text"]:focus:not(.zen-search-field)',
					'.zen-woocommerce-page input[type="email"]:focus',
					'.zen-woocommerce-page input[type="tel"]:focus',
					'.zen-woocommerce-page input[type="password"]:focus',
					'.zen-woocommerce-page textarea:focus',
					'.zen-woocommerce-page input[type="submit"].button',
					'.zen-shopping-cart-dropdown',
					'.zen-woocommerce-page .coupon input[type="text"]:focus',
					'.zen-woocommerce-page input[type="text"]:focus:not(.zen-search-field)',
					'.zen-woocommerce-page input[type="email"]:focus',
					'.zen-woocommerce-page input[type="tel"]:focus',
					'.zen-woocommerce-page input[type="password"]:focus',
					'.zen-woocommerce-page textarea:focus',
					'.zen-woocommerce-page input[type="submit"].button',
					'.zen-shopping-cart-dropdown'
				));
			}

            echo rouhi_zenith_dynamic_css($color_selector, array('color' => rouhi_zenith_options()->getOptionValue('first_color')));
            echo rouhi_zenith_dynamic_css($color_important_selector, array('color' => rouhi_zenith_options()->getOptionValue('first_color').'!important'));
            echo rouhi_zenith_dynamic_css('::selection', array('background' => rouhi_zenith_options()->getOptionValue('first_color')));
            echo rouhi_zenith_dynamic_css('::-moz-selection', array('background' => rouhi_zenith_options()->getOptionValue('first_color')));
            echo rouhi_zenith_dynamic_css($background_color_selector, array('background-color' => rouhi_zenith_options()->getOptionValue('first_color')));
            echo rouhi_zenith_dynamic_css($background_color_important_selector, array('background-color' => rouhi_zenith_options()->getOptionValue('first_color').'!important'));
            echo rouhi_zenith_dynamic_css($border_color_selector, array('border-color' => rouhi_zenith_options()->getOptionValue('first_color')));
            echo rouhi_zenith_dynamic_css($border_color_important_selector, array('border-color' => rouhi_zenith_options()->getOptionValue('first_color').'!important'));
        }

		if (rouhi_zenith_options()->getOptionValue('page_background_color')) {
			$background_color_selector = array(
				'.zen-wrapper-inner',
				'.zen-content',
				'.zen-container',
				'.single-post .zen-content-inner > .zen-container',
                '.single-portfolio-item .zen-content-inner > .zen-container',
				'.zen-tabs.zen-vertical .zen-tabs-nav li.ui-state-active a'
			);
			echo rouhi_zenith_dynamic_css($background_color_selector, array('background-color' => rouhi_zenith_options()->getOptionValue('page_background_color')));
		}

		if (rouhi_zenith_options()->getOptionValue('selection_color')) {
			echo rouhi_zenith_dynamic_css('::selection', array('background' => rouhi_zenith_options()->getOptionValue('selection_color')));
			echo rouhi_zenith_dynamic_css('::-moz-selection', array('background' => rouhi_zenith_options()->getOptionValue('selection_color')));
		}

		$boxed_background_style = array();
		if (rouhi_zenith_options()->getOptionValue('page_background_color_in_box')) {
			$boxed_background_style['background-color'] = rouhi_zenith_options()->getOptionValue('page_background_color_in_box');
		}

		if (rouhi_zenith_options()->getOptionValue('boxed_background_image')) {
			$boxed_background_style['background-image'] = 'url('.esc_url(rouhi_zenith_options()->getOptionValue('boxed_background_image')).')';
			$boxed_background_style['background-position'] = 'center 0px';
			$boxed_background_style['background-repeat'] = 'no-repeat';
		}

		if (rouhi_zenith_options()->getOptionValue('boxed_pattern_background_image')) {
			$boxed_background_style['background-image'] = 'url('.esc_url(rouhi_zenith_options()->getOptionValue('boxed_pattern_background_image')).')';
			$boxed_background_style['background-position'] = '0px 0px';
			$boxed_background_style['background-repeat'] = 'repeat';
		}

		if (rouhi_zenith_options()->getOptionValue('boxed_background_image_attachment')) {
			$boxed_background_style['background-attachment'] = (rouhi_zenith_options()->getOptionValue('boxed_background_image_attachment'));
		}

		echo rouhi_zenith_dynamic_css('.zen-boxed .zen-wrapper', $boxed_background_style);


		$content_top_padding_grid = rouhi_zenith_options()->getOptionValue('content_top_padding_grid');
		if ($content_top_padding_grid !== ''){
			echo rouhi_zenith_dynamic_css('.zen-content-inner > .zen-container', array('padding-top' => rouhi_zenith_filter_px($content_top_padding_grid).'px'));
		}

		$content_top_padding_full_width = rouhi_zenith_options()->getOptionValue('content_top_padding_full_width');
		if ($content_top_padding_full_width !== ''){
			echo rouhi_zenith_dynamic_css('.zen-content-inner > .zen-full-width', array('padding-top' => rouhi_zenith_filter_px($content_top_padding_full_width).'px'));
		}
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_design_styles');
}

if (!function_exists('rouhi_zenith_h1_styles')) {

    function rouhi_zenith_h1_styles() {

        $h1_styles = array();

        if(rouhi_zenith_options()->getOptionValue('h1_color') !== '') {
            $h1_styles['color'] = rouhi_zenith_options()->getOptionValue('h1_color');
        }
        if(rouhi_zenith_options()->getOptionValue('h1_google_fonts') !== '-1') {
            $h1_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('h1_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('h1_fontsize') !== '') {
            $h1_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h1_fontsize')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h1_lineheight') !== '') {
            $h1_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h1_lineheight')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h1_texttransform') !== '') {
            $h1_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('h1_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('h1_fontstyle') !== '') {
            $h1_styles['font-style'] = rouhi_zenith_options()->getOptionValue('h1_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('h1_fontweight') !== '') {
            $h1_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('h1_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('h1_letterspacing') !== '') {
            $h1_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h1_letterspacing')).'px';
        }

        $h1_selector = array(
            'h1'
        );

        if (!empty($h1_styles)) {
            echo rouhi_zenith_dynamic_css($h1_selector, $h1_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_h1_styles');
}

if (!function_exists('rouhi_zenith_h2_styles')) {

    function rouhi_zenith_h2_styles() {

        $h2_styles = array();

        if(rouhi_zenith_options()->getOptionValue('h2_color') !== '') {
            $h2_styles['color'] = rouhi_zenith_options()->getOptionValue('h2_color');
        }
        if(rouhi_zenith_options()->getOptionValue('h2_google_fonts') !== '-1') {
            $h2_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('h2_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('h2_fontsize') !== '') {
            $h2_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h2_fontsize')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h2_lineheight') !== '') {
            $h2_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h2_lineheight')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h2_texttransform') !== '') {
            $h2_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('h2_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('h2_fontstyle') !== '') {
            $h2_styles['font-style'] = rouhi_zenith_options()->getOptionValue('h2_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('h2_fontweight') !== '') {
            $h2_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('h2_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('h2_letterspacing') !== '') {
            $h2_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h2_letterspacing')).'px';
        }

        $h2_selector = array(
            'h2'
        );

        if (!empty($h2_styles)) {
            echo rouhi_zenith_dynamic_css($h2_selector, $h2_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_h2_styles');
}

if (!function_exists('rouhi_zenith_h3_styles')) {

    function rouhi_zenith_h3_styles() {

        $h3_styles = array();

        if(rouhi_zenith_options()->getOptionValue('h3_color') !== '') {
            $h3_styles['color'] = rouhi_zenith_options()->getOptionValue('h3_color');
        }
        if(rouhi_zenith_options()->getOptionValue('h3_google_fonts') !== '-1') {
            $h3_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('h3_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('h3_fontsize') !== '') {
            $h3_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h3_fontsize')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h3_lineheight') !== '') {
            $h3_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h3_lineheight')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h3_texttransform') !== '') {
            $h3_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('h3_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('h3_fontstyle') !== '') {
            $h3_styles['font-style'] = rouhi_zenith_options()->getOptionValue('h3_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('h3_fontweight') !== '') {
            $h3_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('h3_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('h3_letterspacing') !== '') {
            $h3_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h3_letterspacing')).'px';
        }

        $h3_selector = array(
            'h3'
        );

        if (!empty($h3_styles)) {
            echo rouhi_zenith_dynamic_css($h3_selector, $h3_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_h3_styles');
}

if (!function_exists('rouhi_zenith_h4_styles')) {

    function rouhi_zenith_h4_styles() {

        $h4_styles = array();

        if(rouhi_zenith_options()->getOptionValue('h4_color') !== '') {
            $h4_styles['color'] = rouhi_zenith_options()->getOptionValue('h4_color');
        }
        if(rouhi_zenith_options()->getOptionValue('h4_google_fonts') !== '-1') {
            $h4_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('h4_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('h4_fontsize') !== '') {
            $h4_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h4_fontsize')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h4_lineheight') !== '') {
            $h4_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h4_lineheight')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h4_texttransform') !== '') {
            $h4_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('h4_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('h4_fontstyle') !== '') {
            $h4_styles['font-style'] = rouhi_zenith_options()->getOptionValue('h4_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('h4_fontweight') !== '') {
            $h4_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('h4_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('h4_letterspacing') !== '') {
            $h4_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h4_letterspacing')).'px';
        }

        $h4_selector = array(
            'h4'
        );

        if (!empty($h4_styles)) {
            echo rouhi_zenith_dynamic_css($h4_selector, $h4_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_h4_styles');
}

if (!function_exists('rouhi_zenith_h5_styles')) {

    function rouhi_zenith_h5_styles() {

        $h5_styles = array();

        if(rouhi_zenith_options()->getOptionValue('h5_color') !== '') {
            $h5_styles['color'] = rouhi_zenith_options()->getOptionValue('h5_color');
        }
        if(rouhi_zenith_options()->getOptionValue('h5_google_fonts') !== '-1') {
            $h5_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('h5_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('h5_fontsize') !== '') {
            $h5_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h5_fontsize')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h5_lineheight') !== '') {
            $h5_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h5_lineheight')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h5_texttransform') !== '') {
            $h5_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('h5_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('h5_fontstyle') !== '') {
            $h5_styles['font-style'] = rouhi_zenith_options()->getOptionValue('h5_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('h5_fontweight') !== '') {
            $h5_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('h5_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('h5_letterspacing') !== '') {
            $h5_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h5_letterspacing')).'px';
        }

        $h5_selector = array(
            'h5'
        );

        if (!empty($h5_styles)) {
            echo rouhi_zenith_dynamic_css($h5_selector, $h5_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_h5_styles');
}

if (!function_exists('rouhi_zenith_h6_styles')) {

    function rouhi_zenith_h6_styles() {

        $h6_styles = array();

        if(rouhi_zenith_options()->getOptionValue('h6_color') !== '') {
            $h6_styles['color'] = rouhi_zenith_options()->getOptionValue('h6_color');
        }
        if(rouhi_zenith_options()->getOptionValue('h6_google_fonts') !== '-1') {
            $h6_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('h6_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('h6_fontsize') !== '') {
            $h6_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h6_fontsize')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h6_lineheight') !== '') {
            $h6_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h6_lineheight')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('h6_texttransform') !== '') {
            $h6_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('h6_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('h6_fontstyle') !== '') {
            $h6_styles['font-style'] = rouhi_zenith_options()->getOptionValue('h6_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('h6_fontweight') !== '') {
            $h6_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('h6_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('h6_letterspacing') !== '') {
            $h6_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('h6_letterspacing')).'px';
        }

        $h6_selector = array(
            'h6'
        );

        if (!empty($h6_styles)) {
            echo rouhi_zenith_dynamic_css($h6_selector, $h6_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_h6_styles');
}

if (!function_exists('rouhi_zenith_text_styles')) {

    function rouhi_zenith_text_styles() {

        $text_styles = array();

        if(rouhi_zenith_options()->getOptionValue('text_color') !== '') {
            $text_styles['color'] = rouhi_zenith_options()->getOptionValue('text_color');
        }
        if(rouhi_zenith_options()->getOptionValue('text_google_fonts') !== '-1') {
            $text_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('text_google_fonts'));
            echo rouhi_zenith_dynamic_css(array(
            	'.zen-blog-holder article span.zen-quote-author',
            	'.zen-single-links-pages .zen-single-links-pages-inner > a',
            	'.zen-single-links-pages .zen-single-links-pages-inner > span',
            	'.zen-comment-holder .zen-comment-text .zen-comment-date',
            	'.zen-pagination li a',
            	'.zen-pagination li.active span',
            	'.zen-counter-holder .zen-counter',
            	'.zen-progress-bar.zen-progress-on-side .zen-progress-number-wrapper .zen-progress-number',
            	'.zen-price-table .zen-price-table-inner .zen-table-prices .zen-price',
            	'.zen-blog-list-holder.zen-image-in-box .zen-item-info-section',
            	'blockquote div.zen-blockquote-text',
            	'.zen-process-outer .zen-process-slider .zen-process-slider-content-area .zen-process-slider-item .zen-process-slide-item-title-holder .zen-process-slide-item-number',
            	'.widget.widget_text'
        	),array('font-family' => $text_styles['font-family']));

			if (rouhi_zenith_is_woocommerce_installed()){
				echo rouhi_zenith_dynamic_css(array(
					'.woocommerce .product .price',
					'.zen-woocommerce-page .product .price',
					'.woocommerce .product .zen-onsale',
					'.woocommerce .product .zen-out-of-stock',
					'.zen-woocommerce-page .product .zen-onsale',
					'.zen-woocommerce-page .product .zen-out-of-stock',
					'.woocommerce-pagination .page-numbers li > a',
					'.woocommerce-pagination .page-numbers li > span',
					'.zen-woocommerce-page .woocommerce-product-rating .woocommerce-review-link',
					'.zen-woocommerce-page .zen-quantity-buttons .zen-quantity-input',
					'.zen-shopping-cart-outer .zen-shopping-cart-header .zen-cart-no',
					'.zen-shopping-cart-dropdown .zen-item-info-holder .zen-item-left .amount',
					'.zen-shopping-cart-dropdown .zen-cart-bottom .zen-subtotal-holder .zen-total-amount',
					'.woocommerce.widget_price_filter .price_slider_amount .price_label',
					'.widget .product_list_widget li .amount'
				),array('font-family' => $text_styles['font-family']));
			}
        }
        if(rouhi_zenith_options()->getOptionValue('text_fontsize') !== '') {
            $text_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('text_fontsize')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('text_lineheight') !== '') {
            $text_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('text_lineheight')).'px';
        }
        if(rouhi_zenith_options()->getOptionValue('text_texttransform') !== '') {
            $text_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('text_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('text_fontstyle') !== '') {
            $text_styles['font-style'] = rouhi_zenith_options()->getOptionValue('text_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('text_fontweight') !== '') {
            $text_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('text_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('text_letterspacing') !== '') {
            $text_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('text_letterspacing')).'px';
        }

        $text_selector = array(
            'p'
        );

        if (!empty($text_styles)) {
            echo rouhi_zenith_dynamic_css($text_selector, $text_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_text_styles');
}

if (!function_exists('rouhi_zenith_link_styles')) {

    function rouhi_zenith_link_styles() {

        $link_styles = array();

        if(rouhi_zenith_options()->getOptionValue('link_color') !== '') {
            $link_styles['color'] = rouhi_zenith_options()->getOptionValue('link_color');
        }
        if(rouhi_zenith_options()->getOptionValue('link_fontstyle') !== '') {
            $link_styles['font-style'] = rouhi_zenith_options()->getOptionValue('link_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('link_fontweight') !== '') {
            $link_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('link_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('link_fontdecoration') !== '') {
            $link_styles['text-decoration'] = rouhi_zenith_options()->getOptionValue('link_fontdecoration');
        }

        $link_selector = array(
            'a',
            'p a'
        );

        if (!empty($link_styles)) {
            echo rouhi_zenith_dynamic_css($link_selector, $link_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_link_styles');
}

if (!function_exists('rouhi_zenith_link_hover_styles')) {

    function rouhi_zenith_link_hover_styles() {

        $link_hover_styles = array();

        if(rouhi_zenith_options()->getOptionValue('link_hovercolor') !== '') {
            $link_hover_styles['color'] = rouhi_zenith_options()->getOptionValue('link_hovercolor');
        }
        if(rouhi_zenith_options()->getOptionValue('link_hover_fontdecoration') !== '') {
            $link_hover_styles['text-decoration'] = rouhi_zenith_options()->getOptionValue('link_hover_fontdecoration');
        }

        $link_hover_selector = array(
            'a:hover',
            'p a:hover'
        );

        if (!empty($link_hover_styles)) {
            echo rouhi_zenith_dynamic_css($link_hover_selector, $link_hover_styles);
        }

        $link_heading_hover_styles = array();

        if(rouhi_zenith_options()->getOptionValue('link_hovercolor') !== '') {
            $link_heading_hover_styles['color'] = rouhi_zenith_options()->getOptionValue('link_hovercolor');
        }

        $link_heading_hover_selector = array(
            'h1 a:hover',
            'h2 a:hover',
            'h3 a:hover',
            'h4 a:hover',
            'h5 a:hover',
            'h6 a:hover'
        );

        if (!empty($link_heading_hover_styles)) {
            echo rouhi_zenith_dynamic_css($link_heading_hover_selector, $link_heading_hover_styles);
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_link_hover_styles');
}

if (!function_exists('rouhi_zenith_sidebar_styles')) {

	function rouhi_zenith_sidebar_styles() {
		$sidebar_styles = array();

		$background_color = rouhi_zenith_options()->getOptionValue('sidebar_background_color');
		if ($background_color !== ''){
			$sidebar_styles['background-color'] = $background_color;
		}

		$padding_top = rouhi_zenith_options()->getOptionValue('sidebar_padding_top');
		if ($padding_top !== ''){
			$sidebar_styles['padding-top'] = rouhi_zenith_filter_px($padding_top).'px';
		}

		$padding_right = rouhi_zenith_options()->getOptionValue('sidebar_padding_right');
		if ($padding_right !== ''){
			$sidebar_styles['padding-right'] = rouhi_zenith_filter_px($padding_right).'px';
		}

		$padding_bottom = rouhi_zenith_options()->getOptionValue('sidebar_padding_bottom');
		if ($padding_bottom !== ''){
			$sidebar_styles['padding-bottom'] = rouhi_zenith_filter_px($padding_bottom).'px';
		}

		$padding_left = rouhi_zenith_options()->getOptionValue('sidebar_padding_left');
		if ($padding_left !== ''){
			$sidebar_styles['padding-left'] = rouhi_zenith_filter_px($padding_left).'px';
		}

		if(is_array($sidebar_styles) && count($sidebar_styles)){
			echo rouhi_zenith_dynamic_css('.zen-sidebar',$sidebar_styles);
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_sidebar_styles');
}