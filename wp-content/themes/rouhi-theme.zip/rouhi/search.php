<?php $sidebar = rouhi_zenith_sidebar_layout(); ?>
<?php get_header(); ?>
<?php 
global $wp_query;

if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
else { $paged = 1; }

if(rouhi_zenith_options()->getOptionValue('blog_page_range') != ""){
	$blog_page_range = esc_attr(rouhi_zenith_options()->getOptionValue('blog_page_range'));
} else{
	$blog_page_range = $wp_query->max_num_pages;
}
?>
<?php rouhi_zenith_get_title(); ?>
	<div class="zen-container">
		<?php do_action('rouhi_zenith_after_container_open'); ?>
		<div class="zen-container-inner clearfix">
			<div class="zen-container">
				<?php do_action('rouhi_zenith_after_container_open'); ?>
				<div class="zen-container-inner" >
					<h2 class="zen-search-for"><?php echo esc_html__('Search results for: ', 'rouhi').get_search_query();?></h2>
					<div class="zen-blog-holder zen-blog-type-standard">
                        <?php if(have_posts()) : while ( have_posts() ) : the_post();
								rouhi_zenith_get_post_format_html('standard');
                        endwhile; ?>
                            <?php
                            if(rouhi_zenith_options()->getOptionValue('pagination') == 'yes') {
                                rouhi_zenith_pagination($wp_query->max_num_pages, $blog_page_range, $paged);
                            }
                            ?>
                        <?php else: ?>
                            <div class="entry zen-search-none">
                                <p><?php esc_html_e('No posts were found.', 'rouhi'); ?></p>
                            </div>
                        <?php endif; ?>
				</div>
				<?php do_action('rouhi_zenith_before_container_close'); ?>
			</div>
			</div>
		</div>
		<?php do_action('rouhi_zenith_before_container_close'); ?>
	</div>
<?php get_footer(); ?>