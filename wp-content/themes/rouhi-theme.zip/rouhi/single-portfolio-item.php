<?php

get_header();
rouhi_zenith_get_title();
get_template_part('slider');
rouhi_zenith_single_portfolio();
get_footer();

?>