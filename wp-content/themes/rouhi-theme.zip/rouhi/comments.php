<div class="zen-comment-holder clearfix" id="comments">
	<div class="zen-comment-number">
		<div class="zen-comment-number-inner">
			<h4><?php esc_html_e('Latest comments','rouhi'); ?></h4>
		</div>
	</div>
<div class="zen-comments">
<?php if ( post_password_required() ) : ?>
				<p class="zen-no-password"><?php esc_html_e( 'This post is password protected. Enter the password to view any comments.', 'rouhi' ); ?></p>
			</div></div>
<?php
		return;
	endif;
?>
<?php if ( have_comments() ) : ?>

	<ul class="zen-comment-list">
		<?php wp_list_comments(array( 'callback' => 'rouhi_zenith_comment')); ?>
	</ul>


<?php // End Comments ?>

 <?php else : // this is displayed if there are no comments so far 

	if ( ! comments_open() ) :
?>
		<!-- If comments are open, but there are no comments. -->

	 
		<!-- If comments are closed. -->
		<p><?php esc_html_e('Sorry, the comment form is closed at this time.', 'rouhi'); ?></p>

	<?php endif; ?>
<?php endif; ?>
</div></div>
<?php
$commenter = wp_get_current_commenter();
$req = get_option( 'require_name_email' );
$aria_req = ( $req ? " aria-required='true'" : '' );

$args = array(
	'id_form' => 'commentform',
	'id_submit' => 'submit_comment',
	'title_reply'=> esc_html__( 'Post a comment','rouhi' ),
	'title_reply_to' => esc_html__( 'Post a reply to %s','rouhi' ),
	'cancel_reply_link' => esc_html__( 'Cancel reply','rouhi' ),
	'label_submit' => esc_html__( 'Post the comment','rouhi' ),
	'comment_field' => '<textarea id="comment" placeholder="'.esc_html__( 'Write your comment here...','rouhi' ).'" name="comment" cols="45" rows="8" aria-required="true"></textarea>',
	'comment_notes_before' => '',
	'comment_notes_after' => '',
	'fields' => apply_filters( 'comment_form_default_fields', array(
		'author' => '<div class="zen-two-columns-50-50 clearfix"><div class="zen-two-columns-50-50-inner"><div class="zen-column"><div class="zen-column-inner"><input id="author" name="author" placeholder="'. esc_html__( 'Your full name','rouhi' ) .'" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '"' . $aria_req . ' /></div></div>',
		'url' => '<div class="zen-column"><div class="zen-column-inner"><input id="email" name="email" placeholder="'. esc_html__( 'E-mail address','rouhi' ) .'" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '"' . $aria_req . ' /></div></div></div></div>',
		'email' => '<div class="zen-column"><div class="zen-column-inner"><input id="url" name="url" type="text" placeholder="'. esc_html__( 'Website','rouhi' ) .'" value="' . esc_attr( $commenter['comment_author_url'] ) . '" /></div></div>'
		 ) ) );
 ?>
<?php if(get_comment_pages_count() > 1){
	?>
	<div class="zen-comment-pager">
		<p><?php paginate_comments_links(); ?></p>
	</div>
<?php } ?>
 <div class="zen-comment-form">
	<?php comment_form($args); ?>
</div>
								
							


