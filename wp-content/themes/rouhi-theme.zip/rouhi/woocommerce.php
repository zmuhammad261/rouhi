<?php 
/*
Template Name: WooCommerce
*/ 
?>
<?php

global $woocommerce;

$id = get_option('woocommerce_shop_page_id');
$shop = get_post($id);
$sidebar = rouhi_zenith_sidebar_layout();

if(get_post_meta($id, 'zen_page_background_color', true) != ''){
	$background_color = 'background-color: '.esc_attr(get_post_meta($id, 'zen_page_background_color', true));
}else{
	$background_color = '';
}

$content_style = '';
if(get_post_meta($id, 'zen_content-top-padding', true) != '') {
	if(get_post_meta($id, 'zen_content-top-padding-mobile', true) == 'yes') {
		$content_style = 'padding-top:'.esc_attr(get_post_meta($id, 'zen_content-top-padding', true)).'px !important';
	} else {
		$content_style = 'padding-top:'.esc_attr(get_post_meta($id, 'zen_content-top-padding', true)).'px';
	}
}

if ( get_query_var('paged') ) {
	$paged = get_query_var('paged');
} elseif ( get_query_var('page') ) {
	$paged = get_query_var('page');
} else {
	$paged = 1;
}

get_header();

rouhi_zenith_get_title();
get_template_part('slider');

$full_width = false;

if ( rouhi_zenith_options()->getOptionValue('zen_woo_products_list_full_width') == 'yes' && !is_singular('product') ) {
	$full_width = true;
}

if ( $full_width ) { ?>
	<div class="zen-full-width" <?php rouhi_zenith_inline_style($background_color); ?>>
<?php } else { ?>
	<div class="zen-container" <?php rouhi_zenith_inline_style($background_color); ?>>
<?php }
		if ( $full_width ) { ?>
			<div class="zen-full-width-inner" <?php rouhi_zenith_inline_style($content_style); ?>>
		<?php } else { ?>
			<div class="zen-container-inner clearfix" <?php rouhi_zenith_inline_style($content_style); ?>>
		<?php }

			//Woocommerce content
			if ( ! is_singular('product') ) {

				switch( $sidebar ) {

					case 'sidebar-33-right': ?>
						<div class="zen-two-columns-66-33 grid2 zen-woocommerce-with-sidebar clearfix">
							<div class="zen-column1">
								<div class="zen-column-inner">
									<?php rouhi_zenith_woocommerce_content(); ?>
								</div>
							</div>
							<div class="zen-column2">
								<?php get_sidebar();?>
							</div>
						</div>
					<?php
						break;
					case 'sidebar-25-right': ?>
						<div class="zen-two-columns-75-25 grid2 zen-woocommerce-with-sidebar clearfix">
							<div class="zen-column1 zen-content-left-from-sidebar">
								<div class="zen-column-inner">
									<?php rouhi_zenith_woocommerce_content(); ?>
								</div>
							</div>
							<div class="zen-column2">
								<?php get_sidebar();?>
							</div>
						</div>
					<?php
						break;
					case 'sidebar-33-left': ?>
						<div class="zen-two-columns-33-66 grid2 zen-woocommerce-with-sidebar clearfix">
							<div class="zen-column1">
								<?php get_sidebar();?>
							</div>
							<div class="zen-column2">
								<div class="zen-column-inner">
									<?php rouhi_zenith_woocommerce_content(); ?>
								</div>
							</div>
						</div>
					<?php
						break;
					case 'sidebar-25-left': ?>
						<div class="zen-two-columns-25-75 grid2 zen-woocommerce-with-sidebar clearfix">
							<div class="zen-column1">
								<?php get_sidebar();?>
							</div>
							<div class="zen-column2 zen-content-right-from-sidebar">
								<div class="zen-column-inner">
									<?php rouhi_zenith_woocommerce_content(); ?>
								</div>
							</div>
						</div>
					<?php
						break;
					default:
						rouhi_zenith_woocommerce_content();
				}

			} else {
				rouhi_zenith_woocommerce_content();
			} ?>

			</div>
	</div>
<?php get_footer(); ?>
