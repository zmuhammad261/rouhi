<?php get_header(); ?>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<?php rouhi_zenith_get_title(); ?>
<?php get_template_part('slider'); ?>
	<div class="zen-container">
		<?php do_action('rouhi_zenith_after_container_open'); ?>
		<div class="zen-container-inner">
			<?php rouhi_zenith_get_blog_single(); ?>
		</div>
		<?php do_action('rouhi_zenith_before_container_close'); ?>
	</div>
	<?php rouhi_zenith_get_module_template_part('templates/single/parts/single-navigation', 'blog'); ?>
<?php endwhile; ?>
<?php endif; ?>
<?php get_footer(); ?>