<?php

add_action('after_setup_theme', 'rouhi_zenith_admin_map_init', 0);

function rouhi_zenith_admin_map_init() {

    do_action('rouhi_zenith_before_options_map');

    require_once zenith_framework_root_dir.'/admin/options/elements/map.php';
    require_once zenith_framework_root_dir.'/admin/options/fonts/map.php';
    require_once zenith_framework_root_dir.'/admin/options/general/map.php';
    require_once zenith_framework_root_dir.'/admin/options/page/map.php';
    require_once zenith_framework_root_dir.'/admin/options/sidebar/map.php';
    require_once zenith_framework_root_dir.'/admin/options/parallax/map.php';
    require_once zenith_framework_root_dir.'/admin/options/social/map.php';
    require_once zenith_framework_root_dir.'/admin/options/contentbottom/map.php';
    require_once zenith_framework_root_dir.'/admin/options/error404/map.php';
    require_once zenith_framework_root_dir.'/admin/options/reset/map.php';


    do_action('rouhi_zenith_options_map');

    do_action('rouhi_zenith_after_options_map');

}