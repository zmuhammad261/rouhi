<?php

if ( ! function_exists('rouhi_zenith_reset_options_map') ) {
	/**
	 * Reset options panel
	 */
	function rouhi_zenith_reset_options_map() {

		rouhi_zenith_add_admin_page(
			array(
				'slug'  => '_reset_page',
				'title' => 'Reset',
				'icon'  => 'fa fa-retweet'
			)
		);

		$panel_reset = rouhi_zenith_add_admin_panel(
			array(
				'page'  => '_reset_page',
				'name'  => 'panel_reset',
				'title' => 'Reset'
			)
		);

		rouhi_zenith_add_admin_field(array(
			'type'	=> 'yesno',
			'name'	=> 'reset_to_defaults',
			'default_value'	=> 'no',
			'label'			=> 'Reset to Defaults',
			'description'	=> 'This option will reset all Zenith Options values to defaults',
			'parent'		=> $panel_reset
		));

	}

	add_action( 'rouhi_zenith_options_map', 'rouhi_zenith_reset_options_map', 100 );

}