<?php

if ( ! function_exists('rouhi_zenith_load_elements_map') ) {
	/**
	 * Add Elements option page for shortcodes
	 */
	function rouhi_zenith_load_elements_map() {

		rouhi_zenith_add_admin_page(
			array(
				'slug' => '_elements_page',
				'title' => 'Elements',
				'icon' => 'fa fa-star'
			)
		);

		do_action( 'rouhi_zenith_options_elements_map' );

	}

	add_action('rouhi_zenith_options_map', 'rouhi_zenith_load_elements_map',12);

}