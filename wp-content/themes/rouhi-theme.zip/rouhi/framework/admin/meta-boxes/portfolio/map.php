<?php

$zen_pages = array();
$pages = get_pages(); 
foreach($pages as $page) {
	$zen_pages[$page->ID] = $page->post_title;
}

global $rouhi_zenith_IconCollections;

//Portfolio Images

$zenPortfolioImages = new RouhiMetaBox("portfolio-item", "Portfolio Images (multiple upload)", '', '', 'portfolio_images');
$rouhi_zenith_Framework->zenMetaBoxes->addMetaBox("portfolio_images",$zenPortfolioImages);

	$zen_portfolio_image_gallery = new RouhiMultipleImages("zen_portfolio-image-gallery","Portfolio Images","Choose your portfolio images");
	$zenPortfolioImages->addChild("zen_portfolio-image-gallery",$zen_portfolio_image_gallery);

//Portfolio Images/Videos 2

$zenPortfolioImagesVideos2 = new RouhiMetaBox("portfolio-item", "Portfolio Images/Videos (single upload)");
$rouhi_zenith_Framework->zenMetaBoxes->addMetaBox("portfolio_images_videos2",$zenPortfolioImagesVideos2);

	$zen_portfolio_images_videos2 = new RouhiImagesVideosFramework("Portfolio Images/Videos 2","ThisIsDescription");
	$zenPortfolioImagesVideos2->addChild("zen_portfolio_images_videos2",$zen_portfolio_images_videos2);

//Portfolio Additional Sidebar Items

$zenAdditionalSidebarItems = new RouhiMetaBox("portfolio-item", "Additional Portfolio Sidebar Items");
$rouhi_zenith_Framework->zenMetaBoxes->addMetaBox("portfolio_properties",$zenAdditionalSidebarItems);

	$zen_portfolio_properties = new RouhiOptionsFramework("Portfolio Properties","ThisIsDescription");
	$zenAdditionalSidebarItems->addChild("zen_portfolio_properties",$zen_portfolio_properties);

