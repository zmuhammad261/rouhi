<div class="zen-tabs-content">
    <div class="tab-content">

        <div class="tab-pane fade in active">
            <div class="zen-tab-content">
                <h2 class="zen-page-title"><?php echo esc_html($page->title); ?></h2>


                <form method="post" class="zen_ajax_form">
                    <div class="zen-page-form">
                        <?php wp_nonce_field('rouhi_zenith_ajax_save_nonce', 'rouhi_zenith_ajax_save_nonce'); ?>
                        <?php $page->render(); ?>
                    </div>
                </form>

            </div><!-- close zen-tab-content -->
        </div>

    </div>
</div> <!-- close div.zen-tabs-content -->