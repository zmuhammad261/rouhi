<div class="form-top-section">
    <div class="form-top-section-holder" id="anchornav">
        <div class="form-top-section-inner clearfix">
            <?php if(is_object($page) && property_exists($page, 'layout')) { ?>
            <div class="zen-anchor-holder">
                <?php if(is_array($page->layout) && count($page->layout)) { ?>
                    <span>Scroll To:</span>
                    <select class="nav-select zen-selectpicker" data-width="315px" data-hide-disabled="true" data-live-search="true" id="zen-select-anchor">
                        <option value="" disabled selected></option>
                        <?php foreach ($page->layout as $panel) { ?>
                            <option data-anchor="#zen_<?php echo esc_attr($panel->name); ?>"><?php echo esc_attr($panel->title); ?></option>
                        <?php } ?>
                    </select>

                <?php } ?>
            </div>
            <?php } ?>
        </div>
    </div>
</div>