<?php

if (rouhi_zenith_is_wpml_installed()) {
	include_once zenith_framework_modules_root_dir.'/wpml/wpml-functions.php';
}