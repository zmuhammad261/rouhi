<?php

//load lib
include_once zenith_framework_modules_root_dir.'/header/lib/header-functions.php';
include_once zenith_framework_modules_root_dir.'/header/lib/header-abstract.php';
include_once zenith_framework_modules_root_dir.'/header/lib/header-factory.php';
include_once zenith_framework_modules_root_dir.'/header/lib/header-connector.php';

//options
include_once zenith_framework_modules_root_dir.'/header/options-map/header-map.inc';
include_once zenith_framework_modules_root_dir.'/header/options-map/logo-map.php';
include_once zenith_framework_modules_root_dir.'/header/options-map/mobile-header.php';

//header types
include_once zenith_framework_modules_root_dir.'/header/types/header-standard.php';
include_once zenith_framework_modules_root_dir.'/header/types/header-centered-logo.php';

include_once zenith_framework_modules_root_dir.'/header/functions.php';
include_once zenith_framework_modules_root_dir.'/header/filter-functions.php';
include_once zenith_framework_modules_root_dir.'/header/template-functions.php';
include_once zenith_framework_modules_root_dir.'/header/template-hooks.php';
include_once zenith_framework_modules_root_dir.'/header/widget-areas-functions.php';

//custom styles
include_once zenith_framework_modules_root_dir.'/header/custom-styles/header.inc';
include_once zenith_framework_modules_root_dir.'/header/custom-styles/mobile-header.php';