<?php

if(!function_exists('rouhi_zenith_header_register_main_navigation')) {
    /**
     * Registers main navigation
     */
    function rouhi_zenith_header_register_main_navigation() {

        if(rouhi_zenith_options()->getOptionValue('header_type') == 'header-standard') {
            register_nav_menus(
                array(
                    'main-navigation' => esc_html__('Main Navigation', 'rouhi')
                )
            );
        }
        if(rouhi_zenith_options()->getOptionValue('header_type') == 'header-centered-logo') {
            register_nav_menus(
                array(
                    'left-main-navigation' => esc_html__('Left Main Navigation', 'rouhi')
                )
            );
            register_nav_menus(
                array(
                    'right-main-navigation' => esc_html__('Right Main Navigation', 'rouhi')
                )
            );
        }

        register_nav_menus(
            array(
                'mobile-navigation' => esc_html__('Mobile Navigation', 'rouhi')
            )
        );

    }

    add_action('after_setup_theme', 'rouhi_zenith_header_register_main_navigation');
}

if(!function_exists('rouhi_zenith_get_nav_menu_items_number')) {
    /**
     * Return number of menu items
     * @param $location
     * @return bool
     */
    function rouhi_zenith_get_nav_menu_items_number($location) {
        if(has_nav_menu($location)) {
            $theme_location  = $location;
            $theme_locations = get_nav_menu_locations();
            $menu_obj        = get_term($theme_locations[$theme_location], 'nav_menu');

            return $menu_obj->count;
        }else{
            return false;
        }
    }

    add_action('after_setup_theme', 'rouhi_zenith_header_register_main_navigation');
}

if(!function_exists('rouhi_zenith_get_sticky_header_height')) {
    /**
     * Returns top sticky header height
     *
     * @return bool|int|void
     */
    function rouhi_zenith_get_sticky_header_height() {
        //sticky menu height, needed only for sticky header on scroll up
        if(rouhi_zenith_options()->getOptionValue('header_type') !== 'header-vertical' &&
           in_array(rouhi_zenith_options()->getOptionValue('header_behaviour'), array('sticky-header-on-scroll-up'))) {

            $sticky_header_height = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('sticky_header_height'));

            return $sticky_header_height !== '' ? intval($sticky_header_height) : 60;
        }

        return 0;

    }
}

if(!function_exists('rouhi_zenith_get_sticky_header_height_of_complete_transparency')) {
    /**
     * Returns top sticky header height it is fully transparent. used in anchor logic
     *
     * @return bool|int|void
     */
    function rouhi_zenith_get_sticky_header_height_of_complete_transparency() {

        if(rouhi_zenith_options()->getOptionValue('header_type') !== 'header-vertical') {
            if(rouhi_zenith_options()->getOptionValue('sticky_header_transparency') === '0') {
                $stickyHeaderTransparent = rouhi_zenith_options()->getOptionValue('sticky_header_grid_background_color') !== '' &&
                                           rouhi_zenith_options()->getOptionValue('sticky_header_grid_transparency') === '0';
            } else {
                $stickyHeaderTransparent = rouhi_zenith_options()->getOptionValue('sticky_header_background_color') !== '' &&
                                           rouhi_zenith_options()->getOptionValue('sticky_header_transparency') === '0';
            }

            if($stickyHeaderTransparent) {
                return 0;
            } else {
                $sticky_header_height = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('sticky_header_height'));

                return $sticky_header_height !== '' ? intval($sticky_header_height) : 60;
            }
        }
        return 0;
    }
}

if(!function_exists('rouhi_zenith_get_sticky_scroll_amount')) {
    /**
     * Returns top sticky scroll amount
     *

     * @return bool|int|void
     */
    function rouhi_zenith_get_sticky_scroll_amount() {

        //sticky menu scroll amount
        if(rouhi_zenith_options()->getOptionValue('header_type') !== 'header-vertical' &&
           in_array(rouhi_zenith_options()->getOptionValue('header_behaviour'), array('sticky-header-on-scroll-up','sticky-header-on-scroll-down-up'))) {

            $sticky_scroll_amount = rouhi_zenith_filter_px(rouhi_zenith_get_meta_field_intersect('scroll_amount_for_sticky'));

            return $sticky_scroll_amount !== '' ? intval($sticky_scroll_amount) : 0;
        }

        return 0;

    }
}