<?php

//mobile header
add_action('rouhi_zenith_after_page_header', 'rouhi_zenith_get_mobile_header');