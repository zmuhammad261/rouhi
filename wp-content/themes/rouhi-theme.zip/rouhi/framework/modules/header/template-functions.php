<?php

use Rouhi\Modules\Header\Lib\HeaderFactory;

if(!function_exists('rouhi_zenith_get_header')) {
    /**
     * Loads header HTML based on header type option. Sets all necessary parameters for header
     * and defines rouhi_zenith_header_type_parameters filter
     */
    function rouhi_zenith_get_header() {

        //will be read from options
        $header_type     = rouhi_zenith_options()->getOptionValue('header_type');
        $header_behavior = rouhi_zenith_options()->getOptionValue('header_behaviour');

        extract(rouhi_zenith_get_page_options());

        if(HeaderFactory::getInstance()->validHeaderObject()) {
            $parameters = array(
                'hide_logo'          => rouhi_zenith_options()->getOptionValue('hide_logo') == 'yes' ? true : false,
                'show_sticky'        => in_array($header_behavior, array(
                    'sticky-header-on-scroll-up',
                    'sticky-header-on-scroll-down-up'
                )) ? true : false,
                'menu_area_background_color' => $menu_area_background_color,
                'vertical_header_background_color' => $vertical_header_background_color,
                'vertical_header_opacity' => $vertical_header_opacity,
                'vertical_background_image' => $vertical_background_image
            );

            $parameters = apply_filters('rouhi_zenith_header_type_parameters', $parameters, $header_type);

            HeaderFactory::getInstance()->getHeaderObject()->loadTemplate($parameters);
        }
    }
}

if(!function_exists('rouhi_zenith_get_logo')) {
    /**
     * Loads logo HTML
     *
     * @param $slug
     */
    function rouhi_zenith_get_logo($slug = '') {

        $slug = $slug !== '' ? $slug : rouhi_zenith_options()->getOptionValue('header_type');

        if($slug == 'sticky'){
            $logo_image = rouhi_zenith_options()->getOptionValue('logo_image_sticky');
        }else{
            $logo_image = rouhi_zenith_options()->getOptionValue('logo_image');
        }

        $logo_image_dark = rouhi_zenith_options()->getOptionValue('logo_image_dark');
        $logo_image_light = rouhi_zenith_options()->getOptionValue('logo_image_light');


        //get logo image dimensions and set style attribute for image link.
        $logo_dimensions = rouhi_zenith_get_image_dimensions($logo_image);

        $logo_height = '';
        $logo_styles = '';
        if(is_array($logo_dimensions) && array_key_exists('height', $logo_dimensions)) {
            $logo_height = $logo_dimensions['height'];
            $logo_styles = 'height: '.intval($logo_height / 2).'px;'; //divided with 2 because of retina screens
        }

        $params = array(
            'logo_image'  => $logo_image,
            'logo_image_dark' => $logo_image_dark,
            'logo_image_light' => $logo_image_light,
            'logo_styles' => $logo_styles
        );

        rouhi_zenith_get_module_template_part('templates/parts/logo', 'header', $slug, $params);
    }
}

if(!function_exists('rouhi_zenith_get_main_menu')) {
    /**
     * Loads main menu HTML
     *
     * @param string $additional_class addition class to pass to template
     */
    function rouhi_zenith_get_main_menu($additional_class = 'zen-default-nav') {
        rouhi_zenith_get_module_template_part('templates/parts/navigation', 'header', '', array('additional_class' => $additional_class));
    }
}

if(!function_exists('rouhi_zenith_get_left_main_menu')) {
    /**
     * Loads main menu HTML
     *
     * @param string $additional_class addition class to pass to template
     */
    function rouhi_zenith_get_left_main_menu($additional_class = 'zen-default-nav') {
        rouhi_zenith_get_module_template_part('templates/parts/navigation-left', 'header', '', array('additional_class' => $additional_class));
    }
}

if(!function_exists('rouhi_zenith_get_right_main_menu')) {
    /**
     * Loads main menu HTML
     *
     * @param string $additional_class addition class to pass to template
     */
    function rouhi_zenith_get_right_main_menu($additional_class = 'zen-default-nav') {
        rouhi_zenith_get_module_template_part('templates/parts/navigation-right', 'header', '', array('additional_class' => $additional_class));
    }
}


if(!function_exists('rouhi_zenith_get_sticky_menu')) {
	/**
	 * Loads sticky menu HTML
	 *
	 * @param string $additional_class addition class to pass to template
	 */
	function rouhi_zenith_get_sticky_menu($additional_class = 'zen-default-nav') {
		rouhi_zenith_get_module_template_part('templates/parts/sticky-navigation', 'header', '', array('additional_class' => $additional_class));
	}
}

if(!function_exists('rouhi_zenith_get_sticky_left_main_menu')) {
    /**
     * Loads main menu HTML
     *
     * @param string $additional_class addition class to pass to template
     */
    function rouhi_zenith_get_sticky_left_main_menu($additional_class = 'zen-default-nav') {
        rouhi_zenith_get_module_template_part('templates/parts/sticky-navigation-left', 'header', '', array('additional_class' => $additional_class));
    }
}

if(!function_exists('rouhi_zenith_get_sticky_right_main_menu')) {
    /**
     * Loads main menu HTML
     *
     * @param string $additional_class addition class to pass to template
     */
    function rouhi_zenith_get_sticky_right_main_menu($additional_class = 'zen-default-nav') {
        rouhi_zenith_get_module_template_part('templates/parts/sticky-navigation-right', 'header', '', array('additional_class' => $additional_class));
    }
}

if(!function_exists('rouhi_zenith_get_sticky_header')) {
    /**
     * Loads sticky header behavior HTML
     * * @param $slug
     */
    function rouhi_zenith_get_sticky_header($slug = '') {

        $parameters = array(
            'hide_logo' => rouhi_zenith_options()->getOptionValue('hide_logo') == 'yes' ? true : false,
        );

        rouhi_zenith_get_module_template_part('templates/behaviors/sticky-header', 'header', $slug, $parameters);
    }
}

if(!function_exists('rouhi_zenith_get_mobile_header')) {
    /**
     * Loads mobile header HTML only if responsiveness is enabled
     */
    function rouhi_zenith_get_mobile_header() {
        if(rouhi_zenith_is_responsive_on()) {
            $header_type = rouhi_zenith_options()->getOptionValue('header_type');

            //this could be read from theme options
            $mobile_header_type = 'mobile-header';

            $parameters = array(
                'show_logo'              => rouhi_zenith_options()->getOptionValue('hide_logo') == 'yes' ? false : true,
                'show_navigation_opener' => has_nav_menu('mobile-navigation')
            );

            rouhi_zenith_get_module_template_part('templates/types/'.$mobile_header_type, 'header', $header_type, $parameters);
        }
    }
}

if(!function_exists('rouhi_zenith_get_mobile_logo')) {
    /**
     * Loads mobile logo HTML. It checks if mobile logo image is set and uses that, else takes normal logo image
     *
     * @param string $slug
     */
    function rouhi_zenith_get_mobile_logo($slug = '') {

        $slug = $slug !== '' ? $slug : rouhi_zenith_options()->getOptionValue('header_type');

        //check if mobile logo has been set and use that, else use normal logo
        if(rouhi_zenith_options()->getOptionValue('logo_image_mobile') !== '') {
            $logo_image = rouhi_zenith_options()->getOptionValue('logo_image_mobile');
        } else {
            $logo_image = rouhi_zenith_options()->getOptionValue('logo_image');
        }

        //get logo image dimensions and set style attribute for image link.
        $logo_dimensions = rouhi_zenith_get_image_dimensions($logo_image);

        $logo_height = '';
        $logo_styles = '';
        if(is_array($logo_dimensions) && array_key_exists('height', $logo_dimensions)) {
            $logo_height = $logo_dimensions['height'];
            $logo_styles = 'height: '.intval($logo_height / 2).'px'; //divided with 2 because of retina screens
        }

        //set parameters for logo
        $parameters = array(
            'logo_image'      => $logo_image,
            'logo_dimensions' => $logo_dimensions,
            'logo_height'     => $logo_height,
            'logo_styles'     => $logo_styles
        );

        rouhi_zenith_get_module_template_part('templates/parts/mobile-logo', 'header', $slug, $parameters);
    }
}

if(!function_exists('rouhi_zenith_get_mobile_nav')) {
    /**
     * Loads mobile navigation HTML
     */
    function rouhi_zenith_get_mobile_nav() {

        $slug = rouhi_zenith_options()->getOptionValue('header_type');

        rouhi_zenith_get_module_template_part('templates/parts/mobile-navigation', 'header', $slug);
    }
}

if(!function_exists('rouhi_zenith_get_page_options')) {
    /**
     * Gets options from page
     */
    function rouhi_zenith_get_page_options() {
        $id = rouhi_zenith_get_page_id();
        $page_options = array();
        $menu_area_background_color_rgba = '';
        $menu_area_background_color = '';
        $menu_area_background_transparency = '';
        $vertical_header_background_color = '';
        $vertical_header_opacity = '';
        $vertical_background_image = '';

        $header_type = rouhi_zenith_options()->getOptionValue('header_type');
        switch ($header_type) {
            case 'header-standard':

                if(($meta_temp = get_post_meta($id, 'zen_menu_area_background_color_header_standard_meta', true)) != '') {
                    $menu_area_background_color = $meta_temp;
                }

                if(($meta_temp = get_post_meta($id, 'zen_menu_area_background_transparency_header_standard_meta', true)) != '') {
                    $menu_area_background_transparency = $meta_temp;
                }

                if(rouhi_zenith_rgba_color($menu_area_background_color, $menu_area_background_transparency) !== null) {
                    $menu_area_background_color_rgba = 'background-color:'.rouhi_zenith_rgba_color($menu_area_background_color, $menu_area_background_transparency);
                }

                break;

            case 'header-vertical':
                if(($meta_temp = get_post_meta($id, 'zen_vertical_header_background_color_meta', true)) !== '') {
                    $vertical_header_background_color = 'background-color:'.$meta_temp;
                }

                if(($meta_temp = get_post_meta($id, 'zen_vertical_header_transparency_meta', true)) !== '') {
                    $vertical_header_opacity = 'opacity:'.$meta_temp;
                }

                if(get_post_meta($id, 'zen_disable_vertical_header_background_image_meta', true) == 'yes'){
                    $vertical_background_image = 'background-image:none';
                }elseif(($meta_temp = get_post_meta($id, 'zen_vertical_header_background_image_meta', true)) !== ''){
                    $vertical_background_image = 'background-image:url('.$meta_temp.')';
                }

                break;
        }

        $page_options['menu_area_background_color'] = $menu_area_background_color_rgba;
        $page_options['vertical_header_background_color'] = $vertical_header_background_color;
        $page_options['vertical_header_opacity'] = $vertical_header_opacity;
        $page_options['vertical_background_image'] = $vertical_background_image;

        return $page_options;
    }
}