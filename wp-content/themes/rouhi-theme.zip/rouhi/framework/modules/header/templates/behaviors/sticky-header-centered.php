<?php do_action('rouhi_zenith_before_sticky_header'); ?>

<div class="zen-sticky-header">
    <?php do_action( 'rouhi_zenith_after_sticky_menu_html_open' ); ?>
    <div class="zen-sticky-holder">
        <div class="zen-vertical-align-containers">
            <div class="zen-position-left">
                <div class="zen-position-left-inner">

                    <?php if(is_active_sidebar('zen-sticky-left')) : ?>
                        <div class="widget">
                        <?php dynamic_sidebar('zen-sticky-left'); ?>
                        </div>
                    <?php endif; ?>
                    <?php rouhi_zenith_get_sticky_left_main_menu('zen-sticky-nav'); ?>
                </div>
            </div>
            <div class="zen-position-center">
                <div class="zen-position-center-inner">
                    <?php if(!$hide_logo) {
                        rouhi_zenith_get_logo('sticky');
                    } ?>
                </div>
            </div>
            <div class="zen-position-right">
                <div class="zen-position-right-inner">
                    <?php rouhi_zenith_get_sticky_right_main_menu('zen-sticky-nav'); ?>
                    <?php if(is_active_sidebar('zen-sticky-right')) : ?>
                        <div class="widget">
                        <?php dynamic_sidebar('zen-sticky-right'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php do_action('rouhi_zenith_after_sticky_header'); ?>