<?php do_action('rouhi_zenith_before_site_logo'); ?>

<div class="zen-logo-wrapper">
    <a href="<?php echo esc_url(home_url('/')); ?>" <?php rouhi_zenith_inline_style($logo_styles); ?>>
        <img class="zen-normal-logo" src="<?php echo esc_url($logo_image); ?>" alt="<?php esc_html_e('logo','rouhi'); ?>"/>
        <?php if(!empty($logo_image_dark)){ ?><img class="zen-dark-logo" src="<?php echo esc_url($logo_image_dark); ?>" alt="<?php esc_html_e('dark logo','rouhi'); ?>"/><?php } ?>
        <?php if(!empty($logo_image_light)){ ?><img class="zen-light-logo" src="<?php echo esc_url($logo_image_light); ?>" alt="<?php esc_html_e('light logo','rouhi'); ?>"/><?php } ?>
    </a>
</div>

<?php do_action('rouhi_zenith_after_site_logo'); ?>