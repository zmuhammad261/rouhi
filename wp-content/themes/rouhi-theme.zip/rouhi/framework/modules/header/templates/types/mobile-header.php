<?php do_action('rouhi_zenith_before_mobile_header'); ?>

<header class="zen-mobile-header">
    <div class="zen-mobile-header-inner">
        <?php do_action( 'rouhi_zenith_after_mobile_header_html_open' ) ?>
        <div class="zen-mobile-header-holder">

            <div class="zen-vertical-align-containers">
                <?php if($show_logo) : ?>
                    <div class="zen-position-left">
                        <div class="zen-position-left-inner">
                            <?php rouhi_zenith_get_mobile_logo(); ?>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="zen-position-right">
                    <div class="zen-position-right-inner">
                        <?php if(is_active_sidebar('zen-right-from-mobile-logo')) {
                            dynamic_sidebar('zen-right-from-mobile-logo');
                        } ?>
                        <?php if($show_navigation_opener) : ?>
                            <div class="zen-mobile-menu-opener">
                                <a href="javascript:void(0)">
                                    <span class="zen-mobile-opener-icon-holder">
                                        <span class="zen-line line1"></span>
                                        <span class="zen-line line2"></span>
                                        <span class="zen-line line3"></span>
                                        <span class="zen-line line4"></span>
                                        <span class="zen-line line5"></span>
                                    </span>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div> <!-- close .zen-vertical-align-containers -->

        </div>
        <?php rouhi_zenith_get_mobile_nav(); ?>
    </div>
</header> <!-- close .zen-mobile-header -->

<?php do_action('rouhi_zenith_after_mobile_header'); ?>