<?php do_action('rouhi_zenith_before_page_header'); ?>

<header class="zen-page-header">
    <div class="zen-menu-area" <?php rouhi_zenith_inline_style($menu_area_background_color); ?>>
        <?php do_action( 'rouhi_zenith_after_header_menu_area_html_open' )?>
        <div class="zen-vertical-align-containers">
            <div class="zen-position-left">
                <div class="zen-position-left-inner">
                    <?php if(!$hide_logo) {
                        rouhi_zenith_get_logo();
                    } ?>
                </div>
            </div>
            <div class="zen-position-center">
                <div class="zen-position-center-inner">
                    <?php rouhi_zenith_get_main_menu(); ?>
                </div>
            </div>
            <div class="zen-position-right">
                <div class="zen-position-right-inner">
                    <?php if(is_active_sidebar('zen-right-from-main-menu')) : ?>
                        <?php dynamic_sidebar('zen-right-from-main-menu'); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
    <?php if($show_sticky) {
        rouhi_zenith_get_sticky_header('standard');
    } ?>
</header>

<?php do_action('rouhi_zenith_after_page_header'); ?>

