<?php do_action('rouhi_zenith_before_mobile_logo'); ?>

<div class="zen-mobile-logo-wrapper">
    <a href="<?php echo esc_url(home_url('/')); ?>" <?php rouhi_zenith_inline_style($logo_styles); ?>>
        <img src="<?php echo esc_url($logo_image); ?>" alt="<?php esc_html_e('mobile logo','rouhi'); ?>"/>
    </a>
</div>

<?php do_action('rouhi_zenith_after_mobile_logo'); ?>