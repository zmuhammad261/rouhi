<?php do_action('rouhi_zenith_before_top_navigation'); ?>
<div>
<nav class="zen-main-menu zen-drop-down zen-items-number-<?php echo rouhi_zenith_get_nav_menu_items_number('right-main-navigation'); ?> <?php echo esc_attr($additional_class); ?>">
    <?php
    wp_nav_menu( array(
        'theme_location' => 'right-main-navigation' ,
        'container'  => '',
        'container_class' => '',
        'menu_class' => 'clearfix',
        'menu_id' => '',
        'fallback_cb' => 'top_navigation_fallback',
        'link_before' => '<span>',
        'link_after' => '</span>',
        'walker' => new RouhiTopNavigationWalker()
    ));
    ?>
</nav>
</div>
<?php do_action('rouhi_zenith_after_top_navigation'); ?>