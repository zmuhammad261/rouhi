<?php

if(!function_exists('rouhi_zenith_header_class')) {
    /**
     * Function that adds class to header based on theme options
     * @param array array of classes from main filter
     * @return array array of classes with added header class
     */
    function rouhi_zenith_header_class($classes) {
        $header_type = rouhi_zenith_get_meta_field_intersect('header_type', rouhi_zenith_get_page_id());

        $classes[] = 'zen-'.$header_type;

        return $classes;
    }

    add_filter('body_class', 'rouhi_zenith_header_class');
}

if(!function_exists('rouhi_zenith_header_behaviour_class')) {
    /**
     * Function that adds behaviour class to header based on theme options
     * @param array array of classes from main filter
     * @return array array of classes with added behaviour class
     */
    function rouhi_zenith_header_behaviour_class($classes) {

        $classes[] = 'zen-'.rouhi_zenith_options()->getOptionValue('header_behaviour');

        return $classes;
    }

    add_filter('body_class', 'rouhi_zenith_header_behaviour_class');
}

if(!function_exists('rouhi_zenith_mobile_header_class')) {
    function rouhi_zenith_mobile_header_class($classes) {
        $classes[] = 'zen-default-mobile-header';

        $classes[] = 'zen-sticky-up-mobile-header';

        return $classes;
    }

    add_filter('body_class', 'rouhi_zenith_mobile_header_class');
}

if(!function_exists('rouhi_zenith_header_class_first_level_bg_color')) {
    /**
     * Function that adds first level menu background color class to header tag
     * @param array array of classes from main filter
     * @return array array of classes with added first level menu background color class
     */
    function rouhi_zenith_header_class_first_level_bg_color($classes) {

        //check if first level hover background color is set
        if(rouhi_zenith_options()->getOptionValue('menu_hover_background_color') !== ''){
            $classes[]= 'zen-menu-item-first-level-bg-color';
        }

        return $classes;
    }

    add_filter('body_class', 'rouhi_zenith_header_class_first_level_bg_color');
}

if(!function_exists('rouhi_zenith_menu_dropdown_appearance')) {
    /**
     * Function that adds menu dropdown appearance class to body tag
     * @param array array of classes from main filter
     * @return array array of classes with added menu dropdown appearance class
     */
    function rouhi_zenith_menu_dropdown_appearance($classes) {

        if(rouhi_zenith_options()->getOptionValue('menu_dropdown_appearance') !== 'default'){
            $classes[] = 'zen-'.rouhi_zenith_options()->getOptionValue('menu_dropdown_appearance');
        }

        return $classes;
    }

    add_filter('body_class', 'rouhi_zenith_menu_dropdown_appearance');
}

if (!function_exists('rouhi_zenith_header_skin_class')) {

    function rouhi_zenith_header_skin_class( $classes ) {

        $id = rouhi_zenith_get_page_id();

		if(($meta_temp = get_post_meta($id, 'zen_header_style_meta', true)) !== ''){
			$classes[] = 'zen-' . $meta_temp;
		} else if ( rouhi_zenith_options()->getOptionValue('header_style') !== '' ) {
            $classes[] = 'zen-' . rouhi_zenith_options()->getOptionValue('header_style');
        }

        return $classes;

    }

    add_filter('body_class', 'rouhi_zenith_header_skin_class');

}

if (!function_exists('rouhi_zenith_header_scroll_style_class')) {

	function rouhi_zenith_header_scroll_style_class( $classes ) {

		if (rouhi_zenith_get_meta_field_intersect('enable_header_style_on_scroll') == 'yes' ) {
			$classes[] = 'zen-header-style-on-scroll';
		}

		return $classes;

	}

	add_filter('body_class', 'rouhi_zenith_header_scroll_style_class');

}

if(!function_exists('rouhi_zenith_header_global_js_var')) {
    function rouhi_zenith_header_global_js_var($global_variables) {

        $global_variables['zenTopBarHeight'] = 0; //beacuse there is no top header on this theme
        $global_variables['zenStickyHeaderHeight'] = rouhi_zenith_get_sticky_header_height();
        $global_variables['zenStickyHeaderTransparencyHeight'] = rouhi_zenith_get_sticky_header_height_of_complete_transparency();

        return $global_variables;
    }

    add_filter('rouhi_zenith_js_global_variables', 'rouhi_zenith_header_global_js_var');
}

if(!function_exists('rouhi_zenith_header_per_page_js_var')) {
    function rouhi_zenith_header_per_page_js_var($perPageVars) {

        $perPageVars['zenStickyScrollAmount'] = rouhi_zenith_get_sticky_scroll_amount();

        return $perPageVars;
    }

    add_filter('rouhi_zenith_per_page_js_vars', 'rouhi_zenith_header_per_page_js_var');
}