<?php
use Rouhi\Modules\Header\Lib;

if(!function_exists('rouhi_zenith_set_header_object')) {
    function rouhi_zenith_set_header_object() {
        $header_type = rouhi_zenith_get_meta_field_intersect('header_type', rouhi_zenith_get_page_id());

        $object = Lib\HeaderFactory::getInstance()->build($header_type);

        if(Lib\HeaderFactory::getInstance()->validHeaderObject()) {
            $header_connector = new Lib\HeaderConnector($object);
            $header_connector->connect($object->getConnectConfig());
        }
    }

    add_action('wp', 'rouhi_zenith_set_header_object', 1);
}