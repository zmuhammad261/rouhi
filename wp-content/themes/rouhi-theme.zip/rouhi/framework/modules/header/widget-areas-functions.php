<?php

if(!function_exists('rouhi_zenith_header_standard_widget_areas')) {
    /**
     * Registers widget areas for standard header type
     */
    function rouhi_zenith_header_standard_widget_areas() {
        if(rouhi_zenith_options()->getOptionValue('header_type') == 'header-standard') {
            register_sidebar(array(
                'name'          => esc_html__('Header Right', 'rouhi'),
                'id'            => 'zen-right-from-main-menu',
                'before_widget' => '<div id="%1$s" class="widget %2$s zen-right-from-main-menu-widget">',
                'after_widget'  => '</div>',
                'description'   => esc_html__('Widgets added here will appear on the right hand side from the main menu', 'rouhi')
            ));
        }
    }

    add_action('widgets_init', 'rouhi_zenith_header_standard_widget_areas');
}

if(!function_exists('rouhi_zenith_header_centered_logo_widget_areas')) {
    /**
     * Registers widget areas for centered logo header type
     */
    function rouhi_zenith_header_centered_logo_widget_areas() {
        if(rouhi_zenith_options()->getOptionValue('header_type') == 'header-centered-logo') {
            register_sidebar(array(
                'name'          => esc_html__('Header Left', 'rouhi'),
                'id'            => 'zen-left-from-logo',
                'before_widget' => '<div id="%1$s" class="%2$s zen-left-from-logo-widget">',
                'after_widget'  => '</div>',
                'description'   => esc_html__('Widgets added here will appear on the left hand side from logo', 'rouhi')
            ));

            register_sidebar(array(
                'name'          => esc_html__('Header Right', 'rouhi'),
                'id'            => 'zen-right-from-logo',
                'before_widget' => '<div id="%1$s" class="%2$s zen-right-from-logo-widget">',
                'after_widget'  => '</div>',
                'description'   => esc_html__('Widgets added here will appear on the right hand side from logo', 'rouhi')
            ));
        }
    }

    add_action('widgets_init', 'rouhi_zenith_header_centered_logo_widget_areas');
}

if(!function_exists('rouhi_zenith_register_sticky_header_areas')) {
    /**
     * Registers widget area for sticky header
     */
    function rouhi_zenith_register_sticky_header_areas() {
        if(in_array(rouhi_zenith_options()->getOptionValue('header_behaviour'), array('sticky-header-on-scroll-up','sticky-header-on-scroll-down-up'))) {
            if(rouhi_zenith_options()->getOptionValue('header_type') == 'header-standard') {
                register_sidebar(array(
                    'name' => esc_html__('Sticky Header Right', 'rouhi'),
                    'id' => 'zen-sticky-right-from-main-menu',
                    'before_widget' => '<div id="%1$s" class="%2$s zen-sticky-right-from-main-menu-widget">',
                    'after_widget' => '</div>',
                    'description' => esc_html__('Widgets added here will appear on the right hand side in sticky menu', 'rouhi')
                ));
            }
            if(rouhi_zenith_options()->getOptionValue('header_type') == 'header-centered-logo') {
                register_sidebar(array(
                    'name' => esc_html__('Sticky Header Left', 'rouhi'),
                    'id' => 'zen-sticky-left',
                    'before_widget' => '<div id="%1$s" class="%2$s zen-sticky-left">',
                    'after_widget' => '</div>',
                    'description' => esc_html__('Widgets added here will appear on the left hand side in sticky menu', 'rouhi')
                ));
                register_sidebar(array(
                    'name' => esc_html__('Sticky Header Right', 'rouhi'),
                    'id' => 'zen-sticky-right',
                    'before_widget' => '<div id="%1$s" class="%2$s zen-sticky-right">',
                    'after_widget' => '</div>',
                    'description' => esc_html__('Widgets added here will appear on the right hand side in sticky menu', 'rouhi')
                ));
            }
        }
    }

    add_action('widgets_init', 'rouhi_zenith_register_sticky_header_areas');
}

if(!function_exists('rouhi_zenith_register_mobile_header_areas')) {
    /**
     * Registers widget areas for mobile header
     */
    function rouhi_zenith_register_mobile_header_areas() {
        if(rouhi_zenith_is_responsive_on()) {
            register_sidebar(array(
                'name'          => esc_html__('Mobile Header Right', 'rouhi'),
                'id'            => 'zen-right-from-mobile-logo',
                'before_widget' => '<div id="%1$s" class="%2$s zen-right-from-mobile-logo">',
                'after_widget'  => '</div>',
                'description'   => esc_html__('Widgets added here will appear on the right hand side from the mobile logo', 'rouhi')
            ));
        }
    }

    add_action('widgets_init', 'rouhi_zenith_register_mobile_header_areas');
}