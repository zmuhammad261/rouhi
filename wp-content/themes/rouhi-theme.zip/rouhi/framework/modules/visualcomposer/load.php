<?php

if (rouhi_zenith_visual_composer_installed()) {
	include_once zenith_framework_modules_root_dir.'/visualcomposer/visual-composer-functions.php';
	include_once zenith_framework_modules_root_dir.'/visualcomposer/visual-composer-config.php';
}