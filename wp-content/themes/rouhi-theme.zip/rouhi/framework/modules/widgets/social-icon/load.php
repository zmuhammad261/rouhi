<?php

require_once zenith_framework_modules_root_dir.'/widgets/social-icon/social-icon.php';
