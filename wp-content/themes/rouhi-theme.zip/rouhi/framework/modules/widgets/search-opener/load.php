<?php

require_once zenith_framework_modules_root_dir.'/widgets/search-opener/search-opener.php';
