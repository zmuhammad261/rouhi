<?php

require_once zenith_framework_modules_root_dir.'/widgets/latest-post/latest-posts.php';