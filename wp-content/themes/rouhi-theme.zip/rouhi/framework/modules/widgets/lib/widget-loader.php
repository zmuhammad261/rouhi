<?php

if (!function_exists('rouhi_zenith_register_widgets')) {

	function rouhi_zenith_register_widgets() {

		$widgets = array(
			'RouhiFullScreenMenuOpener',
			'RouhiLatestPosts',
			'RouhiSearchOpener',
			'RouhiSocialIconWidget',
		);

		foreach ($widgets as $widget) {
			register_widget($widget);
		}
	}
}

add_action('widgets_init', 'rouhi_zenith_register_widgets');