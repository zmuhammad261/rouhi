<?php

include_once zenith_framework_modules_root_dir.'/blog/options-map/map.php';
include_once zenith_framework_modules_root_dir.'/blog/blog-functions.php';