<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="zen-post-content">
		<div class="zen-post-text">
			<div class="zen-post-text-inner clearfix">
				<div class="zen-post-title-holder">
					<div class="zen-post-mark-holder">
						<div class="zen-post-mark">
							<span class="icon-basic-lightbulb"></span>
						</div>
					</div>
					<div class="zen-post-title">
						<h2>
							<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo esc_html(get_post_meta(get_the_ID(), "zen_post_quote_text_meta", true)); ?></a>
						</h2>
						<h3 class="zen-quote-author">&mdash; <?php the_title(); ?></h3>
					</div>
				</div>
				<?php the_content(); ?>
			</div>
		</div>
	</div>
	<?php do_action('rouhi_zenith_before_blog_article_closed_tag'); ?>
</article>