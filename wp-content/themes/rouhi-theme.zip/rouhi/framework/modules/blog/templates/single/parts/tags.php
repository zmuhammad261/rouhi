<div class="zen-single-tags-holder">
	<h4 class="zen-single-tags-title"><?php esc_html_e('Post Tags:', 'rouhi'); ?></h4>
	<div class="zen-tags">
		<?php the_tags('', '', ''); ?>
	</div>
</div>