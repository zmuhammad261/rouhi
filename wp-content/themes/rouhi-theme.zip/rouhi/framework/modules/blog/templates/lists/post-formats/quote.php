<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="zen-post-content">
		<?php if (!$hide_image){
			rouhi_zenith_get_module_template_part('templates/lists/parts/image', 'blog');
		} ?>
		<div class="zen-post-text">
			<div class="zen-post-text-inner">
				<div class="zen-post-mark">
					<span class="icon-basic-lightbulb"></span>
				</div>
				<div class="zen-post-info">
					<?php rouhi_zenith_post_info(array('category' => 'yes', 'date' => 'no', 'comments' => 'no', 'share' => 'no', 'like' => 'no')) ?>
				</div>
				<div class="zen-post-title">
					<h3>
						<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php echo esc_html(get_post_meta(get_the_ID(), "zen_post_quote_text_meta", true)); ?></a>
					</h3>
					<span class="zen-quote-author">&mdash; <?php the_title(); ?></span>
				</div>
			</div>
			<?php
				rouhi_zenith_get_module_template_part('templates/lists/parts/author-read-more', 'blog');
			?>
		</div>
	</div>
</article>