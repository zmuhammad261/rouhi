<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="zen-post-content">
		<div class="zen-post-text">
			<div class="zen-post-text-inner clearfix">
				<div class="zen-post-title-holder">
					<div class="zen-post-mark-holder">
						<div class="zen-post-mark">
							<span class="icon-basic-link"></span>
						</div>
					</div>
					<h2 class="zen-post-title">
						<a href="<?php echo esc_html(get_post_meta(get_the_ID(), "zen_post_link_link_meta", true)); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
					</h2>
				</div>
				<?php the_content(); ?>
			</div>
		</div>
	</div>
	<?php do_action('rouhi_zenith_before_blog_article_closed_tag'); ?>
</article>