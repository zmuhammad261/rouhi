<div class="zen-blog-holder zen-blog-type-standard <?php echo rouhi_zenith_get_cols_number(); ?>">
	<?php
		if($blog_query->have_posts()) : while ( $blog_query->have_posts() ) : $blog_query->the_post();
			rouhi_zenith_get_post_format_html($blog_type,$hide_image);
		endwhile;
		else:
			rouhi_zenith_get_module_template_part('templates/parts/no-posts', 'blog');
		endif;
	?>
	<?php
		if(rouhi_zenith_options()->getOptionValue('pagination') == 'yes') {
			rouhi_zenith_pagination($blog_query->max_num_pages, $blog_page_range, $paged);
		}
	?>
</div>
