<?php rouhi_zenith_get_blog_before_content();?>
<?php if(($sidebar == 'default')||($sidebar == '')) : ?>
	<?php rouhi_zenith_get_blog_type($blog_type); ?>
<?php elseif($sidebar == 'sidebar-33-right' || $sidebar == 'sidebar-25-right'): ?>
	<div <?php echo rouhi_zenith_sidebar_columns_class(); ?>>
		<div class="zen-column1 zen-content-left-from-sidebar">
			<div class="zen-column-inner">
				<?php rouhi_zenith_get_blog_type($blog_type); ?>
			</div>
		</div>
		<div class="zen-column2">
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php elseif($sidebar == 'sidebar-33-left' || $sidebar == 'sidebar-25-left'): ?>
	<div <?php echo rouhi_zenith_sidebar_columns_class(); ?>>
		<div class="zen-column1">
			<?php get_sidebar(); ?>
		</div>
		<div class="zen-column2 zen-content-right-from-sidebar">
			<div class="zen-column-inner">
				<?php rouhi_zenith_get_blog_type($blog_type); ?>
			</div>
		</div>
	</div>
<?php endif; ?>

