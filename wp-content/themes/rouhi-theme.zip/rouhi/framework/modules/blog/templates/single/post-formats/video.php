<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="zen-post-content">
		<div class="zen-post-image">
			<?php rouhi_zenith_get_module_template_part('templates/parts/video', 'blog'); ?>
		</div>
		<div class="zen-post-text">
			<div class="zen-post-text-inner clearfix">
				<?php the_content(); ?>
			</div>
		</div>
	</div>
	<?php do_action('rouhi_zenith_before_blog_article_closed_tag'); ?>
</article>