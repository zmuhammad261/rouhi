<?php if (rouhi_zenith_options()->getOptionValue('enable_social_share') == 'yes' && rouhi_zenith_options()->getOptionValue('enable_social_share_on_post') == 'yes'){ ?>
<div class ="zen-blog-share">
	<?php echo rouhi_zenith_get_social_share_html(); ?>
</div>
<?php } ?>