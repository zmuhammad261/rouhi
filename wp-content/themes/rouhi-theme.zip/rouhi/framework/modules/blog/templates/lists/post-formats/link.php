<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="zen-post-content">
		<?php if (!$hide_image){
			rouhi_zenith_get_module_template_part('templates/lists/parts/image', 'blog');
		} ?>
		<div class="zen-post-text">
			<div class="zen-post-text-inner">
				<div class="zen-post-mark">
					<span class="icon-basic-link"></span>
				</div>
				<div class="zen-post-info">
					<?php rouhi_zenith_post_info(array('category' => 'yes', 'date' => 'no', 'comments' => 'no', 'share' => 'no', 'like' => 'no')) ?>
				</div>
				<?php rouhi_zenith_get_module_template_part('templates/lists/parts/title', 'blog'); ?>
				<?php
					rouhi_zenith_excerpt();
                    $args_pages = array(
                        'before'           => '<div class="zen-single-links-pages"><div class="zen-single-links-pages-inner">',
                        'after'            => '</div></div>',
                        'link_before'      => '<span>',
                        'link_after'       => '</span>',
                        'pagelink'         => '%'
                    );

                    wp_link_pages($args_pages);
				?>
			</div>
			<?php
				rouhi_zenith_get_module_template_part('templates/lists/parts/author-read-more', 'blog');
			?>
		</div>
	</div>
</article>