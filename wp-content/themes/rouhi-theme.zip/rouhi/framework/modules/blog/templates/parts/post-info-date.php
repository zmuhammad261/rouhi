<div class="zen-post-info-date">
	<?php if(!rouhi_zenith_post_has_title()) { ?>
	<a href="<?php the_permalink() ?>">
		<?php } ?>
		<?php the_time(get_option('date_format')); ?>
		<?php if(!rouhi_zenith_post_has_title()) { ?>
	</a>
<?php } ?>
</div>