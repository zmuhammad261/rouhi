<?php
	$author_info_box = esc_attr(rouhi_zenith_options()->getOptionValue('blog_author_info'));
	$author_info_email = esc_attr(rouhi_zenith_options()->getOptionValue('blog_author_info_email'));

?>
<?php if($author_info_box === 'yes') { ?>
	<div class="zen-author-description">
		<div class="zen-author-description-inner">
			<div class="zen-author-description-image">
				<?php echo rouhi_zenith_kses_img(get_avatar(get_the_author_meta( 'ID' ), 80)); ?>
			</div>
			<div class="zen-author-description-text-holder">
				<h4 class="zen-author-name">
					<?php esc_html_e('Written by:','rouhi'); ?>
					<span class="zen-author">
					<?php
						if(get_the_author_meta('first_name') != "" || get_the_author_meta('last_name') != "") {
							echo esc_attr(get_the_author_meta('first_name')) . " " . esc_attr(get_the_author_meta('last_name'));
						} else {
							echo esc_attr(get_the_author_meta('display_name'));
						}
					?>
					</span>
				</h4>
				<?php if($author_info_email === 'yes' && is_email(get_the_author_meta('email'))){ ?>
					<p class="zen-author-email"><?php echo sanitize_email(get_the_author_meta('email')); ?></p>
				<?php } ?>
				<?php if(get_the_author_meta('description') != "") { ?>
					<div class="zen-author-text">
						<p><?php echo esc_attr(get_the_author_meta('description')); ?></p>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
<?php } ?>