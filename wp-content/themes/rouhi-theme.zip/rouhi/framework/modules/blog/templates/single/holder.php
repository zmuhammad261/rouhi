<?php if(($sidebar == "default")||($sidebar == "")) : ?>
	<div class="zen-blog-holder zen-blog-single">
		<?php rouhi_zenith_get_single_html(); ?>
	</div>
<?php elseif($sidebar == 'sidebar-33-right' || $sidebar == 'sidebar-25-right'): ?>
	<div <?php echo rouhi_zenith_sidebar_columns_class(); ?>>
		<div class="zen-column1 zen-content-left-from-sidebar">
			<div class="zen-column-inner">
				<div class="zen-blog-holder zen-blog-single">
					<?php rouhi_zenith_get_single_html(); ?>
				</div>
			</div>
		</div>
		<div class="zen-column2">
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php elseif($sidebar == 'sidebar-33-left' || $sidebar == 'sidebar-25-left'): ?>
	<div <?php echo rouhi_zenith_sidebar_columns_class(); ?>>
		<div class="zen-column1">
			<?php get_sidebar(); ?>
		</div>
		<div class="zen-column2 zen-content-right-from-sidebar">
			<div class="zen-column-inner">
				<div class="zen-blog-holder zen-blog-single">
					<?php rouhi_zenith_get_single_html(); ?>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
