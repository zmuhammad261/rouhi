<?php if(rouhi_zenith_options()->getOptionValue('blog_single_navigation') == 'yes'){ ?>
	<?php $navigation_blog_through_category = rouhi_zenith_options()->getOptionValue('blog_navigation_through_same_category') ?>
	<div class="zen-blog-single-navigation">
		<div class="zen-blog-single-navigation-inner">
			<?php if(get_previous_post() != ""){ ?>
				<div class="zen-blog-single-prev">
					<?php
					if($navigation_blog_through_category == 'yes'){
						previous_post_link('%link','<span class="zen-btn-text">'.esc_html__('Previous post','rouhi').'</span><span class="zen-btn-icon-arrow"><span class="zen-line-1"></span><span class="zen-line-2"></span><span class="zen-line-3"></span></span>', true,'','category');
					} else {
						previous_post_link('%link','<span class="zen-btn-text">'.esc_html__('Previous post','rouhi').'</span><span class="zen-btn-icon-arrow"><span class="zen-line-1"></span><span class="zen-line-2"></span><span class="zen-line-3"></span></span>');
					}
					?>
				</div> <!-- close div.blog_prev -->
			<?php } ?>
			<div class="zen-blog-single-all">
				<a href="<?php echo rouhi_zenith_get_blog_list_url();?>" target="_blank"><?php esc_html_e('All posts','rouhi');?></a>
			</div>
			<?php if(get_next_post() != ""){ ?>
				<div class="zen-blog-single-next">
					<?php
					if($navigation_blog_through_category == 'yes'){
						next_post_link('%link','<span class="zen-btn-text">'.esc_html__('Next post','rouhi').'</span><span class="zen-btn-icon-arrow"><span class="zen-line-1"></span><span class="zen-line-2"></span><span class="zen-line-3"></span></span>', true,'','category');
					} else {
						next_post_link('%link','<span class="zen-btn-text">'.esc_html__('Next post','rouhi').'</span><span class="zen-btn-icon-arrow"><span class="zen-line-1"></span><span class="zen-line-2"></span><span class="zen-line-3"></span></span>');
					}
					?>
				</div>
			<?php } ?>
		</div>
	</div>
<?php } ?>