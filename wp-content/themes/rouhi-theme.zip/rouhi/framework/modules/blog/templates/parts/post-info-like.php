<div class="zen-blog-like">
	<?php if( function_exists('rouhi_zenith_get_like') ) rouhi_zenith_get_like(); ?>
</div>