<div class="zen-item-bottom-holder">
	<div class="zen-item-bottom-holder-inner">
		<div class="zen-item-btm-left-holder">
			<div class="zen-item-author-image">
				<?php echo rouhi_zenith_kses_img(get_avatar(get_the_author_meta( 'ID' ), 30)); ?>
			</div>
			<?php rouhi_zenith_post_info(array(
				'author' => 'yes',
			)) ?>
		</div>
		<div class="zen-item-btn-right-holder">
			<?php rouhi_zenith_read_more_button();?>
		</div>
	</div>
</div>