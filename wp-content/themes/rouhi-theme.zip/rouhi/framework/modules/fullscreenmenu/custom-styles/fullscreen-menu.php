<?php

if (!function_exists('rouhi_zenith_fullscreen_menu_general_styles')) {

	function rouhi_zenith_fullscreen_menu_general_styles()
	{
		$fullscreen_menu_background_color = '';
		if (rouhi_zenith_options()->getOptionValue('fullscreen_alignment') !== '') {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li, .zen-fullscreen-above-menu-widget-holder, .zen-fullscreen-below-menu-widget-holder', array(
				'text-align' => rouhi_zenith_options()->getOptionValue('fullscreen_alignment')
			));
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_background_color') !== '') {
			$fullscreen_menu_background_color = rouhi_zenith_hex2rgb(rouhi_zenith_options()->getOptionValue('fullscreen_menu_background_color'));
			if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_background_transparency') !== '') {
				$fullscreen_menu_background_transparency = rouhi_zenith_options()->getOptionValue('fullscreen_menu_background_transparency');
			} else {
				$fullscreen_menu_background_transparency = 0.9;
			}
		}

		if ($fullscreen_menu_background_color !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-menu-holder', array(
				'background-color' => 'rgba(' . $fullscreen_menu_background_color[0] . ',' . $fullscreen_menu_background_color[1] . ',' . $fullscreen_menu_background_color[2] . ',' . $fullscreen_menu_background_transparency . ')'
			));
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_background_image') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-menu-holder', array(
				'background-image' => 'url(' . rouhi_zenith_options()->getOptionValue('fullscreen_menu_background_image') . ')',
				'background-position' => 'center 0',
				'background-repeat' => 'no-repeat'
			));
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_pattern_image') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-menu-holder', array(
				'background-image' => 'url(' . rouhi_zenith_options()->getOptionValue('fullscreen_menu_pattern_image') . ')',
				'background-repeat' => 'repeat',
				'background-position' => '0 0'
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_fullscreen_menu_general_styles');

}

if (!function_exists('rouhi_zenith_fullscreen_menu_first_level_style')) {

	function rouhi_zenith_fullscreen_menu_first_level_style()
	{

		$first_menu_style = array();

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_color') !== '') {
			$first_menu_style['color'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_color');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_google_fonts') !== '-1') {
			$first_menu_style['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('fullscreen_menu_google_fonts')) . ',sans-serif';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontsize') !== '') {
			$first_menu_style['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontsize')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_lineheight') !== '') {
			$first_menu_style['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_lineheight')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontstyle') !== '') {
			$first_menu_style['font-style'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontstyle');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontweight') !== '') {
			$first_menu_style['font-weight'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontweight');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_letterspacing') !== '') {
			$first_menu_style['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_letterspacing')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_texttransform') !== '') {
			$first_menu_style['text-transform'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_texttransform');
		}

		if (!empty($first_menu_style)) {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu > ul > li > a, nav.zen-fullscreen-menu > ul > li > h6', $first_menu_style);
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_color') !== '') {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li a span.bottom_line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_color')
			));
		}

		$first_menu_hover_style = array();

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_hover_color') !== '') {
			$first_menu_hover_style['color'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_hover_color');
		}

		if (!empty($first_menu_hover_style)) {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu > ul > li > a:hover, nav.zen-fullscreen-menu > ul > li > h6:hover', $first_menu_hover_style);

            echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li a:hover span.bottom_line', array(
                'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_hover_color')
            ));
		}

		$first_menu_active_style = array();

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_active_color') !== '') {
			$first_menu_active_style['color'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_active_color');

            echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li a.current span.bottom_line', array(
                'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_active_color')
            ));
		}

		if (!empty($first_menu_active_style)) {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu > ul > li > a.current', $first_menu_active_style);
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_fullscreen_menu_first_level_style');

}

if (!function_exists('rouhi_zenith_fullscreen_menu_second_level_style')) {

	function rouhi_zenith_fullscreen_menu_second_level_style()
	{
		$second_menu_style = array();
		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_color_2nd') !== '') {
			$second_menu_style['color'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_color_2nd');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_google_fonts_2nd') !== '-1') {
			$second_menu_style['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('fullscreen_menu_google_fonts_2nd')) . ',sans-serif';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontsize_2nd') !== '') {
			$second_menu_style['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontsize_2nd')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_lineheight_2nd') !== '') {
			$second_menu_style['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_lineheight_2nd')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontstyle_2nd') !== '') {
			$second_menu_style['font-style'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontstyle_2nd');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontweight_2nd') !== '') {
			$second_menu_style['font-weight'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontweight_2nd');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_letterspacing_2nd') !== '') {
			$second_menu_style['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_letterspacing_2nd')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_texttransform_2nd') !== '') {
			$second_menu_style['text-transform'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_texttransform_2nd');
		}

		if (!empty($second_menu_style)) {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li ul li a, nav.zen-fullscreen-menu ul li ul li h6', $second_menu_style);
		}

		$second_menu_hover_style = array();

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_hover_color_2nd') !== '') {
			$second_menu_hover_style['color'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_hover_color_2nd');
		}

		if (!empty($second_menu_hover_style)) {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li ul li a:hover, nav.zen-fullscreen-menu ul li ul li h6:hover', $second_menu_hover_style);
		}
	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_fullscreen_menu_second_level_style');

}

if (!function_exists('rouhi_zenith_fullscreen_menu_third_level_style')) {

	function rouhi_zenith_fullscreen_menu_third_level_style()
	{
		$third_menu_style = array();
		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_color_3rd') !== '') {
			$third_menu_style['color'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_color_3rd');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_google_fonts_3rd') !== '-1') {
			$third_menu_style['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('fullscreen_menu_google_fonts_3rd')) . ',sans-serif';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontsize_3rd') !== '') {
			$third_menu_style['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontsize_3rd')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_lineheight_3rd') !== '') {
			$third_menu_style['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_lineheight_3rd')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontstyle_3rd') !== '') {
			$third_menu_style['font-style'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontstyle_3rd');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontweight_3rd') !== '') {
			$third_menu_style['font-weight'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_fontweight_3rd');
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_letterspacing_3rd') !== '') {
			$third_menu_style['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_letterspacing_3rd')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_texttransform_3rd') !== '') {
			$third_menu_style['text-transform'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_texttransform_3rd');
		}

		if (!empty($third_menu_style)) {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li ul li ul li a', $third_menu_style);
		}

		$third_menu_hover_style = array();

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_hover_color_3rd') !== '') {
			$third_menu_hover_style['color'] = rouhi_zenith_options()->getOptionValue('fullscreen_menu_hover_color_3rd');
		}

		if (!empty($third_menu_hover_style)) {
			echo rouhi_zenith_dynamic_css('nav.zen-fullscreen-menu ul li ul li ul li a:hover', $third_menu_hover_style);
		}
	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_fullscreen_menu_third_level_style');

}

if (!function_exists('rouhi_zenith_fullscreen_menu_icon_styles')) {

	function rouhi_zenith_fullscreen_menu_icon_styles()
	{

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_color') !== '') {

			echo rouhi_zenith_dynamic_css('.zen-fullscreen-menu-opener .zen-line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_color')
			));

		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_hover_color') !== '') {

			echo rouhi_zenith_dynamic_css('.zen-fullscreen-menu-opener:hover .zen-line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_hover_color')
			));

		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_light_icon_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-light-header .zen-page-header > div:not(.zen-sticky-header) .zen-fullscreen-menu-opener:not(.opened) .zen-line,
			.zen-light-header.zen-header-style-on-scroll .zen-page-header .zen-fullscreen-menu-opener:not(.opened) .zen-line,
			.zen-light-header .zen-top-bar .zen-fullscreen-menu-opener:not(.opened) .zen-line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_light_icon_color') . ' !important'
			));

		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_light_icon_hover_color') !== '') {

			echo rouhi_zenith_dynamic_css('.zen-light-header .zen-page-header > div:not(.zen-sticky-header) .zen-fullscreen-menu-opener:not(.opened):hover .zen-line,
			.zen-light-header.zen-header-style-on-scroll .zen-page-header .zen-fullscreen-menu-opener:not(.opened):hover .zen-line,
			.zen-light-header .zen-top-bar .zen-fullscreen-menu-opener:not(.opened):hover .zen-line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_light_icon_hover_color') . ' !important'
			));

		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_dark_icon_color') !== '') {

			echo rouhi_zenith_dynamic_css('.zen-dark-header .zen-page-header > div:not(.zen-sticky-header) .zen-fullscreen-menu-opener:not(.opened) .zen-line,
			.zen-dark-header.zen-header-style-on-scroll .zen-page-header .zen-fullscreen-menu-opener:not(.opened) .zen-line,
			.zen-dark-header .zen-top-bar .zen-fullscreen-menu-opener:not(.opened) .zen-line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_dark_icon_color') . ' !important'
			));

		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_dark_icon_hover_color') !== '') {

			echo rouhi_zenith_dynamic_css('.zen-dark-header .zen-page-header > div:not(.zen-sticky-header) .zen-fullscreen-menu-opener:not(.opened):hover .zen-line,
			.zen-dark-header.zen-header-style-on-scroll .zen-page-header .zen-fullscreen-menu-opener:not(.opened):hover .zen-line,
			.zen-dark-header .zen-top-bar .zen-fullscreen-menu-opener:not(.opened):hover .zen-line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('fullscreen_menu_dark_icon_hover_color') . ' !important'
			));

		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_fullscreen_menu_icon_styles');

}

if (!function_exists('rouhi_zenith_fullscreen_menu_icon_spacing')) {

	function rouhi_zenith_fullscreen_menu_icon_spacing()
	{

		$fullscreen_menu_icon_spacing = array();

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_padding_left') !== '') {
			$fullscreen_menu_icon_spacing['padding-left'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_padding_left')) . 'px';
		}

		if (rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_padding_right') !== '') {
			$fullscreen_menu_icon_spacing['padding-right'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('fullscreen_menu_icon_padding_right')) . 'px';
		}

		if (!empty($fullscreen_menu_icon_spacing)) {
			echo rouhi_zenith_dynamic_css('a.zen-fullscreen-menu-opener', $fullscreen_menu_icon_spacing);
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_fullscreen_menu_icon_spacing');

}