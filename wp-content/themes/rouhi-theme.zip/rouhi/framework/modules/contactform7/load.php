<?php

if (rouhi_zenith_contact_form_7_installed()) {
	include_once zenith_framework_modules_root_dir.'/contactform7/options-map/map.php';
	include_once zenith_framework_modules_root_dir.'/contactform7/custom-styles/contact-form.php';
	include_once zenith_framework_modules_root_dir.'/contactform7/contact-form-7-config.php';
}