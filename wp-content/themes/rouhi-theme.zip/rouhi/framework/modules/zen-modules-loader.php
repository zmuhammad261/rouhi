<?php

if(!function_exists('rouhi_zenith_load_modules')) {
    /**
     * Loades all modules by going through all folders that are placed directly in modules folder
     * and loads load.php file in each. Hooks to rouhi_zenith_after_options_map action
     *
     * @see http://php.net/manual/en/function.glob.php
     */
    function rouhi_zenith_load_modules() {
        foreach(glob(zenith_framework_root_dir.'/modules/*/load.php') as $module_load) {
            include_once $module_load;
        }
    }

    add_action('rouhi_zenith_before_options_map', 'rouhi_zenith_load_modules');
}

if(!function_exists('rouhi_zenith_load_shortcode_interface')) {

    function rouhi_zenith_load_shortcode_interface() {

        include_once zenith_framework_modules_root_dir.'/shortcodes/lib/shortcode-interface.php';

    }

    add_action('rouhi_zenith_before_options_map', 'rouhi_zenith_load_shortcode_interface');

}

if(!function_exists('rouhi_zenith_load_shortcodes')) {
    /**
     * Loades all shortcodes by going through all folders that are placed directly in shortcodes folder
     * and loads load.php file in each. Hooks to rouhi_zenith_after_options_map action
     *
     * @see http://php.net/manual/en/function.glob.php
     */
    function rouhi_zenith_load_shortcodes() {
        foreach(glob(zenith_framework_root_dir.'/modules/shortcodes/*/load.php') as $shortcode_load) {
            include_once $shortcode_load;
        }

        include_once zenith_framework_modules_root_dir.'/shortcodes/lib/shortcode-loader.inc';
    }

    add_action('rouhi_zenith_before_options_map', 'rouhi_zenith_load_shortcodes');
}

if(!function_exists('rouhi_zenith_load_widget_class')) {
	 /**
     * Loades widget class file. 
     *
     */
	function rouhi_zenith_load_widget_class(){
		include_once zenith_framework_modules_root_dir.'/widgets/lib/widget-class.php';
	} 
	
	add_action('rouhi_zenith_before_options_map', 'rouhi_zenith_load_widget_class');
}

if(!function_exists('rouhi_zenith_load_widgets')) {
    /**
     * Loades all widgets by going through all folders that are placed directly in widgets folder
     * and loads load.php file in each. Hooks to rouhi_zenith_after_options_map action
     */
    function rouhi_zenith_load_widgets() {
		
        foreach(glob(zenith_framework_root_dir.'/modules/widgets/*/load.php') as $widget_load) {
            include_once $widget_load;
        }

        include_once zenith_framework_modules_root_dir.'/widgets/lib/widget-loader.php';
    }

    add_action('rouhi_zenith_before_options_map', 'rouhi_zenith_load_widgets');
}