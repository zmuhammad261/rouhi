<?php

if ( ! function_exists('rouhi_zenith_pricing_table_options_map') ) {
	/**
	 * Add Pricing Table options to elements page
	 */
	function rouhi_zenith_pricing_table_options_map() {

		$panel_pricing_table = rouhi_zenith_add_admin_panel(
			array(
				'page' => '_elements_page',
				'name' => 'panel_pricing_table',
				'title' => 'Pricing Table'
			)
		);

	}

	add_action( 'rouhi_zenith_options_elements_map', 'rouhi_zenith_pricing_table_options_map');

}