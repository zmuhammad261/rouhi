<div <?php rouhi_zenith_class_attribute($pricing_table_classes)?>>
	<div class="zen-price-table-inner">
		<?php if($active == 'yes'){ ?>
			<div class="zen-active-text">
				<h3 class="zen-active-text-inner">
					<?php echo esc_attr($active_text) ?>
				</h3>
				<?php echo rouhi_zenith_execute_shortcode('zen_separator',array(
						'type' => 'full-width',
						'position' => 'center',
						'color_dot' => 'black',
						'border_style' => 'dotted_multiple',
						'thickness' => '3',
						'top_margin' => '10px',
						'bottom_margin' => '10px',
				)); ?>
			</div>
		<?php } ?>
		<div class="zen-table-prices">
			<div class="zen-price-in-table">
				<span class="zen-price"><?php echo esc_attr($price)?></span>
				<sup class="zen-value"><?php echo esc_attr($currency) ?></sup>
				<h6 class="zen-mark"><?php echo esc_attr($price_period)?></h6>
			</div>	
		</div>
		<ul>
			<li class="zen-table-title">
				<h5 class="zen-subtitle-content"><?php echo esc_html($subtitle) ?></h5>
				<h3 class="zen-title-content"><?php echo esc_html($title) ?></h3>
			</li>
			<li class="zen-table-info">
				<p><?php echo esc_html($info) ?></p>
			</li>
			<li class="zen-table-content">
				<?php echo rouhi_zenith_remove_wpautop($content, true)?>
			</li>
			<?php 
			if($show_button == "yes" && $button_text !== ''){ ?>
				<li class="zen-price-button">
					<?php echo rouhi_zenith_get_button_html(array(
						'link' => $link,
						'text' => $button_text,
						'type' => 'arrow',
						'arrow_alignment' => 'left'
					)); ?>
				</li>				
			<?php } ?>
		</ul>
	</div>
	<?php if ($btm_text !== '') {?>
	<div class="zen-table-btm">
		<span class="zen-table-icon icon-basic-lightbulb"></span>
		<h6><?php echo esc_html($btm_text) ?></h6>
	</div>
	<?php } ?>
</div>
