<?php
namespace Rouhi\Modules\PricingTables;

use Rouhi\Modules\Shortcodes\Lib\ShortcodeInterface;

class PricingTables implements ShortcodeInterface{
	private $base;
	function __construct() {
		$this->base = 'zen_pricing_tables';
		add_action('vc_before_init', array($this, 'vcMap'));
	}
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {

		vc_map( array(
				'name' => 'Pricing Tables',
				'base' => $this->base,
				'as_parent' => array('only' => 'zen_pricing_table'),
				'content_element' => true,
				'category' => 'ROUHI ELEMENTS',
				'icon' => 'icon-wpb-pricing-tables extended-custom-icon',
				'show_settings_on_create' => true,
				'params' => array(
					array(
						'type' => 'dropdown',
						'holder' => 'div',
						'class' => '',
						'heading' => 'Columns',
						'param_name' => 'columns',
						'value' => array(
							'Two'       => 'zen-two-columns',
							'Three'     => 'zen-three-columns',
							'Four'      => 'zen-four-columns',
						),
						'save_always' => true,
						'description' => ''
					)
				),
				'js_view' => 'VcColumnView'
		) );

	}

	public function render($atts, $content = null) {
		$args = array(
			'columns'         => 'zen-two-columns'
		);
		
		$params = shortcode_atts($args, $atts);
		extract($params);
		
		$html = '<div class="zen-pricing-tables clearfix '.$columns.'">';
		$html .= rouhi_zenith_remove_wpautop($content);
		$html .= '</div>';

		return $html;
	}

}
