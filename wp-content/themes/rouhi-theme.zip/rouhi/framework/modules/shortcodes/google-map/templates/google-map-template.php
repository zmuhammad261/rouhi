<div class="zen-google-map-holder">
	<div class="zen-google-map" id="<?php echo esc_attr($map_id); ?>" <?php print $map_data; ?>></div>
	<?php if ($scroll_wheel == "false") { ?>
		<div class="zen-google-map-overlay"></div>
	<?php } ?>
</div>
