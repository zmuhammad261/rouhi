<div class="zen-pie-chart-with-icon-holder">
	<div class="zen-percentage-with-icon" <?php echo rouhi_zenith_get_inline_attrs($pie_chart_data); ?>>
		<?php print $icon; ?>
	</div>
	<div class="zen-pie-chart-text" <?php rouhi_zenith_inline_style($pie_chart_style)?>>
		<?php if ($subtitle !== ''){ ?>
		<h5><?php echo esc_html($subtitle); ?></h5>
		<?php } ?>
		<<?php echo esc_html($title_tag)?> class="zen-pie-title">
			<?php echo esc_html($title); ?>
		</<?php echo esc_html($title_tag)?>>
		<p><?php echo esc_html($text); ?></p>
	</div>
</div>