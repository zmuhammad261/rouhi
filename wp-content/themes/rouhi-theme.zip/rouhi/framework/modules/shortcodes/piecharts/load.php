<?php

//Pie Chart Basic
include_once zenith_framework_modules_root_dir.'/shortcodes/piecharts/piechartbasic/load.php';

//Pie Chart Basic With Icon
include_once zenith_framework_modules_root_dir.'/shortcodes/piecharts/piechartwithicon/load.php';
