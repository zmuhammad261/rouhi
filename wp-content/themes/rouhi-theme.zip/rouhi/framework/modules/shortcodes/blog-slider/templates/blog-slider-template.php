<div class="zen-blog-slider-holder">
	<div class="zen-blog-slider">
	<?php 
	$html = '';
		if($query_result->have_posts()):
		while ($query_result->have_posts()) : $query_result->the_post();
			$html .= rouhi_zenith_get_shortcode_module_template_part('templates/blog-slider-item', 'blog-slider', '', $params);
		endwhile;
		print $html;
		else: ?>
		<div class="zen-blog-slider-messsage">
			<p><?php esc_html_e('No posts were found.', 'rouhi'); ?></p>
		</div>
		<?php endif;
		wp_reset_postdata();
	?>
	</div>	
</div>