<div class="zen-blog-slider-item" style="background-image: url(<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>);">
	<div class="zen-blog-slider-item-inner">
		<div class="zen-item-text-holder">
			<div class="zen-item-info-section">
				<?php rouhi_zenith_post_info(array(
					'category' => 'yes',
				)) ?>
			</div>
			<<?php echo esc_html( $title_tag)?> class="zen-item-title">
				<a href="<?php echo esc_url(get_permalink()) ?>" >
					<?php echo esc_attr(get_the_title()) ?>
				</a>
			</<?php echo esc_html($title_tag) ?>>
			<?php echo rouhi_zenith_execute_shortcode('zen_separator',array(
					'type' => 'normal',
					'position' => 'center',
					'color_dot' => 'black',
					'border_style' => 'dotted_multiple',
					'thickness' => '3',
					'width' => '25%',
					'top_margin' => '25px',
					'bottom_margin' => '20px',
			)); ?>
			<?php if ($text_length != '0') {
				$excerpt = ($text_length > 0) ? substr(get_the_excerpt(), 0, intval($text_length)) : get_the_excerpt(); ?>
				<p class="zen-excerpt"><?php echo esc_html($excerpt)?></p>
			<?php } ?>
		</div>
		<div class="zen-item-bottom-holder">
			<div class="zen-item-btm-left-holder">
				<div class="zen-item-author-image">
					<?php echo rouhi_zenith_kses_img(get_avatar(get_the_author_meta( 'ID' ), 30)); ?>
				</div>
				<?php rouhi_zenith_post_info(array(
					'author' => 'yes',
				)) ?>
			</div>
			<div class="zen-item-btn-right-holder">
				<?php echo rouhi_zenith_execute_shortcode('zen_button',array(
					'type' => 'arrow',
					'text' => 'More',
					'link' => esc_url(get_permalink())
				));?>
			</div>
		</div>
	</div>	
</div>