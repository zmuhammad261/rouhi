<div class="zen-tabs <?php echo esc_attr($tab_class) ?> clearfix">
	<ul class="zen-tabs-nav">
		<?php  foreach ($tabs_titles as $tab_title) {?>
			<li>
				<a href="#tab-<?php echo sanitize_title($tab_title)?>">					
					<span class="zen-icon-frame"></span>
					<span class="zen-tab-text-after-icon">
						<?php echo esc_attr($tab_title)?>
					</span>
				</a>
			 </li>
		<?php } ?>
	</ul> 
	<?php echo rouhi_zenith_remove_wpautop($content) ?>
</div>
