<?php
if(!function_exists('rouhi_zenith_tabs_typography_styles')){
	function rouhi_zenith_tabs_typography_styles(){
		$selector = '.zen-tabs .zen-tabs-nav li a';
		$tabs_tipography_array = array();
		$font_family = rouhi_zenith_options()->getOptionValue('tabs_font_family');
		
		if(rouhi_zenith_is_font_option_valid($font_family)){
			$tabs_tipography_array['font-family'] = rouhi_zenith_is_font_option_valid($font_family);
		}
		
		$text_transform = rouhi_zenith_options()->getOptionValue('tabs_text_transform');
        if(!empty($text_transform)) {
            $tabs_tipography_array['text-transform'] = $text_transform;
        }

        $font_style = rouhi_zenith_options()->getOptionValue('tabs_font_style');
        if(!empty($font_style)) {
            $tabs_tipography_array['font-style'] = $font_style;
        }

        $letter_spacing = rouhi_zenith_options()->getOptionValue('tabs_letter_spacing');
        if($letter_spacing !== '') {
            $tabs_tipography_array['letter-spacing'] = rouhi_zenith_filter_px($letter_spacing).'px';
        }

        $font_weight = rouhi_zenith_options()->getOptionValue('tabs_font_weight');
        if(!empty($font_weight)) {
            $tabs_tipography_array['font-weight'] = $font_weight;
        }

        echo rouhi_zenith_dynamic_css($selector, $tabs_tipography_array);
	}
	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_tabs_typography_styles');
}

if(!function_exists('rouhi_zenith_tabs_inital_color_styles')){
	function rouhi_zenith_tabs_inital_color_styles(){
		$selector = '.zen-tabs .zen-tabs-nav li a';
		$styles = array();
		
		if(rouhi_zenith_options()->getOptionValue('tabs_color')) {
            $styles['color'] = rouhi_zenith_options()->getOptionValue('tabs_color');
        }
		
		echo rouhi_zenith_dynamic_css($selector, $styles);
	}
	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_tabs_inital_color_styles');
}
if(!function_exists('rouhi_zenith_tabs_active_color_styles')){
	function rouhi_zenith_tabs_active_color_styles(){
		$selector = '.zen-tabs .zen-tabs-nav li.ui-state-active a, .zen-tabs .zen-tabs-nav li.ui-state-hover a';
		$styles = array();
		
		if(rouhi_zenith_options()->getOptionValue('tabs_color_active')) {
            $styles['color'] = rouhi_zenith_options()->getOptionValue('tabs_color_active');
        }
		
		echo rouhi_zenith_dynamic_css($selector, $styles);
	}
	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_tabs_active_color_styles');
}