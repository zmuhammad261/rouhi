<?php
require_once zenith_framework_modules_root_dir.'/shortcodes/tabs/tabs.php';
require_once zenith_framework_modules_root_dir.'/shortcodes/tabs/tab.php';
require_once zenith_framework_modules_root_dir.'/shortcodes/tabs/custom-styles/custom-styles.php';
require_once zenith_framework_modules_root_dir.'/shortcodes/tabs/options-map/map.php';
