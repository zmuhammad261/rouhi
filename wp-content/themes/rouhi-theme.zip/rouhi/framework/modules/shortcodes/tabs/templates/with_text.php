<div class="zen-tabs <?php echo esc_attr($tab_class) ?> clearfix">
	<ul class="zen-tabs-nav">
		<?php  foreach ($tabs_titles as $tab_title) {?>
			<li>
				<a href="#tab-<?php echo sanitize_title($tab_title)?>">
					<span class="zen-tabs-arrow icon-arrows-right"></span>
					<span class="zen-tabs-text"><?php echo esc_attr($tab_title)?></span>
				</a>
			</li>
		<?php } ?>
	</ul> 
	<?php echo rouhi_zenith_remove_wpautop($content) ?>
</div>

