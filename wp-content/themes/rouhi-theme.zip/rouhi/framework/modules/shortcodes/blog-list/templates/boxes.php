<li class="zen-blog-list-item clearfix">
	<div class="zen-blog-list-item-inner">
		<?php if ($hide_image == "no") { ?>
		<div class="zen-item-image">
				<?php
					if (rouhi_zenith_get_post_format_class() !== 'gallery'){ ?>
					<a href="<?php echo esc_url(get_permalink()); ?>" target="_blank">
						<?php echo get_the_post_thumbnail(get_the_ID(), $thumb_image_size); ?>
					</a>
				<?php
					}
				else{
					rouhi_zenith_get_module_template_part('parts/gallery', 'shortcodes/blog-list','',array('thumb_image_size' => $thumb_image_size));
				}
				?>
		</div>
		<?php } ?>
		<div class="zen-item-text-holder">
			<div class="zen-post-mark zen-post-<?php echo rouhi_zenith_get_post_format_class();?>">
				<span class="<?php echo rouhi_zenith_get_post_format_icon_class();?>"></span>
			</div>
			<div class="zen-item-info-section">
				<?php rouhi_zenith_post_info(array('category' => 'yes', 'date' => 'no', 'comments' => 'no', 'share' => 'no', 'like' => 'no')) ?>
			</div>
			<<?php echo esc_html( $title_tag)?> class="zen-item-title">
				<a href="<?php echo esc_url(get_permalink()) ?>" >
					<?php echo esc_attr(get_the_title()) ?>
				</a>
			</<?php echo esc_html($title_tag) ?>>
			<?php if ($text_length != '0') {
				$excerpt = ($text_length > 0) ? substr(get_the_excerpt(), 0, intval($text_length)) : get_the_excerpt(); ?>
				<p class="zen-excerpt"><?php echo esc_html($excerpt)?>...</p>
			<?php } ?>
		</div>
		<div class="zen-item-bottom-holder">
			<div class="zen-item-bottom-holder-inner">
				<div class="zen-item-btm-left-holder">
					<div class="zen-item-author-image">
						<?php echo rouhi_zenith_kses_img(get_avatar(get_the_author_meta( 'ID' ), 30)); ?>
					</div>
					<?php rouhi_zenith_post_info(array(
						'author' => 'yes',
					)) ?>
				</div>
				<div class="zen-item-btn-right-holder">
					<?php echo rouhi_zenith_execute_shortcode('zen_button',array(
						'type' => 'arrow',
						'text' => 'More',
						'arrow_alignment' => 'right',
						'link' => esc_url(get_permalink())
					));?>
				</div>
			</div>
		</div>
	</div>
</li>