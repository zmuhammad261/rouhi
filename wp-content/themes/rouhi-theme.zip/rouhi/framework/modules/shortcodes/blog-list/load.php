<?php

include_once zenith_framework_modules_root_dir.'/shortcodes/blog-list/blog-list.php';
include_once zenith_framework_modules_root_dir.'/shortcodes/blog-list/custom-styles/blog-list.php';