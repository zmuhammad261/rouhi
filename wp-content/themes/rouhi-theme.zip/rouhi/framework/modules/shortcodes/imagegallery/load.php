<?php

include_once zenith_framework_modules_root_dir.'/shortcodes/imagegallery/image-gallery.php';