<?php
/**
 * Counter shortcode template
 */
?>
<div class="zen-counter-holder <?php echo esc_attr($position); ?>" <?php echo rouhi_zenith_get_inline_style($counter_holder_styles); ?>>

	<span class="zen-counter <?php echo esc_attr($type) ?>" <?php echo rouhi_zenith_get_inline_style($counter_styles); ?>>
		<?php echo esc_attr($digit); ?>
	</span>
	<<?php echo esc_html($title_tag); ?> class="zen-counter-title" <?php echo rouhi_zenith_get_inline_style($title_style); ?>>
		<?php echo esc_attr($title); ?>
	</<?php echo esc_html($title_tag);; ?>>
	<?php if ($text != "") { ?>
		<p class="zen-counter-text"><?php echo esc_html($text); ?></p>
	<?php } ?>

</div>