<?php
require_once zenith_framework_modules_root_dir.'/shortcodes/info-table/info-table.php';
require_once zenith_framework_modules_root_dir.'/shortcodes/info-table/info-table-row.php';
