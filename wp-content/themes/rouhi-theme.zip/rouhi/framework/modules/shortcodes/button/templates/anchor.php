<a href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>" <?php rouhi_zenith_inline_style($button_styles); ?> <?php rouhi_zenith_class_attribute($button_classes); ?> <?php echo rouhi_zenith_get_inline_attrs($button_data); ?> <?php echo rouhi_zenith_get_inline_attrs($button_custom_attrs); ?>>
    <span class="zen-btn-text"><?php echo esc_html($text); ?></span>
    <?php
    if ($type !== 'arrow'){
    	echo rouhi_zenith_icon_collections()->renderIcon($icon, $icon_pack);
	}else{ ?>

	<span class="zen-btn-icon-arrow">
		<span <?php rouhi_zenith_inline_style($arrow_styles); ?> class="zen-line-1"></span>
		<span <?php rouhi_zenith_inline_style($arrow_styles); ?> class="zen-line-2"></span>
		<span <?php rouhi_zenith_inline_style($arrow_styles); ?> class="zen-line-3"></span>
	</span>
	<?php }  ?>
</a>