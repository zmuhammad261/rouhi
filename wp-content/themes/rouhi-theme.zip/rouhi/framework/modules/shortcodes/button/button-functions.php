<?php

if(!function_exists('rouhi_zenith_get_button_html')) {
    /**
     * Calls button shortcode with given parameters and returns it's output
     * @param $params
     *
     * @return mixed|string
     */
    function rouhi_zenith_get_button_html($params) {
        $button_html = rouhi_zenith_execute_shortcode('zen_button', $params);
        $button_html = str_replace("\n", '', $button_html);
        return $button_html;
    }
}