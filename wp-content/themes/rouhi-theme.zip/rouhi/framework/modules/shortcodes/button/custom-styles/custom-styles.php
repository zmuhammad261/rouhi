<?php

if(!function_exists('rouhi_zenith_button_typography_styles')) {
    /**
     * Typography styles for all button types
     */
    function rouhi_zenith_button_typography_styles() {
        $selector = '.zen-btn';
        $styles = array();

        $font_family = rouhi_zenith_options()->getOptionValue('button_font_family');
        if(rouhi_zenith_is_font_option_valid($font_family)) {
            $styles['font-family'] = rouhi_zenith_get_font_option_val($font_family);
        }

        $text_transform = rouhi_zenith_options()->getOptionValue('button_text_transform');
        if(!empty($text_transform)) {
            $styles['text-transform'] = $text_transform;
        }

        $font_style = rouhi_zenith_options()->getOptionValue('button_font_style');
        if(!empty($font_style)) {
            $styles['font-style'] = $font_style;
        }

        $letter_spacing = rouhi_zenith_options()->getOptionValue('button_letter_spacing');
        if($letter_spacing !== '') {
            $styles['letter-spacing'] = rouhi_zenith_filter_px($letter_spacing).'px';
        }

        $font_weight = rouhi_zenith_options()->getOptionValue('button_font_weight');
        if(!empty($font_weight)) {
            $styles['font-weight'] = $font_weight;
        }

        echo rouhi_zenith_dynamic_css($selector, $styles);
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_button_typography_styles');
}

if(!function_exists('rouhi_zenith_button_outline_styles')) {
    /**
     * Generate styles for outline button
     */
    function rouhi_zenith_button_outline_styles() {
        //outline styles
        $outline_styles   = array();
        $outline_selector = '.zen-btn.zen-btn-outline';

        if(rouhi_zenith_options()->getOptionValue('btn_outline_text_color')) {
            $outline_styles['color'] = rouhi_zenith_options()->getOptionValue('btn_outline_text_color');
        }

        if(rouhi_zenith_options()->getOptionValue('btn_outline_border_color')) {
            $outline_styles['border-color'] = rouhi_zenith_options()->getOptionValue('btn_outline_border_color');
        }

        echo rouhi_zenith_dynamic_css($outline_selector, $outline_styles);

        //outline hover styles
        if(rouhi_zenith_options()->getOptionValue('btn_outline_hover_text_color')) {
            echo rouhi_zenith_dynamic_css(
                '.zen-btn.zen-btn-outline:not(.zen-btn-custom-hover-color):hover',
                array('color' => rouhi_zenith_options()->getOptionValue('btn_outline_hover_text_color').'!important')
            );
        }

        if(rouhi_zenith_options()->getOptionValue('btn_outline_hover_bg_color')) {
            echo rouhi_zenith_dynamic_css(
                '.zen-btn.zen-btn-outline:not(.zen-btn-custom-hover-bg):hover',
                array('background-color' => rouhi_zenith_options()->getOptionValue('btn_outline_hover_bg_color').'!important')
            );
        }

        if(rouhi_zenith_options()->getOptionValue('btn_outline_hover_border_color')) {
            echo rouhi_zenith_dynamic_css(
                '.zen-btn.zen-btn-outline:not(.zen-btn-custom-border-hover):hover',
                array('border-color' => rouhi_zenith_options()->getOptionValue('btn_outline_hover_border_color').'!important')
            );
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_button_outline_styles');
}

if(!function_exists('rouhi_zenith_button_arrow_styles')) {
    /**
     * Generate styles for arrow button
     */
    function rouhi_zenith_button_arrow_styles() {
        //arrow styles
        $arrow_styles   = array();
        $arrow_selector = '.zen-btn.zen-btn-arrow';
        $arrow_icon_styles   = array();
        $arrow_icon_selector = '.zen-btn.zen-btn-arrow .zen-btn-icon-arrow .zen-line-1,
                                .zen-btn.zen-btn-arrow .zen-btn-icon-arrow .zen-line-2,
                                .zen-btn.zen-btn-arrow .zen-btn-icon-arrow .zen-line-3';

        if(rouhi_zenith_options()->getOptionValue('btn_arrow_color')) {
            $arrow_styles['color'] = rouhi_zenith_options()->getOptionValue('btn_arrow_color');
            $arrow_icon_styles['border-bottom-color'] = rouhi_zenith_options()->getOptionValue('btn_arrow_color');
        }

        echo rouhi_zenith_dynamic_css($arrow_selector, $arrow_styles);
        echo rouhi_zenith_dynamic_css($arrow_icon_selector, $arrow_icon_styles);

    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_button_arrow_styles');
}

if(!function_exists('rouhi_zenith_button_solid_styles')) {
    /**
     * Generate styles for solid type buttons
     */
    function rouhi_zenith_button_solid_styles() {
        //solid styles
        $solid_selector = '.zen-btn.zen-btn-solid';
        $solid_styles = array();

        if(rouhi_zenith_options()->getOptionValue('btn_solid_text_color')) {
            $solid_styles['color'] = rouhi_zenith_options()->getOptionValue('btn_solid_text_color');
        }

        if(rouhi_zenith_options()->getOptionValue('btn_solid_border_color')) {
            $solid_styles['border-color'] = rouhi_zenith_options()->getOptionValue('btn_solid_border_color');
        }

        if(rouhi_zenith_options()->getOptionValue('btn_solid_bg_color')) {
            $solid_styles['background-color'] = rouhi_zenith_options()->getOptionValue('btn_solid_bg_color');
        }

        echo rouhi_zenith_dynamic_css($solid_selector, $solid_styles);

        //solid hover styles
        if(rouhi_zenith_options()->getOptionValue('btn_solid_hover_text_color')) {
            echo rouhi_zenith_dynamic_css(
                '.zen-btn.zen-btn-solid:not(.zen-btn-custom-hover-color):hover',
                array('color' => rouhi_zenith_options()->getOptionValue('btn_solid_hover_text_color').'!important')
            );
        }

        if(rouhi_zenith_options()->getOptionValue('btn_solid_hover_bg_color')) {
            echo rouhi_zenith_dynamic_css(
                '.zen-btn.zen-btn-solid:not(.zen-btn-custom-hover-bg):hover',
                array('background-color' => rouhi_zenith_options()->getOptionValue('btn_solid_hover_bg_color').'!important')
            );
        }

        if(rouhi_zenith_options()->getOptionValue('btn_solid_hover_border_color')) {
            echo rouhi_zenith_dynamic_css(
                '.zen-btn.zen-btn-solid:not(.zen-btn-custom-hover-bg):hover',
                array('border-color' => rouhi_zenith_options()->getOptionValue('btn_solid_hover_border_color').'!important')
            );
        }
    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_button_solid_styles');
}