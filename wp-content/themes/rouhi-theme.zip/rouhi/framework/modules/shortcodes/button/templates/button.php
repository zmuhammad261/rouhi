<button type="submit" <?php rouhi_zenith_inline_style($button_styles); ?> <?php rouhi_zenith_class_attribute($button_classes); ?> <?php echo rouhi_zenith_get_inline_attrs($button_data); ?> <?php echo rouhi_zenith_get_inline_attrs($button_custom_attrs); ?>>
    <span class="zen-btn-text"><?php echo esc_html($text); ?></span>
    <?php echo rouhi_zenith_icon_collections()->renderIcon($icon, $icon_pack); ?>
</button>