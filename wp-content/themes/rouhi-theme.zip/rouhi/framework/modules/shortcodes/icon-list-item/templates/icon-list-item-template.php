<?php
$icon_html = rouhi_zenith_icon_collections()->renderIcon($icon, $icon_pack, $params);
?>
<div class="zen-icon-list-item">
	<div class="zen-icon-list-icon-holder">
        <div class="zen-icon-list-icon-holder-inner clearfix">
			<?php 
			print $icon_html;
			?>
		</div>
	</div>
	<p class="zen-icon-list-text" <?php echo rouhi_zenith_get_inline_style($title_style)?> > <?php echo esc_attr($title)?></p>
</div>