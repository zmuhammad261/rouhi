<div class="zen-accordion-holder clearfix <?php echo esc_attr($acc_class)?> ">
	<?php echo rouhi_zenith_remove_wpautop($content)?>
</div>