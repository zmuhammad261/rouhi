<<?php echo esc_attr($title_tag)?> class="clearfix zen-title-holder">
	<span class="zen-tab-title">
		<span class="zen-tab-title-inner">
			<?php echo esc_attr($title)?>
		</span>
	</span>
	<span class="zen-accordion-mark">
		<span class="zen-accordion-mark-icon">
			<span class="icon-arrows-plus"></span>
			<span class="icon-arrows-minus"></span>
		</span>
	</span>
</<?php echo esc_attr($title_tag)?>>
<div class="zen-accordion-content">
	<div class="zen-accordion-content-inner">
		<?php echo rouhi_zenith_remove_wpautop($content)?>
	</div>
</div>
