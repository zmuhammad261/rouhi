<?php

include_once zenith_framework_modules_root_dir.'/shortcodes/blockquote/options-map/map.php';
include_once zenith_framework_modules_root_dir.'/shortcodes/blockquote/blockquote.php';
include_once zenith_framework_modules_root_dir.'/shortcodes/blockquote/custom-styles/blockquote.php';