<?php
/**
 * Blockquote shortcode template
 */
?>

<blockquote class="rouhi-blockquote-shortcode" <?php rouhi_zenith_inline_style($blockquote_style); ?> >
	<span class="rouhi-icon-quotations-holder">
		<?php echo rouhi_zenith_icon_collections()->getQuoteIcon("linea_icons", true); ?>
	</span>
	<<?php echo esc_attr($blockquote_title_tag); ?> class="rouhi-blockquote-text">
	<span><?php echo esc_attr($text); ?></span>
	</<?php echo esc_attr($blockquote_title_tag);?>>
</blockquote>