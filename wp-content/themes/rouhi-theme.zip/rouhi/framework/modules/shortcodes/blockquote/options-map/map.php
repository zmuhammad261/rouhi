<?php

if ( ! function_exists('rouhi_zenith_blockquote_options_map') ) {
	/**
	 * Add Blockquote options to elements page
	 */
	function rouhi_zenith_blockquote_options_map() {

		$panel_blockquote = rouhi_zenith_add_admin_panel(
			array(
				'page' => '_elements_page',
				'name' => 'panel_blockquote',
				'title' => 'Blockquote'
			)
		);

	}

	add_action( 'rouhi_zenith_options_elements_map', 'rouhi_zenith_blockquote_options_map');

}