<div class="zen-image-with-text-over">
	<div class="zen-iwto-content-holder">
		<?php if ($link !== ''){?>
			<a href="<?php echo esc_url($link);?>" target="<?php echo esc_attr($target);?>">
		<?php } ?>
			<div class="zen-iwto-text-bckg-holder">
				<div class="zen-iwto-text-holder-outer">
					<div class="zen-iwto-text-holder-inner">
						<<?php echo esc_attr($text_tag_valid); ?> class="zen-iwto-text-holder" <?php rouhi_zenith_inline_style($text_style); ?>>
							<?php echo esc_html($text); ?>
						</<?php echo esc_attr($text_tag_valid); ?>>
						<?php echo rouhi_zenith_execute_shortcode('zen_separator',array(
							'type' => 'normal',
							'class_name' => 'zen-iwto-separator',
							'position' => 'left',
							'color_dot' => 'white',
							'border_style' => 'dotted_multiple',
							'thickness' => '3',
							'width' => '60px'
						)); ?>
					</div>
				</div>
			</div>
			<div class="zen-iwto-image">
				<?php echo wp_get_attachment_image($image,'full');?>
			</div>
		<?php if ($link !== ''){?>
			</a>
		<?php } ?>
	</div>
</div>