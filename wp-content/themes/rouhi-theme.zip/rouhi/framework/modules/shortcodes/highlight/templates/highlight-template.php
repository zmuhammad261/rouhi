<?php
/**
 * Highlight shortcode template
 */
?>

<span class="zen-highlight" <?php rouhi_zenith_inline_style($highlight_style);?>>
	<?php echo esc_html($content);?>
</span>