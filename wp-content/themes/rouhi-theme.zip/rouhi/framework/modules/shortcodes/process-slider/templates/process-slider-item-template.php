<div class="zen-process-slider-item">
	<?php if ($image != '') { ?>
		<div class="zen-process-image-holder">
			<?php echo wp_get_attachment_image($image,'full');?>
		</div>
	<?php } ?>
	<div class="zen-process-slide-item-title-holder">
		<span  class="zen-process-slide-item-number" <?php rouhi_zenith_inline_style($text_styles); ?>></span>
		<div class="zen-process-slide-item-titles">
			<?php if ($subtitle != '') {?>
				<h5 class="zen-process-subtitle" <?php rouhi_zenith_inline_style($subtitle_styles); ?>><?php echo esc_html($subtitle);?></h5>
			<?php } if ($title != '') {?>
				<h4 class="zen-process-title" <?php rouhi_zenith_inline_style($title_styles); ?>>
                    <?php if ($link != '') { ?>
                        <a href="<?php echo esc_url($link); ?>">
                    <?php } ?>
                        <?php echo esc_html($title);?>
                    <?php if ($link != '') { ?>
                        </a>
                    <?php } ?>
                </h4>
			<?php } ?>
		</div>
	</div>
	<?php if ($excerpt != '') { ?>
		<p class="zen-process-excerpt" <?php rouhi_zenith_inline_style($text_styles); ?>><?php echo esc_html($excerpt);?></p>
	<?php } ?>
</div>