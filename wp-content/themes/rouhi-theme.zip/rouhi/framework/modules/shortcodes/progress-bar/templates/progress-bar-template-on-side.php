<div class="zen-progress-bar zen-progress-on-side">
	<div class="zen-progress-left-holder">
		<<?php echo esc_attr($title_tag);?> class="zen-progress-title-holder clearfix" <?php rouhi_zenith_inline_style($progress_style['text_style']);?>>
			<span class="zen-progress-title"><?php echo esc_attr($title)?></span>
		</<?php echo esc_attr($title_tag)?>>
		<div class="zen-progress-content-outer" <?php rouhi_zenith_inline_style($progress_style['bar_style']);?>>
			<div data-percentage=<?php echo esc_attr($percent)?> class="zen-progress-content" <?php rouhi_zenith_inline_style($progress_style['active_bar_style']);?>></div>
		</div>
	</div>
	<div class="zen-progress-number-wrapper">
		<span class="zen-progress-number" <?php rouhi_zenith_inline_style($progress_style['percent_style']);?>>
			<span class="zen-percent">0</span>
		</span>
	</div>
</div>	