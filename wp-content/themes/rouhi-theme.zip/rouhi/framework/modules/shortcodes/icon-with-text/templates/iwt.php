<div <?php rouhi_zenith_class_attribute($holder_classes); ?>>
    <div class="zen-iwt-icon-holder">
        <?php if(!empty($custom_icon)) : ?>
            <?php echo wp_get_attachment_image($custom_icon, 'full'); ?>
        <?php else: ?>
            <?php echo rouhi_zenith_get_shortcode_module_template_part('templates/icon', 'icon-with-text', '', array('icon_parameters' => $icon_parameters)); ?>
        <?php endif; ?>
    </div>
    <div class="zen-iwt-content-holder" <?php rouhi_zenith_inline_style($content_styles); ?>>
        <div class="zen-iwt-title-holder">
			<?php if ($subtitle !== ''){ ?>
			<h5 class="zen-iwt-subtitle" <?php rouhi_zenith_inline_style($subtitle_styles); ?>>
				<?php echo esc_html($subtitle);?>
			</h5>
			<?php } ?>
			<?php  if ($title !== '') { ?>
     	       <<?php echo esc_attr($title_tag); ?> <?php rouhi_zenith_inline_style($title_styles); ?>><?php echo esc_html($title); ?></<?php echo esc_attr($title_tag); ?>>
            <?php } ?>
        </div>
        <div class="zen-iwt-text-holder">
            <p <?php rouhi_zenith_inline_style($text_styles); ?>><?php echo esc_html($text); ?></p>
            <?php if (is_array($btn_params) && count($btn_params)) {
                echo rouhi_zenith_execute_shortcode('zen_button',$btn_params);
            } ?>
        </div>
    </div>
</div>