<div <?php rouhi_zenith_class_attribute($holder_classes); ?>>
    <div class="zen-iwt-content-holder">
        <div class="zen-iwt-icon-title-holder">
            <div class="zen-iwt-icon-holder">
                <?php echo rouhi_zenith_get_shortcode_module_template_part('templates/icon', 'icon-with-text', '', array('icon_parameters' => $icon_parameters)); ?>
            </div>
            <div class="zen-iwt-title-holder">
				<?php if ($subtitle !== ''){ ?>
				<h5 class="zen-iwt-subtitle" <?php rouhi_zenith_inline_style($subtitle_styles); ?>>
					<?php echo esc_html($subtitle);?>
				</h5>
				<?php } ?>
				<?php  if ($title !== '') { ?>
                	<<?php echo esc_attr($title_tag); ?> <?php rouhi_zenith_inline_style($title_styles); ?>><?php echo esc_html($title); ?></<?php echo esc_attr($title_tag); ?>>
                <?php } ?>
            </div>
        </div>
        <div class="zen-iwt-text-holder">
            <p <?php rouhi_zenith_inline_style($text_styles); ?>><?php echo esc_html($text); ?></p>
            <?php if (is_array($btn_params) && count($btn_params)) {
                echo rouhi_zenith_execute_shortcode('zen_button',$btn_params);
            } ?>
        </div>
    </div>
</div>