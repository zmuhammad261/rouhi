<li class="zen-<?php echo esc_html($name) ?>-share">
	<a class="zen-share-link" href="#" onclick="<?php print $link; ?>">
		<?php if (rouhi_zenith_options()->getOptionValue('enable_top_text') == "yes") { ?>
		<span class="zen-share-label"><?php echo esc_html($top_text); ?></span>
		<?php } ?>
		<span class="zen-share-name"><?php echo esc_html($text); ?></span>
		<?php if ($custom_icon !== '') { ?>
			<img src="<?php echo esc_url($custom_icon); ?>" alt="<?php echo esc_html($name); ?>" />
		<?php } else { ?>
		<span class="zen-social-icons-holder">
			<span class="zen-social-network-icon <?php echo esc_attr($icon); ?>"></span>
			<span class="zen-social-arrow icon-arrows-slim-right"></span>
		</span>
		<?php } ?>
	</a>
</li>