<div class="zen-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>" <?php rouhi_zenith_inline_style($separator_holder_style); ?>>
	<div class="zen-separator" <?php rouhi_zenith_inline_style($separator_style); ?>></div>
</div>
