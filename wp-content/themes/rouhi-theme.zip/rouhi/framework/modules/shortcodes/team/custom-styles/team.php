<?php
/**
 * Custom styles for Team shortcode
 * Hooks to zenith_rouhi_style_dynamic hook
 */

//if (!function_exists('rouhi_zenith_team_style')) {
//
//	function rouhi_zenith_team_style()
//	{
//
//		if (rouhi_zenith_options()->getOptionValue('option_value') !== '') {
//			echo rouhi_zenith_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_team_style');
//
//}

?>