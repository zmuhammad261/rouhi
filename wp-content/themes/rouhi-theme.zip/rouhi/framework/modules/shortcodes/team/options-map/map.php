<?php

if ( ! function_exists('rouhi_zenith_team_options_map') ) {
	/**
	 * Add Team options to elements page
	 */
	function rouhi_zenith_team_options_map() {

		$panel_team = rouhi_zenith_add_admin_panel(
			array(
				'page' => '_elements_page',
				'name' => 'panel_team',
				'title' => 'Team'
			)
		);

	}

	add_action( 'rouhi_zenith_options_elements_map', 'rouhi_zenith_team_options_map');

}