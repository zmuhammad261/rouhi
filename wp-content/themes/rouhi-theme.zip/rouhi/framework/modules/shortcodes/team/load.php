<?php

include_once zenith_framework_modules_root_dir.'/shortcodes/team/options-map/map.php';
include_once zenith_framework_modules_root_dir.'/shortcodes/team/team.php';
include_once zenith_framework_modules_root_dir.'/shortcodes/team/custom-styles/team.php';