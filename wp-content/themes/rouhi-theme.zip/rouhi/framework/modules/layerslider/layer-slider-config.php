<?php
	if(!function_exists('rouhi_zenith_layerslider_overrides')) {
		/**
		 * Disables Layer Slider auto update box
		 */
		function rouhi_zenith_layerslider_overrides() {
			$GLOBALS['lsAutoUpdateBox'] = false;
		}

		add_action('layerslider_ready', 'rouhi_zenith_layerslider_overrides');
	}
?>