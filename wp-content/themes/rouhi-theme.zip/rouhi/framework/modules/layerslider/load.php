<?php

include_once zenith_framework_modules_root_dir.'/layerslider/layer-slider-config.php';
