<?php

if ( ! function_exists('rouhi_zenith_like') ) {
	/**
	 * Returns RouhiLike instance
	 *
	 * @return RouhiLike
	 */
	function rouhi_zenith_like() {
		return RouhiLike::get_instance();
	}

}

function rouhi_zenith_get_like() {

	echo wp_kses(rouhi_zenith_like()->add_like(), array(
		'span' => array(
			'class' => true,
			'aria-hidden' => true,
			'style' => true,
			'id' => true
		),
		'i' => array(
			'class' => true,
			'style' => true,
			'id' => true
		),
		'a' => array(
			'href' => true,
			'class' => true,
			'id' => true,
			'title' => true,
			'style' => true
		)
	));
}

if ( ! function_exists('rouhi_zenith_like_latest_posts') ) {
	/**
	 * Add like to latest post
	 *
	 * @return string
	 */
	function rouhi_zenith_like_latest_posts() {
		return rouhi_zenith_like()->add_like();
	}

}

if ( ! function_exists('rouhi_zenith_like_portfolio_list') ) {
	/**
	 * Add like to portfolio project
	 *
	 * @param $portfolio_project_id
	 * @return string
	 */
	function rouhi_zenith_like_portfolio_list($portfolio_project_id) {
		return rouhi_zenith_like()->add_like_portfolio_list($portfolio_project_id);
	}

}

if ( ! function_exists('rouhi_zenith_like_portfolio_post') ) {
    /**
     * Add like to portfolio project
     *
     * @param $portfolio_project_id
     * @return string
     */
    function rouhi_zenith_like_portfolio_post($portfolio_project_id) {
        return rouhi_zenith_like()->add_like_portfolio_post($portfolio_project_id);
    }

}