<?php

include_once zenith_framework_modules_root_dir.'/like/like.php';
include_once zenith_framework_modules_root_dir.'/like/like-functions.php';