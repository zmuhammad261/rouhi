<?php

if( !function_exists('rouhi_zenith_search_body_class') ) {
	/**
	 * Function that adds body classes for different search types
	 *
	 * @param $classes array original array of body classes
	 *
	 * @return array modified array of classes
	 */
	function rouhi_zenith_search_body_class($classes) {

		if ( is_active_widget( false, false, 'zen_search_opener' ) ) {

			$classes[] = 'zen-fullscreen-search';

			$classes[] = 'zen-' . rouhi_zenith_options()->getOptionValue('search_animation');

		}
		return $classes;

	}

	add_filter('body_class', 'rouhi_zenith_search_body_class');
}

if ( ! function_exists('rouhi_zenith_get_search') ) {
	/**
	 * Loads search HTML based on search type option.
	 */
	function rouhi_zenith_get_search() {

		if ( rouhi_zenith_active_widget( false, false, 'zen_search_opener' ) ) {

			rouhi_zenith_load_search_template();

		}
	}

}

if ( ! function_exists('rouhi_zenith_set_search_position_mobile') ) {
	/**
	 * Hooks search template to mobile header
	 */
	function rouhi_zenith_set_search_position_mobile() {

		add_action( 'rouhi_zenith_after_mobile_header_html_open', 'rouhi_zenith_load_search_template');

	}

}

if ( ! function_exists('rouhi_zenith_load_search_template') ) {
	/**
	 * Loads HTML template with parameters
	 */
	function rouhi_zenith_load_search_template() {
		global $rouhi_zenith_IconCollections;

		$search_icon = '';
		$search_icon_close = '';
		if ( rouhi_zenith_options()->getOptionValue('search_icon_pack') !== '' ) {
			$search_icon = $rouhi_zenith_IconCollections->getSearchIcon( rouhi_zenith_options()->getOptionValue('search_icon_pack'), true );
			$search_icon_close = $rouhi_zenith_IconCollections->getSearchClose( rouhi_zenith_options()->getOptionValue('search_icon_pack'), true );
		}

		$parameters = array(
			'search_in_grid'		=> rouhi_zenith_options()->getOptionValue('search_in_grid') == 'yes' ? true : false,
			'search_icon'			=> $search_icon,
			'search_icon_close'		=> $search_icon_close
		);

		rouhi_zenith_get_module_template_part( 'templates/types/fullscreen-search', 'search', '', $parameters );

	}

}