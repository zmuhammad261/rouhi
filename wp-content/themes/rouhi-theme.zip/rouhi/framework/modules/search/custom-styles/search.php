<?php

if (!function_exists('rouhi_zenith_search_opener_icon_size')) {

	function rouhi_zenith_search_opener_icon_size()
	{

		if (rouhi_zenith_options()->getOptionValue('header_search_icon_size')) {
			echo rouhi_zenith_dynamic_css('.zen-search-opener', array(
				'font-size' => rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('header_search_icon_size')) . 'px'
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_opener_icon_size');

}

if (!function_exists('rouhi_zenith_search_opener_icon_colors')) {

	function rouhi_zenith_search_opener_icon_colors()
	{

		if (rouhi_zenith_options()->getOptionValue('header_search_icon_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-search-opener', array(
				'color' => rouhi_zenith_options()->getOptionValue('header_search_icon_color')
			));
		}

		if (rouhi_zenith_options()->getOptionValue('header_search_icon_hover_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-search-opener:hover', array(
				'color' => rouhi_zenith_options()->getOptionValue('header_search_icon_hover_color')
			));
		}

		if (rouhi_zenith_options()->getOptionValue('header_light_search_icon_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-light-header .zen-page-header > div:not(.zen-sticky-header) .zen-search-opener,
			.zen-light-header.zen-header-style-on-scroll .zen-page-header .zen-search-opener,
			.zen-light-header .zen-top-bar .zen-search-opener', array(
				'color' => rouhi_zenith_options()->getOptionValue('header_light_search_icon_color') . ' !important'
			));
		}

		if (rouhi_zenith_options()->getOptionValue('header_light_search_icon_hover_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-light-header .zen-page-header > div:not(.zen-sticky-header) .zen-search-opener:hover,
			.zen-light-header.zen-header-style-on-scroll .zen-page-header .zen-search-opener:hover,
			.zen-light-header .zen-top-bar .zen-search-opener:hover', array(
				'color' => rouhi_zenith_options()->getOptionValue('header_light_search_icon_hover_color') . ' !important'
			));
		}

		if (rouhi_zenith_options()->getOptionValue('header_dark_search_icon_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-dark-header .zen-page-header > div:not(.zen-sticky-header) .zen-search-opener,
			.zen-dark-header.zen-header-style-on-scroll .zen-page-header .zen-search-opener,
			.zen-dark-header .zen-top-bar .zen-search-opener', array(
				'color' => rouhi_zenith_options()->getOptionValue('header_dark_search_icon_color') . ' !important'
			));
		}
		if (rouhi_zenith_options()->getOptionValue('header_dark_search_icon_hover_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-dark-header .zen-page-header > div:not(.zen-sticky-header) .zen-search-opener:hover,
			.zen-dark-header.zen-header-style-on-scroll .zen-page-header .zen-search-opener:hover,
			.zen-dark-header .zen-top-bar .zen-search-opener:hover', array(
				'color' => rouhi_zenith_options()->getOptionValue('header_dark_search_icon_hover_color') . ' !important'
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_opener_icon_colors');

}

if (!function_exists('rouhi_zenith_search_opener_icon_background_colors')) {

	function rouhi_zenith_search_opener_icon_background_colors()
	{

		if (rouhi_zenith_options()->getOptionValue('search_icon_background_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-search-opener', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('search_icon_background_color')
			));
		}

		if (rouhi_zenith_options()->getOptionValue('search_icon_background_hover_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-search-opener:hover', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('search_icon_background_hover_color')
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_opener_icon_background_colors');
}

if (!function_exists('rouhi_zenith_search_opener_text_styles')) {

	function rouhi_zenith_search_opener_text_styles()
	{
		$text_styles = array();

		if (rouhi_zenith_options()->getOptionValue('search_icon_text_color') !== '') {
			$text_styles['color'] = rouhi_zenith_options()->getOptionValue('search_icon_text_color');
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_text_fontsize') !== '') {
			$text_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_icon_text_fontsize')) . 'px';
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_text_lineheight') !== '') {
			$text_styles['line-height'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_icon_text_lineheight')) . 'px';
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_text_texttransform') !== '') {
			$text_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('search_icon_text_texttransform');
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_text_google_fonts') !== '-1') {
			$text_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('search_icon_text_google_fonts')) . ', sans-serif';
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_text_fontstyle') !== '') {
			$text_styles['font-style'] = rouhi_zenith_options()->getOptionValue('search_icon_text_fontstyle');
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_text_fontweight') !== '') {
			$text_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('search_icon_text_fontweight');
		}

		if (!empty($text_styles)) {
			echo rouhi_zenith_dynamic_css('.zen-search-icon-text', $text_styles);
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_text_color_hover') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-search-opener:hover .zen-search-icon-text', array(
				'color' => rouhi_zenith_options()->getOptionValue('search_icon_text_color_hover')
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_opener_text_styles');
}

if (!function_exists('rouhi_zenith_search_opener_spacing')) {

	function rouhi_zenith_search_opener_spacing()
	{
		$spacing_styles = array();

		if (rouhi_zenith_options()->getOptionValue('search_padding_left') !== '') {
			$spacing_styles['padding-left'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_padding_left')) . 'px';
		}
		if (rouhi_zenith_options()->getOptionValue('search_padding_right') !== '') {
			$spacing_styles['padding-right'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_padding_right')) . 'px';
		}
		if (rouhi_zenith_options()->getOptionValue('search_margin_left') !== '') {
			$spacing_styles['margin-left'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_margin_left')) . 'px';
		}
		if (rouhi_zenith_options()->getOptionValue('search_margin_right') !== '') {
			$spacing_styles['margin-right'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_margin_right')) . 'px';
		}

		if (!empty($spacing_styles)) {
			echo rouhi_zenith_dynamic_css('.zen-search-opener', $spacing_styles);
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_opener_spacing');
}

if (!function_exists('rouhi_zenith_search_bar_background')) {

	function rouhi_zenith_search_bar_background()
	{

		if (rouhi_zenith_options()->getOptionValue('search_background_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-search-fade .zen-fullscreen-search-holder .zen-fullscreen-search-table, .zen-fullscreen-search-overlay', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('search_background_color')
			));
		}
	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_bar_background');
}

if (!function_exists('rouhi_zenith_search_text_styles')) {

	function rouhi_zenith_search_text_styles()
	{
		$text_styles = array();

		if (rouhi_zenith_options()->getOptionValue('search_text_color') !== '') {
			$text_styles['color'] = rouhi_zenith_options()->getOptionValue('search_text_color');
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-form-holder .zen-search-field:-moz-placeholder', array('color' => $text_styles['color']));
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-form-holder .zen-search-field::-moz-placeholder', array('color' => $text_styles['color'],'opacity' => '1'));
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-form-holder .zen-search-field:-ms-input-placeholder', array('color' => $text_styles['color']));
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-form-holder .zen-search-field::-webkit-input-placeholder', array('color' => $text_styles['color']));

		}
		if (rouhi_zenith_options()->getOptionValue('search_text_fontsize') !== '') {
			$text_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_text_fontsize')) . 'px';
		}
		if (rouhi_zenith_options()->getOptionValue('search_text_texttransform') !== '') {
			$text_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('search_text_texttransform');
		}
		if (rouhi_zenith_options()->getOptionValue('search_text_google_fonts') !== '-1') {
			$text_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('search_text_google_fonts')) . ', sans-serif';
		}
		if (rouhi_zenith_options()->getOptionValue('search_text_fontstyle') !== '') {
			$text_styles['font-style'] = rouhi_zenith_options()->getOptionValue('search_text_fontstyle');
		}
		if (rouhi_zenith_options()->getOptionValue('search_text_fontweight') !== '') {
			$text_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('search_text_fontweight');
		}
		if (rouhi_zenith_options()->getOptionValue('search_text_letterspacing') !== '') {
			$text_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_text_letterspacing')) . 'px';
		}

		if (!empty($text_styles)) {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-search-field,.zen-fullscreen-search-opened .zen-form-holder .zen-search-field', $text_styles);
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_text_styles');
}

if (!function_exists('rouhi_zenith_search_label_styles')) {

	function rouhi_zenith_search_label_styles()
	{
		$text_styles = array();

		if (rouhi_zenith_options()->getOptionValue('search_label_text_color') !== '') {
			$text_styles['color'] = rouhi_zenith_options()->getOptionValue('search_label_text_color');
		}
		if (rouhi_zenith_options()->getOptionValue('search_label_text_fontsize') !== '') {
			$text_styles['font-size'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_label_text_fontsize')) . 'px';
		}
		if (rouhi_zenith_options()->getOptionValue('search_label_text_texttransform') !== '') {
			$text_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('search_label_text_texttransform');
		}
		if (rouhi_zenith_options()->getOptionValue('search_label_text_google_fonts') !== '-1') {
			$text_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('search_label_text_google_fonts')) . ', sans-serif';
		}
		if (rouhi_zenith_options()->getOptionValue('search_label_text_fontstyle') !== '') {
			$text_styles['font-style'] = rouhi_zenith_options()->getOptionValue('search_label_text_fontstyle');
		}
		if (rouhi_zenith_options()->getOptionValue('search_label_text_fontweight') !== '') {
			$text_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('search_label_text_fontweight');
		}
		if (rouhi_zenith_options()->getOptionValue('search_label_text_letterspacing') !== '') {
			$text_styles['letter-spacing'] = rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_label_text_letterspacing')) . 'px';
		}

		if (!empty($text_styles)) {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-search-label', $text_styles);
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_label_styles');
}

if (!function_exists('rouhi_zenith_search_icon_styles')) {

	function rouhi_zenith_search_icon_styles()
	{

		if (rouhi_zenith_options()->getOptionValue('search_icon_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-search-submit', array(
				'color' => rouhi_zenith_options()->getOptionValue('search_icon_color')
			));
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_hover_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-search-submit:hover', array(
				'color' => rouhi_zenith_options()->getOptionValue('search_icon_hover_color')
			));
		}
		if (rouhi_zenith_options()->getOptionValue('search_icon_size') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-search-submit', array(
				'font-size' => rouhi_zenith_filter_px(rouhi_zenith_options()->getOptionValue('search_icon_size')) . 'px'
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_icon_styles');
}

if (!function_exists('rouhi_zenith_search_close_icon_styles')) {

	function rouhi_zenith_search_close_icon_styles()
	{

		if (rouhi_zenith_options()->getOptionValue('search_close_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-fullscreen-search-close-container a .zen-line-close', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('search_close_color')
			));
		}
		if (rouhi_zenith_options()->getOptionValue('search_close_hover_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-fullscreen-search-close-container a:hover .zen-line-close', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('search_close_hover_color')
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_close_icon_styles');
}

if (!function_exists('rouhi_zenith_search_border_style')) {

	function rouhi_zenith_search_border_style()
	{

		if (rouhi_zenith_options()->getOptionValue('search_border_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-field-holder', array(
				'border-bottom-color' => rouhi_zenith_options()->getOptionValue('search_border_color')
			));
		}
		if (rouhi_zenith_options()->getOptionValue('search_border_focus_color') !== '') {
			echo rouhi_zenith_dynamic_css('.zen-fullscreen-search-holder .zen-field-holder .zen-line', array(
				'background-color' => rouhi_zenith_options()->getOptionValue('search_border_focus_color')
			));
		}

	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_search_border_style');
}

?>
