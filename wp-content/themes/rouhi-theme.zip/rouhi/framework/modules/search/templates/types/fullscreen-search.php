<div class="zen-fullscreen-search-holder">
	<div class="zen-fullscreen-search-close-container">
		<div class="zen-search-close-holder">
			<a class="zen-fullscreen-search-close" href="javascript:void(0)">
                <span class="zen-line-close line1"></span>
                <span class="zen-line-close line2"></span>
			</a>
		</div>
	</div>
	<div class="zen-fullscreen-search-table">
		<div class="zen-fullscreen-search-cell">
			<div class="zen-fullscreen-search-inner">
				<?php if ( $search_in_grid ) { ?>
				<div class="zen-container">
					<div class="zen-container-inner clearfix">
				<?php } ?>
						<form action="<?php echo esc_url(home_url('/')); ?>" class="zen-fullscreen-search-form" method="get">
							<div class="zen-form-holder">
								<span class="zen-search-label"><?php esc_html_e('Enter your search terms:', 'rouhi'); ?></span>
								<div class="zen-field-holder">
									<input type="text"  name="s" class="zen-search-field" autocomplete="off" placeholder="<?php esc_html_e('Type your search','rouhi'); ?>"/>
									<div class="zen-line"></div>
								</div>
								<input type="submit" class="zen-search-submit" value="#" />
							</div>
						</form>
						<?php if ( $search_in_grid ) { ?>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>