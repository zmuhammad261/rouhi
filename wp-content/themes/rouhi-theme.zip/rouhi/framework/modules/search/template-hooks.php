<?php

//Get search HTML
add_action('rouhi_zenith_before_page_header', 'rouhi_zenith_get_search', 9);