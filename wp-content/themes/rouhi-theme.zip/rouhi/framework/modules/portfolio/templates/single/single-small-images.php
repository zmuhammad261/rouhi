<div class="zen-two-columns-75-25 clearfix">
    <div class="zen-column1">
        <div class="zen-column-inner">
            <?php
            $media = rouhi_zenith_get_portfolio_single_media();

            if(is_array($media) && count($media)) : ?>
                <div class="zen-portfolio-media">
                    <?php foreach($media as $single_media) : ?>
                        <div class="zen-portfolio-single-media">
                            <?php rouhi_zenith_portfolio_get_media_html($single_media); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="zen-column2">
        <div class="zen-column-inner">
            <div class="zen-portfolio-info-holder">

                <div class="zen-toolbar-holder">
                    <?php rouhi_zenith_portfolio_get_info_part('social'); ?>
                    <?php rouhi_zenith_portfolio_get_info_part('print'); ?>
                    <?php rouhi_zenith_portfolio_get_info_part('like'); ?>
                </div>

                <?php
                //get portfolio content section
                rouhi_zenith_portfolio_get_info_part('content');

                //get portfolio date section
                rouhi_zenith_portfolio_get_info_part('date');

                //get portfolio categories section
                rouhi_zenith_portfolio_get_info_part('categories');

                //get portfolio tags section
                rouhi_zenith_portfolio_get_info_part('tags');

                //get portfolio custom fields section
                rouhi_zenith_portfolio_get_info_part('custom-fields');
                ?>
            </div>
        </div>
    </div>
</div>