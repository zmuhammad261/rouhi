<?php if(rouhi_zenith_options()->getOptionValue('portfolio_single_hide_date') !== 'yes') : ?>

    <div class="zen-portfolio-info-item zen-portfolio-date">
        <h6 class="zen-info-title"><?php esc_html_e('Date', 'rouhi'); ?></h6>

        <p><?php the_time(get_option('date_format')); ?></p>
    </div>

<?php endif; ?>