<?php
if(rouhi_zenith_options()->getOptionValue('portfolio_single_hide_related') !== 'yes') :
$query = rouhi_zenith_get_related_post_type(get_the_ID(), array('posts_per_page' => '4'));
$categories = wp_get_post_terms(get_the_ID(), 'portfolio-category');
$category_html = '<div class="zen-ptf-category-holder">';
$k = 1;
foreach ($categories as $cat) {
    $category_html .= '<span>'.$cat->name.'</span>';
    if (count($categories) != $k) {
        $category_html .= ' | ';
    }
    $k++;
}
$category_html .= '</div>';

if(is_object($query)) { ?>
<div class="zen-related-projects">
    <h2><?php esc_html_e('Similar Projects','rouhi'); ?></h2>
    <?php
    echo rouhi_zenith_execute_shortcode('zen_separator', array(
        'type'         => 'normal',
        'position'     => 'left',
        'color_dot'    => 'black',
        'border_style' => 'dotted_multiple',
        'width'        => '140',
        'thickness'    => '3',
        'top_margin'   => '20',
        'bottom_margin'   => '40'
        ));
    ?>

    <div class="zen-portfolio-list-holder-outer zen-ptf-standard zen-ptf-four-columns zen-with-space">
        <div class="zen-portfolio-list-holder clearfix">
            <?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>

                <article class="zen-portfolio-item mix">
                    <div class = "zen-item-image-holder">
                        <a href="<?php echo esc_url(get_permalink()); ?>">
                            <?php
                            echo get_the_post_thumbnail(get_the_ID(),'rouhi_zenith_square');
                            ?>
                        </a>
                    </div>
                    <div class="zen-item-text-holder">
                        <?php echo wp_kses_post($category_html); ?>
                        <h3 class="zen-item-title">
                            <a href="<?php echo esc_url(get_permalink()) ?>">
                            <?php echo esc_attr(get_the_title()); ?>
                            </a>
                        </h3>
                        <?php echo rouhi_zenith_execute_shortcode('zen_button',array(
                            'type' => 'arrow',
                            'hover_type' => 'rotate',
                            'text' => esc_html__('View', 'rouhi'),
                            'link' => esc_url(get_permalink())
                        ));
                        ?>
                    </div>

                </article>

            <?php
            endwhile;
            endif;
            wp_reset_postdata();
            ?>
            <div class="zen-gap"></div>
            <div class="zen-gap"></div>
            <div class="zen-gap"></div>
            <div class="zen-gap"></div>
        </div>
    </div>
</div>
<?php }
endif;
?>