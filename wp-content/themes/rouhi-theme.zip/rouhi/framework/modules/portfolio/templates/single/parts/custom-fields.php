<?php
$custom_fields = get_post_meta(get_the_ID(), 'zen_portfolios', true);

if(is_array($custom_fields) && count($custom_fields)) :
    usort($custom_fields, 'rouhi_zenith_compare_portfolio_options');

    foreach($custom_fields as $custom_field) : ?>
        <div class="zen-portfolio-info-item zen-portfolio-custom-field">
            <?php if(!empty($custom_field['optionLabel'])) : ?>
                <h6 class="zen-info-title"><?php echo esc_html($custom_field['optionLabel']); ?></h6>
            <?php endif; ?>
            <p>
                <?php if(!empty($custom_field['optionUrl'])) : ?>
                <a href="<?php echo esc_url($custom_field['optionUrl']); ?>">
                    <?php endif; ?>
                    <?php echo wp_kses_post($custom_field['optionValue']); ?>
                    <?php if(!empty($custom_field['optionUrl'])) : ?>
                </a>
            <?php endif; ?>
            </p>
        </div>
    <?php endforeach; ?>

<?php endif; ?>
