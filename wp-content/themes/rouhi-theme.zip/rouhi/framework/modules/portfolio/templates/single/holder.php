<?php if($fullwidth) : ?>
<div class="zen-full-width">
    <div class="zen-full-width-inner">
<?php else: ?>
<div class="zen-container">
    <div class="zen-container-inner clearfix">
<?php endif; ?>
        <div <?php rouhi_zenith_class_attribute($holder_class); ?>>
            <?php if(post_password_required()) {
                echo get_the_password_form();
            } else {
                //load proper portfolio template
                rouhi_zenith_get_module_template_part('templates/single/single', 'portfolio', $portfolio_template);

                //load portfolio navigation
                rouhi_zenith_get_module_template_part('templates/single/parts/navigation', 'portfolio');

                //get portfolio custom fields section
                rouhi_zenith_get_module_template_part('templates/single/parts/related-portfolios', 'portfolio');

                //load portfolio comments
                rouhi_zenith_get_module_template_part('templates/single/parts/comments', 'portfolio');

            } ?>
        </div>
    </div>
</div>