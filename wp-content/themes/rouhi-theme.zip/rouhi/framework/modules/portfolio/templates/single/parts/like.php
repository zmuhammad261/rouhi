<div class="zen-like-holder">
    <?php echo rouhi_zenith_like_portfolio_post(get_the_ID()); ?>
</div>