<?php if(rouhi_zenith_options()->getOptionValue('enable_social_share') == 'yes'
    && rouhi_zenith_options()->getOptionValue('enable_social_share_on_portfolio-item') == 'yes') : ?>
    <div class="zen-portfolio-social">
        <?php echo rouhi_zenith_get_social_share_html(array(
            'type' => 'dropdown'
        )); ?>
    </div>
<?php endif; ?>