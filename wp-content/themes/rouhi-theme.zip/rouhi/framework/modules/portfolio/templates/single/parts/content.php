<div class="zen-portfolio-info-item">
    <h3><?php the_title(); ?></h3>
    <div class="zen-portfolio-content">
        <?php the_content(); ?>
    </div>
</div>