<div class="zen-print-holder">
    <a href="#" onClick="window.print();return false;" class="zen-print-page">
        <span class="icon-basic-printer zen-icon-printer"></span>
        <span class="zen-printer-title"><?php esc_html_e("Print page", "rouhi") ?></span>
    </a>
</div>