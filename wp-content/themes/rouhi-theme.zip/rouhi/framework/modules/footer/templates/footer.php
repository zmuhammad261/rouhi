<?php
/**
 * Footer template part
 */

rouhi_zenith_get_content_bottom_area(); ?>
</div> <!-- close div.content_inner -->
</div>  <!-- close div.content -->

<footer <?php rouhi_zenith_class_attribute($footer_classes); ?>>
	<div class="zen-footer-inner clearfix">

		<?php

		if($display_footer_top) {
			rouhi_zenith_get_footer_top();
		}
		if($display_footer_bottom) {
			rouhi_zenith_get_footer_bottom();
		}
		?>

	</div>
</footer>

</div> <!-- close div.zen-wrapper-inner  -->
</div> <!-- close div.zen-wrapper -->
<?php wp_footer(); ?>
</body>
</html>