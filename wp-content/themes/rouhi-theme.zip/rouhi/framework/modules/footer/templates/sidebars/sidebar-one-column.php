<div class="clearfix">
	<div class="zen_column zen-column1">
		<div class="zen-column-inner">
			<?php if(is_active_sidebar('footer_column_1')) {
				dynamic_sidebar( 'footer_column_1' );
			} ?>
		</div>
	</div>
</div>