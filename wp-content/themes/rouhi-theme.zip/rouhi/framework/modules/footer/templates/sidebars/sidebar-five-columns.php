<div class="zen-five-columns clearfix">
	<div class="zen-five-columns-inner">
		<div class="zen-column">
			<div class="zen-column-inner">
				<?php if(is_active_sidebar('footer_column_1')) {
					dynamic_sidebar( 'footer_column_1' );
				} ?>
			</div>
		</div>
		<div class="zen-column">
			<div class="zen-column-inner">
				<?php if(is_active_sidebar('footer_column_2')) {
					dynamic_sidebar( 'footer_column_2' );
				} ?>
			</div>
		</div>
		<div class="zen-column">
			<div class="zen-column-inner">
				<?php if(is_active_sidebar('footer_column_3')) {
					dynamic_sidebar( 'footer_column_3' );
				} ?>
			</div>
		</div>
		<div class="zen-column">
			<div class="zen-column-inner">
				<?php if(is_active_sidebar('footer_column_4')) {
					dynamic_sidebar( 'footer_column_4' );
				} ?>
			</div>
		</div>
		<div class="zen-column">
			<div class="zen-column-inner">
				<?php if(is_active_sidebar('footer_column_5')) {
					dynamic_sidebar( 'footer_column_5' );
				} ?>
			</div>
		</div>
	</div>
</div>