<?php

if(!function_exists('rouhi_zenith_footer_style')) {
	/**
	 * Generates custom styles for footer
	 */
	function rouhi_zenith_footer_style() {
		$selector = array();
		$styles = array();

		$styles['border-top'] = '1px solid #434343';
		$styles['padding-top'] = '34px';

		$footer_in_grid = rouhi_zenith_options()->getOptionValue('footer_in_grid');
		if ($footer_in_grid == "yes"){
			$selector[] = '.zen-footer-bottom-holder .zen-container-inner';
		}
		else{
			$selector[] = '.zen-footer-bottom-holder .zen-footer-bottom-holder-inner';
		}

		echo rouhi_zenith_dynamic_css($selector, $styles);
	}

	add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_footer_style');
}