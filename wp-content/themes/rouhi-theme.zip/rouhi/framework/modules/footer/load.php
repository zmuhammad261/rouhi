<?php

include_once zenith_framework_modules_root_dir.'/footer/options-map/map.php';
include_once zenith_framework_modules_root_dir.'/footer/functions.php';
include_once zenith_framework_modules_root_dir.'/footer/template-functions.php';
include_once zenith_framework_modules_root_dir.'/footer/custom-styles/footer.php';
