<?php do_action('rouhi_zenith_before_page_title'); ?>
<?php if($show_title_area) { ?>

    <div class="zen-title <?php echo rouhi_zenith_title_classes(); ?>" style="<?php echo esc_attr($title_height); echo esc_attr($title_background_color); echo esc_attr($title_background_image); ?>" data-height="<?php echo esc_attr(intval(preg_replace('/[^0-9]+/', '', $title_height), 10));?>" <?php echo esc_attr($title_background_image_width); ?>>
        <div class="zen-title-image"><?php if($title_background_image_src != ""){ ?><img src="<?php echo esc_url($title_background_image_src); ?>" alt="&nbsp;" /> <?php } ?></div>

        <?php if($background_type == "video") {
            if($v_image) { ?>
                <div class="zen-mobile-video-image" <?php echo rouhi_zenith_get_inline_attr($video_mobile_style, 'style'); ?>></div>
            <?php } ?>

            <div <?php echo rouhi_zenith_get_class_attribute($video_overlay_class).rouhi_zenith_get_inline_attr($video_overlay_style, 'style'); ?>></div>
            <div class="zen-video-wrap">
                <video class="zen-video" width="1920" height="800" <?php echo rouhi_zenith_get_inline_attr($video_attrs, 'poster'); ?> controls="controls" preload="auto" loop autoplay muted>
                    <?php if($video_webm !== "") { ?>
                        <source type="video/webm" src="<?php echo esc_url($video_webm); ?>">
                    <?php } ?>
                    <?php if($video_mp4 !== "") { ?>
                        <source type="video/mp4" src="<?php echo esc_url($video_mp4); ?>">
                    <?php } ?>
                    <?php if($video_ogv !== "") { ?>
                        <source type="video/ogg" src="<?php echo esc_url($video_ogv); ?>">
                    <?php } ?>
                    <object width="320" height="240" type="application/x-shockwave-flash" data="<?php echo zenith_assets_root; ?>/js/flashmediaelement.swf">
                        <param name="movie" value="<?php echo zenith_assets_root; ?>/js/flashmediaelement.swf" />
                        <?php if(!empty($video_mp4)) { ?>
                            <param name="flashvars" value="controls=true&amp;file=<?php esc_url($video_mp4); ?>" />
                        <?php } ?>
                        <?php if($v_image) { ?>
                            <img <?php echo rouhi_zenith_get_inline_attr($v_image, 'src'); ?> width="1920" height="800" title="No video playback capabilities" alt="<?php esc_html_e('video thumb','rouhi'); ?>" />';
                        <?php } ?>
                    </object>
                </video>
            </div>
        <?php  } ?>

        <div class="zen-title-holder" <?php rouhi_zenith_inline_style($title_holder_height); ?>>
            <div class="zen-container clearfix">
                <div class="zen-container-inner">
                    <div class="zen-title-subtitle-holder" style="<?php echo esc_attr($title_subtitle_holder_padding); ?>">
                        <div class="zen-title-subtitle-holder-inner">
                        <?php switch ($type){
                            case 'standard': ?>
                                <h1 <?php rouhi_zenith_inline_style($title_color); ?>><span><?php rouhi_zenith_title_text(); ?></span></h1>
                                <?php if($has_subtitle){ ?>
                                    <span class="zen-subtitle" <?php rouhi_zenith_inline_style($subtitle_color); ?>><span><?php rouhi_zenith_subtitle_text(); ?></span></span>
                                <?php } ?>
                                <?php rouhi_zenith_title_show_separator();?>
                                <?php if($enable_breadcrumbs){ ?>
                                    <div class="zen-breadcrumbs-holder"> <?php rouhi_zenith_custom_breadcrumbs(); ?></div>
                                <?php } ?>
                            <?php break;
                            case 'breadcrumb': ?>
                                <div class="zen-breadcrumbs-holder"> <?php rouhi_zenith_custom_breadcrumbs(); ?></div>
                                <?php rouhi_zenith_title_show_separator();?>
                            <?php break;
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php } ?>
<?php do_action('rouhi_zenith_after_page_title'); ?>