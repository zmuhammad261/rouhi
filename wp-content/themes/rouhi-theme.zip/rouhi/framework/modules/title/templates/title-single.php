<?php do_action('rouhi_zenith_before_page_title'); ?>
<?php if($show_title_area) { ?>

    <div class="zen-title title-single <?php echo rouhi_zenith_title_classes(); ?>" style="<?php echo esc_attr($title_height); echo esc_attr($title_background_color); echo esc_attr($title_background_image); ?>" data-height="<?php echo esc_attr(intval(preg_replace('/[^0-9]+/', '', $title_height), 10));?>" <?php echo esc_attr($title_background_image_width); ?>>
        <div class="zen-title-image"><?php if($title_background_image_src != ""){ ?><img src="<?php echo esc_url($title_background_image_src); ?>" alt="&nbsp;" /> <?php } ?></div>
        <div class="zen-title-holder" <?php rouhi_zenith_inline_style($title_holder_height); ?>>
            <div class="zen-container clearfix">
                <div class="zen-container-inner">
                    <div class="zen-title-subtitle-holder" style="<?php echo esc_attr($title_subtitle_holder_padding); ?>">
                        <div class="zen-title-subtitle-holder-inner">
                            <h1 <?php rouhi_zenith_inline_style($title_color); ?>><span><?php rouhi_zenith_title_text(); ?></span></h1>
                            <?php rouhi_zenith_title_show_separator();?>
                        </div>
                        <div class="zen-title-info-holder">
                        	<?php rouhi_zenith_post_info(array(
                        		'author' => 'yes',
	                        	'category' => 'yes'
                        	),'single') ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php } ?>
<?php do_action('rouhi_zenith_after_page_title'); ?>