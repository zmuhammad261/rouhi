<?php

if (!function_exists('rouhi_zenith_title_area_typography_style')) {

    function rouhi_zenith_title_area_typography_style(){

        $title_styles = array();

        if(rouhi_zenith_options()->getOptionValue('page_title_color') !== '') {
            $title_styles['color'] = rouhi_zenith_options()->getOptionValue('page_title_color');
        }
        if(rouhi_zenith_options()->getOptionValue('page_title_google_fonts') !== '-1') {
            $title_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('page_title_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('page_title_fontsize') !== '') {
            $title_styles['font-size'] = rouhi_zenith_options()->getOptionValue('page_title_fontsize').'px';
        }
        if(rouhi_zenith_options()->getOptionValue('page_title_lineheight') !== '') {
            $title_styles['line-height'] = rouhi_zenith_options()->getOptionValue('page_title_lineheight').'px';
        }
        if(rouhi_zenith_options()->getOptionValue('page_title_texttransform') !== '') {
            $title_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('page_title_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('page_title_fontstyle') !== '') {
            $title_styles['font-style'] = rouhi_zenith_options()->getOptionValue('page_title_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('page_title_fontweight') !== '') {
            $title_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('page_title_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('page_title_letter_spacing') !== '') {
            $title_styles['letter-spacing'] = rouhi_zenith_options()->getOptionValue('page_title_letter_spacing').'px';
        }

        $title_selector = array(
            '.zen-title .zen-title-holder h1'
        );

        echo rouhi_zenith_dynamic_css($title_selector, $title_styles);


        $subtitle_styles = array();

        if(rouhi_zenith_options()->getOptionValue('page_subtitle_color') !== '') {
            $subtitle_styles['color'] = rouhi_zenith_options()->getOptionValue('page_subtitle_color');
        }
        if(rouhi_zenith_options()->getOptionValue('page_subtitle_google_fonts') !== '-1') {
            $subtitle_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('page_subtitle_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('page_subtitle_fontsize') !== '') {
            $subtitle_styles['font-size'] = rouhi_zenith_options()->getOptionValue('page_subtitle_fontsize').'px';
        }
        if(rouhi_zenith_options()->getOptionValue('page_subtitle_lineheight') !== '') {
            $subtitle_styles['line-height'] = rouhi_zenith_options()->getOptionValue('page_subtitle_lineheight').'px';
        }
        if(rouhi_zenith_options()->getOptionValue('page_subtitle_texttransform') !== '') {
            $subtitle_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('page_subtitle_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('page_subtitle_fontstyle') !== '') {
            $subtitle_styles['font-style'] = rouhi_zenith_options()->getOptionValue('page_subtitle_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('page_subtitle_fontweight') !== '') {
            $subtitle_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('page_subtitle_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('page_subtitle_letter_spacing') !== '') {
            $subtitle_styles['letter-spacing'] = rouhi_zenith_options()->getOptionValue('page_subtitle_letter_spacing').'px';
        }

        $subtitle_selector = array(
            '.zen-title .zen-title-holder .zen-subtitle'
        );

        echo rouhi_zenith_dynamic_css($subtitle_selector, $subtitle_styles);


        $breadcrumb_styles = array();

        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_color') !== '') {
            $breadcrumb_styles['color'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_color');
        }
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_google_fonts') !== '-1') {
            $breadcrumb_styles['font-family'] = rouhi_zenith_get_formatted_font_family(rouhi_zenith_options()->getOptionValue('page_breadcrumb_google_fonts'));
        }
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_fontsize') !== '') {
            $breadcrumb_styles['font-size'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_fontsize').'px';
        }
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_lineheight') !== '') {
            $breadcrumb_styles['line-height'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_lineheight').'px';
        }
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_texttransform') !== '') {
            $breadcrumb_styles['text-transform'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_texttransform');
        }
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_fontstyle') !== '') {
            $breadcrumb_styles['font-style'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_fontstyle');
        }
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_fontweight') !== '') {
            $breadcrumb_styles['font-weight'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_fontweight');
        }
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_letter_spacing') !== '') {
            $breadcrumb_styles['letter-spacing'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_letter_spacing').'px';
        }

        $breadcrumb_selector = array(
            '.zen-title .zen-title-holder .zen-breadcrumbs a, .zen-title .zen-title-holder .zen-breadcrumbs span'
        );

        echo rouhi_zenith_dynamic_css($breadcrumb_selector, $breadcrumb_styles);

        $breadcrumb_selector_styles = array();
        if(rouhi_zenith_options()->getOptionValue('page_breadcrumb_hovercolor') !== '') {
            $breadcrumb_selector_styles['color'] = rouhi_zenith_options()->getOptionValue('page_breadcrumb_hovercolor');
        }

        $breadcrumb_hover_selector = array(
            '.zen-title .zen-title-holder .zen-breadcrumbs a:hover'
        );

        echo rouhi_zenith_dynamic_css($breadcrumb_hover_selector, $breadcrumb_selector_styles);

    }

    add_action('zenith_rouhi_style_dynamic', 'rouhi_zenith_title_area_typography_style');

}


