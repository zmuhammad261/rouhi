<?php

include_once zenith_framework_modules_root_dir.'/title/options-map/map.php';
include_once zenith_framework_modules_root_dir.'/title/filter-functions.php';
include_once zenith_framework_modules_root_dir.'/title/title-functions.php';
include_once zenith_framework_modules_root_dir.'/title/custom-styles/title.php';