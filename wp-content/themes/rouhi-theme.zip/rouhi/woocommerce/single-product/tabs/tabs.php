<?php
/**
 * Single Product tabs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/tabs.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	https://docs.woothemes.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter tabs and allow third parties to add their own
 *
 * Each tab is an array containing title, callback and priority.
 * @see woocommerce_default_product_tabs()
 */
$tabs = apply_filters( 'woocommerce_product_tabs', array() );

if ( ! empty( $tabs ) ) : ?>

	<div class="zen-accordion-holder clearfix zen-accordion zen-initial  ui-accordion ui-widget ui-helper-reset">
		<?php foreach ( $tabs as $key => $tab ) : ?>
			<h4 class="clearfix zen-title-holder">
				<span class="zen-tab-title">
					<span class="zen-tab-title-inner">
						<?php echo esc_html( $tab['title'] ); ?>
					</span>
				</span>
				<span class="zen-accordion-mark">
					<span class="zen-accordion-mark-icon">
						<span class="icon-arrows-plus"></span>
						<span class="icon-arrows-minus"></span>
					</span>
				</span>
			</h4>
			<div class="zen-accordion-content">
				<div class="zen-accordion-content-inner">
					<?php call_user_func( $tab['callback'], $key, $tab ); ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

<?php endif; ?>
