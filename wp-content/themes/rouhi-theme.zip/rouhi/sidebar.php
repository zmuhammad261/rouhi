<?php
$sidebar = rouhi_zenith_get_sidebar();
?>
<div class="zen-column-inner">
    <aside class="zen-sidebar">
        <?php
            if (is_active_sidebar($sidebar)) {
                dynamic_sidebar($sidebar);
            }
        ?>
    </aside>
</div>
