<?php
    /*
        Template Name: Blog: Standard
    */
?>
<?php get_header(); ?>
<?php rouhi_zenith_get_title(); ?>
<?php get_template_part('slider'); ?>
<div class="zen-container">
    <?php do_action('rouhi_zenith_after_container_open'); ?>
    <div class="zen-container-inner" >
        <?php rouhi_zenith_get_blog('standard'); ?>
    </div>
    <?php do_action('rouhi_zenith_before_container_close'); ?>
</div>
<?php get_footer(); ?>