<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <?php rouhi_zenith_wp_title(); ?>
    <?php
    /**
     * @see rouhi_zenith_header_meta() - hooked with 10
     * @see zen_user_scalable - hooked with 10
     */
    ?>
	<?php do_action('rouhi_zenith_header_meta'); ?>

	<?php wp_head(); ?>

</head>

<body <?php body_class(); ?> <?php echo rouhi_zenith_get_fixed_image_background(); ?>>

<div class="zen-wrapper">
    <div class="zen-wrapper-inner">
        <?php rouhi_zenith_get_header(); ?>

        <?php if(rouhi_zenith_options()->getOptionValue('show_back_button') == "yes") { ?>
            <a id='zen-back-to-top'  href='#'>
                <span class="zen-back-to-text">
                     <?php
                        echo esc_html_e('Top','rouhi');
                    ?>
                </span>
                <span class="zen-icon-stack">
                     <?php
                        rouhi_zenith_icon_collections()->getBackToTopIcon('linea_icons');
                    ?>
                </span>
            </a>
        <?php } ?>
        <?php rouhi_zenith_get_full_screen_menu(); ?>

        <div class="zen-content" <?php rouhi_zenith_content_elem_style_attr(); ?>>
            <div class="zen-content-inner">