<?php

if(!function_exists('rouhi_zenith_is_responsive_on')) {
    /**
     * Checks whether responsive mode is enabled in theme options
     * @return bool
     */
    function rouhi_zenith_is_responsive_on() {
        return rouhi_zenith_options()->getOptionValue('responsiveness') !== 'no';
    }
}