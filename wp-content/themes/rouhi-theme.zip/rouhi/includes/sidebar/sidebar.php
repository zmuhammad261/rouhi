<?php

if(!function_exists('rouhi_zenith_register_sidebars')) {
    /**
     * Function that registers theme's sidebars
     */
    function rouhi_zenith_register_sidebars() {

        register_sidebar(array(
            'name' => 'Sidebar',
            'id' => 'sidebar',
            'description' => 'Default Sidebar',
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<div class="sidebar-widget-title-holder"><h4>',
            'after_title' => '</h4><div class="zen-separator-holder clearfix zen-separator-full-width zen-dotted-multiple zen-sep-dark"><div class="zen-separator" style="height: 11px; margin-top: 25px; margin-bottom: 30px;"></div></div></div>'
        ));

    }

    add_action('widgets_init', 'rouhi_zenith_register_sidebars');
}

if(!function_exists('rouhi_zenith_add_support_custom_sidebar')) {
    /**
     * Function that adds theme support for custom sidebars. It also creates RouhiSidebar object
     */
    function rouhi_zenith_add_support_custom_sidebar() {
        add_theme_support('RouhiSidebar');
        if (get_theme_support('RouhiSidebar')) new RouhiSidebar();
    }

    add_action('after_setup_theme', 'rouhi_zenith_add_support_custom_sidebar');
}
