<?php

//define constants
define('zenith_root', get_template_directory_uri());
define('zenith_root_dir', get_template_directory());
define('zenith_assets_root', get_template_directory_uri().'/assets');
define('zenith_assets_root_dir', get_template_directory().'/assets');
define('zenith_framework_root', get_template_directory_uri().'/framework');
define('zenith_framework_root_dir', get_template_directory().'/framework');
define('zenith_framework_modules_root', get_template_directory_uri().'/framework/modules');
define('zenith_framework_modules_root_dir', get_template_directory().'/framework/modules');
define('zenith_theme_env', 'dev');

//include necessary files
include_once zenith_root_dir.'/framework/zen-framework.php';
include_once zenith_root_dir.'/includes/nav-menu/zen-menu.php';
include_once zenith_root_dir.'/includes/sidebar/zen-custom-sidebar.php';
include_once zenith_root_dir.'/includes/zen-related-posts.php';
include_once zenith_root_dir.'/includes/zen-options-helper-functions.php';
include_once zenith_root_dir.'/includes/sidebar/sidebar.php';
require_once zenith_root_dir.'/includes/plugins/class-tgm-plugin-activation.inc';
include_once zenith_root_dir.'/includes/plugins/plugins-activation.php';
include_once zenith_root_dir.'/assets/custom-styles/general-custom-styles.php';
include_once zenith_root_dir.'/assets/custom-styles/general-custom-styles-responsive.php';

if(!is_admin()) {
    include_once zenith_root_dir.'/includes/zen-body-class-functions.php';
}